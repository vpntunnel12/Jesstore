import requests
from cybervpn import *

@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
    async def ssh_member_manager(event):
        # Inline buttons for member SSH manager
        inline = [
            [Button.inline("𝚃𝚛𝚒𝚊𝚕 𝚂𝚂𝙷", "trial-ssh-member"),
             Button.inline("𝙲𝚛𝚎𝚊𝚝𝚎 𝚂𝚂𝙷", "create-ssh-member")],
            [Button.inline("𝙲𝚑𝚎𝚌𝚔 𝙻𝚘𝚐𝚒𝚗 𝚂𝚂𝙷", "login-ssh-member")],
            [Button.inline("𝚂𝚑𝚘𝚠 𝙰𝚕𝚕 𝚄𝚜𝚎𝚛 𝚂𝚂𝙷", "show-ssh-member")],
            [Button.inline("𝚁𝚎𝚗𝚎𝚠 𝚂𝚂𝙷", "renew-ssh-member")],
            [Button.inline("‹ 𝙼𝚊𝚒𝚗 𝙼𝚎𝚗𝚞 ›", "menu")]
        ]
        
        # Fetch location info
        location_info = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        
        # Create message content
        msg = f"""
**◇━━━━━━━━━━━━━━━━◇**
     **◇⟨🔸SSH SERVICE🔸⟩◇**
**◇━━━━━━━━━━━━━━━━◇**
**» Service:** `SSH`
**» Hostname/IP:** `{DOMAIN}`
**» ISP:** `{location_info["isp"]}`
**» Country:** `{location_info["country"]}`
**» ** 🤖@Riswanvpnstore
**◇━━━━━━━━━━━━━━━━◇**
"""
        await event.edit(msg, buttons=inline)

    async def ssh_admin_manager(event):
        # Inline buttons for admin SSH manager
        inline = [
            [Button.inline("TRIAL 1 HARI", "trial-ssh"),
             Button.inline("BUAT AKUN", "create-ssh"),
             Button.inline("HAPUS AKUN", "delete-ssh")],
            [Button.inline("CEK LOGIN", "login-ssh")],
            [Button.inline("CEK AKUN", "show-ssh")],
            [Button.inline("RENEW AKUN", "renew-ssh")],
            [Button.inline("‹KEMBALI›", "menu")]
        ]
        
        # Fetch location info
        location_info = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        
        # Create message content for admin
        msg = f"""
**◇━━━━━━━━━━━━━━━━◇**
    **◇⟨🔸SSH SERVICE🔸⟩◇**
           **Admin Manager**
**◇━━━━━━━━━━━━━━━━◇**
**» Service:** `SSH`
**» Hostname/IP:** `{DOMAIN}`
**» ISP:** `{location_info["isp"]}`
**» Country:** `{location_info["country"]}`
**» ** 🤖@Riswanvpnstore
**◇━━━━━━━━━━━━━━━━◇**
"""
        await event.edit(msg, buttons=inline)

    # Get user details and check access level
    user_id = str(event.sender_id)
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')
        
        # Show admin or member SSH manager based on the user's level
        if level == 'admin':
            await ssh_admin_manager(event)
        else:
            await ssh_member_manager(event)
    except Exception as e:
        print(f'Error: {e}')
