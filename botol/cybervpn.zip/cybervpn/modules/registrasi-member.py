from cybervpn import *
import subprocess
import datetime as DT
import asyncio

# Misalnya, PIN admin yang telah ditentukan
ADMIN_PIN = "0510"

@bot.on(events.CallbackQuery(data=b'registrasi-member'))
async def registrasi_handler(event):
    chat = event.chat_id
    sender = await event.get_sender()
    user_id = str(event.sender_id)

    async with bot.conversation(chat) as level:
        await event.edit("**ADMIN X USER BOT**", buttons=[
            [Button.inline("ADMIN BOT", "admin"), Button.inline("USER BOT", "user")]
        ])
        level = (await level.wait_event(events.CallbackQuery)).data.decode("ascii")

    async def registrasi_member(username, telegram_id, is_admin):
        saldo = 0
        register_user(telegram_id, saldo, is_admin)

        today = DT.date.today()
        later = today + DT.timedelta(days=int(0))
        msg = f"""
**━━━━━━━━━━━━━━━━**
**⟨ 🕊 Registrasi Sukses 🕊 ⟩**
**━━━━━━━━━━━━━━━━**
**» ID Member:** `{telegram_id}`
**» Username:** `{username}`
**» Saldo:** `IDR.0`
**━━━━━━━━━━━━━━━━**
**» Tanggal Registrasi:** `{later}`
**━━━━━━━━━━━━━━━━**
"""
        inline = [
                [Button.url("Telegram", "t.me/R23_VPNSTORE"),
                 Button.url("Whatsapp", "wa.me/6285888801241")]
        ]
        await event.respond(msg, buttons=inline)

    async with bot.conversation(chat) as conv:
        try:
            # Meminta input username
            await conv.send_message('**Masukkan username member:**')
            user_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            username = user_msg.raw_text

            # Meminta input Telegram ID
            await conv.send_message('**Masukkan Telegram ID member:**')
            id_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            telegram_id = id_msg.raw_text

            if level == 'admin':
                # Jika memilih ADMIN, meminta PIN
                await conv.send_message('**Masukkan PIN untuk konfirmasi registrasi admin:**')
                pin_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                pin_entered = pin_msg.raw_text

                if pin_entered == ADMIN_PIN:
                    await registrasi_member(username, telegram_id, 'admin')
                    await conv.send_message('**Registrasi Admin berhasil!**')
                else:
                    await conv.send_message('**PIN salah. Akses ditolak.**')
                    return
            else:
                # Jika memilih USER, langsung daftarkan sebagai user
                await registrasi_member(username, telegram_id, 'user')

        except asyncio.TimeoutError:
            print("Timeout terjadi selama percakapan.")
            await event.respond("Percakapan timeout. Silakan coba lagi.")
        except Exception as e:
            print(f'Error: {e}')
            await event.respond(f"Terjadi kesalahan: {e}")