from cybervpn import *
import subprocess
import datetime as DT
import asyncio

@bot.on(events.CallbackQuery(data=b'registrasi-member'))
async def registrasi_handler(event):
    chat = event.chat_id
    sender = await event.get_sender()
    user_id = str(event.sender_id)

    async with bot.conversation(chat) as level:
        await event.edit("**Pilih Role: Admin atau Reseller**", buttons=[
            [Button.inline("Admin", "admin"), Button.inline("Reseller", "user")]
        ])
        try:
            level_choice = (await level.wait_event(events.CallbackQuery)).data.decode("ascii")
        except asyncio.TimeoutError:
            await event.respond("Timeout terjadi. Silakan coba lagi.")
            return

    async def registrasi_member(telegram_id, level):
        saldo = 0
        register_user(telegram_id, saldo, level)

        today = DT.date.today()
        later = today + DT.timedelta(days=0)
        msg = f"""
**═══════════════════════**
**⟨ 🕊 Pendaftaran Berhasil 🕊 ⟩**
**═══════════════════════**
**» ID Reseller:** `{telegram_id}`
**═══════════════════════**
**» Tanggal Pendaftaran:** `{later}`
**═══════════════════════**
"""
        inline = [
            [Button.url("Telegram", "t.me/RiswanJabar"),
             Button.url("Whatsapp", "wa.me/6285888801241")]
        ]
        # Notifikasi untuk pengguna bahwa mereka sudah terdaftar
        await event.respond(msg, buttons=inline)

        # Kirimkan notifikasi kepada pengguna yang baru saja mendaftar
        try:
            notification_msg = f"**Selamat, pendaftaran Anda berhasil!**\n\nID Telegram Anda: `{telegram_id}`\nTerima kasih telah bergabung dengan kami."
            await bot.send_message(telegram_id, notification_msg)
        except Exception as e:
            print(f'Gagal mengirim notifikasi ke {telegram_id}: {e}')
            await event.respond(f"Terjadi kesalahan saat mengirim notifikasi ke pengguna {telegram_id}.")

    async with bot.conversation(chat) as conv:
        try:
            # Input ID Telegram
            await conv.send_message('**Masukkan ID Telegram Reseller:**')
            id_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            telegram_id = id_msg.raw_text.strip()

            if not telegram_id:
                await event.respond("ID Telegram tidak valid. Silakan coba lagi.")
                return

            # Panggil fungsi registrasi
            await registrasi_member(telegram_id, level_choice)

            # Cek level pengguna
            user_level = get_level_from_db(user_id)
            print(f'Level yang diambil dari database: {user_level}')

            if user_level != 'admin':
                await event.answer(f'Akses Ditolak..!!', alert=True)

        except asyncio.TimeoutError:
            print("Timeout terjadi selama percakapan.")
            await event.respond("Percakapan timeout. Silakan coba lagi.")
        except Exception as e:
            print(f'Error: {e}')
            await event.respond("Terjadi kesalahan. Silakan coba lagi.")