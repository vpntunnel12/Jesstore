from telethon import events
import subprocess
import datetime as DT
from telethon.sync import TelegramClient
import sqlite3

# Event handler for creating SSH accounts
@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
    chat = event.chat_id
    sender = await event.get_sender()
    
    async with bot.conversation(chat) as conv:
        # Requesting necessary details from the user
        await event.respond('**Username:**')
        user = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        await event.respond("**Password:**")
        pw = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        await event.respond("**Expired day (number of days):**")
        exp = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        await event.respond("**Login IP:**")
        login_ip = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text
        await event.edit("`Wait.. Setting up an Account`")
        
        # Create SSH user and apply IP restrictions
        try:
            # Calculate the expiry date
            expiry_date = (DT.date.today() + DT.timedelta(days=int(exp))).strftime("%Y-%m-%d")
            cmd = f'useradd -e {expiry_date} -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
            subprocess.check_output(cmd, shell=True)

            # Apply IP restriction using iptables
            ip_cmd = f"iptables -A INPUT -p tcp --dport 22 -s {login_ip} -j ACCEPT"
            subprocess.check_output(ip_cmd, shell=True)

            # Calculate the final expiry date for the message
            later = DT.date.today() + DT.timedelta(days=int(exp))
            msg = f"""
**═════════════════════════**
             **SSH/WS ACCOUNT**
**═════════════════════════**
**Host:** `{DOMAIN}`
**Username:** `{user.strip()}`
**Password:** `{pw.strip()}`
**Limit IP:** `{login_ip.strip()}`
**Expired on:** `{later}`
**═════════════════════════**
**Port TLS   :** `443`
**Port NTLS  :** `80` `8080`
**═════════════════════════**
**SSH CUSTOM:**
`{DOMAIN}:80@{user.strip()}:{pw.strip()}`
**═════════════════════════**
**UDP CUSTOM:**
`{DOMAIN}:1-65535@{user.strip()}:{pw.strip()}`
**═════════════════════════**
**Payload:**
```GET /cdn-cgi/trace HTTP/1.1[crlf]Host: Bug_Kalian[crlf][crlf]GET-RAY / HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]```
**═════════════════════════**
☞ó ‌つò☞ 𝓡𝓲𝓼𝓲𝓽𝓪𝓷𝓙𝓪𝓫𝓪𝓻 𝓢𝓽𝓸𝓻𝓮
**═════════════════════════**
            """
            await event.respond(msg)

        except subprocess.CalledProcessError:
            await event.respond("**An error occurred while creating the user or applying IP restrictions.**")
            return
        except ValueError:
            await event.respond("**Invalid input for expiry days. Please enter a valid number.**")
            return

    # Check user level from the database to determine access rights
    try:
        level = get_level_from_db(sender.id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await create_ssh_(event)
        else:
            await event.answer(f'Akses Ditolak..!!', alert=True)

    except Exception as e:
        print(f'Error: {e}')
        await event.respond("**Error occurred while checking your access level.**")