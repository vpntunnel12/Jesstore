from cybervpn import *
import subprocess
import datetime as DT
import sys
from telethon.sync import TelegramClient
import sqlite3

# Fungsi untuk melacak login pengguna
def track_user_login(user):
    conn = sqlite3.connect('user_sessions.db')
    cursor = conn.cursor()
    
    # Membuat tabel jika belum ada
    cursor.execute('''CREATE TABLE IF NOT EXISTS logins (
        user TEXT,
        login_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')
    
    # Menambahkan catatan login pengguna
    cursor.execute("INSERT INTO logins (user) VALUES (?)", (user,))
    conn.commit()
    
    # Menghitung berapa banyak login yang dilakukan oleh pengguna ini
    cursor.execute("SELECT COUNT(*) FROM logins WHERE user=?", (user,))
    login_count = cursor.fetchone()[0]
    
    conn.close()
    
    return login_count

@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
    chat = event.chat_id
    sender = await event.get_sender()
    
    async with bot.conversation(chat) as conv:
        # Meminta detail yang diperlukan termasuk harga
        await event.respond('**Username:**')
        user = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        await event.respond("**Password:**")
        pw = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        await event.respond("**Expired day:**")
        exp = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        # Meminta IP login
        await event.respond("**Login IP:**")
        login_ip = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text
        await event.edit("`Wait.. Setting up an Account`")
        
        # Membuat pengguna SSH
        cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
        try:
            subprocess.check_output(cmd, shell=True)
        except subprocess.CalledProcessError:
            await event.respond("**User Sudah ada**")
            return

        # Menerapkan pembatasan IP (contoh menggunakan iptables atau mengubah sshd_config)
        ip_cmd = f"iptables -A INPUT -p tcp --dport 22 -s {login_ip} -j ACCEPT"
        try:
            subprocess.check_output(ip_cmd, shell=True)
        except subprocess.CalledProcessError:
            await event.respond(f"**Failed to apply IP restriction for {login_ip}**")
            return

        # Menghitung tanggal kadaluarsa
        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))
        creation_date = today.strftime("%Y-%m-%d")  # Tanggal pembuatan akun

        # Pesan dengan detail akun termasuk harga dan tanggal pembuatan
        msg = f"""
**═════════════════════════**
**⚡BUAT AKUN SSH PREMIUM⚡**
**═════════════════════════**
**Host:**  `{DOMAIN}`
**Username:**  `{user}`
**Password:**  `{pw}`
**═════════════════════════**
**UDP CUSTOM:**
`{DOMAIN}:1-65535@{user}:{pw}`
**═════════════════════════**
**SSH CUSTOM:**
`{DOMAIN}:80@{user}:{pw}`
**═════════════════════════**
**Payload WebSocket⟩**
```GET /cdn-cgi/trace HTTP/1.1[crlf]Host: Bug_Kalian[crlf][crlf]GET-RAY / HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]```
**═════════════════════════**
**🗓️Tanggal Pembuatan:** `{creation_date}`
**🗓️Aktip Sampai Tanggal:** `{later}`
**═════════════════════════**
**☞ó ‌つò☞ 𝓡𝓲𝓼𝓮𝓮𝓽𝓱𝓮𝓻𝓮 𝓟𝓮𝓻𝓼𝓽𝓮𝓶 𝓢𝓽𝓸𝓻𝓮**
**═════════════════════════**
"""

        # Tombol inline untuk Telegram dan WhatsApp
        inline = [
            [Button.url("telegram", "t.me/RiswanJabar"),
             Button.url("whatsapp", "wa.me/6285888801241")]
        ]
        await event.respond(msg, buttons=inline)

        # Mengirim notifikasi ke grup (ganti GROUP_CHAT_ID dengan ID grup yang sesungguhnya)
        group_chat_id = -1002029496202  # Ganti dengan ID grup yang sesungguhnya
        group_msg = f"""
**═══════════════════**
       **⚡Notification Bot⚡**  
**═══════════════════**
**Tanggal:** `{creation_date}`
**═══════════════════**
**Ssh account created**
**Username:** `{user}`
**Login IP:** `{login_ip}`
**Expired on:** `{later}`
**═══════════════════**
**Order di** @RiswanJabar
**═══════════════════**
"""
        await bot.send_message(group_chat_id, group_msg)

        # Melacak login pengguna dan memberi notifikasi jika ada login ganda
        login_count = track_user_login(user)
        if login_count > 1:
            multi_login_msg = f"""
**⚠️ Multiple Logins Detected ⚠️**

**User:** `{user}`
**Login Count:** `{login_count}`

Pengguna ini telah login lebih dari sekali. Harap periksa aktivitasnya.
"""
            await bot.send_message(group_chat_id, multi_login_msg)

    chat = event.chat_id
    sender = await event.get_sender()

    try:
        # Memeriksa level pengguna dari database
        level = get_level_from_db(sender.id)
        print(f'Meminta level dari database: {level}')

        if level == 'admin':
            await create_ssh_(event)
        else:
            await event.answer(f'Akses Ditolak..!!', alert=True)
    except Exception as e:
        print(f'Error: {e}')