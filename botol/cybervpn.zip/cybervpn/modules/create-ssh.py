from cybervpn import *
import subprocess
import datetime as DT
import sys
from telethon.sync import TelegramClient
import sqlite3

@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
    chat = event.chat_id
    sender = await event.get_sender()
    
    async with bot.conversation(chat) as conv:
        # Asking for the necessary details including price
        await event.respond('**Username:**')
        user = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        await event.respond("**Password:**")
        pw = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        await event.respond("**Quota:**")
        quota = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        await event.respond("**Limit-ip:**")
        limit_ip = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        await event.respond("**Expired day:**")
        exp = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        # Asking for the server name or IP address
        await event.respond("**Server:**")
        server = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        # Asking for the config (could be SSH config or any custom config)
        await event.respond("**Config:**")
        config = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        # Asking for the login IP
        await event.respond("**Login IP:**")
        login_ip = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        # Asking for the price
        await event.respond("**Harga Rp:**")
        price = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        await event.edit("`Wait.. Setting up an Account`")
        
        # Create SSH user
        cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
        try:
            subprocess.check_output(cmd, shell=True)
        except subprocess.CalledProcessError:
            await event.respond("**User Sudah ada**")
            return

        # Apply IP restriction (example: using iptables or modifying sshd_config)
        ip_cmd = f"iptables -A INPUT -p tcp --dport 22 -s {login_ip} -j ACCEPT"
        try:
            subprocess.check_output(ip_cmd, shell=True)
        except subprocess.CalledProcessError:
            await event.respond(f"**Failed to apply IP restriction for {login_ip}**")
            return

        # Calculate expiry date
        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))

        # Message with account details including the price
        msg = f"""
**────────────────────────**
                **SSH/WS ACCOUNT**
**────────────────────────**
**Host         :** `{DOMAIN}`
**Usernem      :** `{user.strip()}`
**Passwd       :** `{pw.strip()}`
**Limit IP     :** `{login_ip.strip()}` **IP**
**Limit GB     :** `9999` **GB**
**Tpe Config   :** `{config.strip()}`
**Total Rp     :** `{price.strip()}` 
**Location     :** `{server.strip()}`
**Expired on   :** `{later}`
**────────────────────────**
                           **ALL PORTS**
**────────────────────────**
**Port TLS   :** `443`
**Port NTLS  :** `80` `8080`
**────────────────────────**
                     **SSH COSTUM**
**────────────────────────**
`{DOMAIN}:80@{user.strip()}:{pw.strip()}`
**────────────────────────**
                     **UDP COSTUM**
**────────────────────────**
`{DOMAIN}:1-65535@{user.strip()}:{pw.strip()}`
**────────────────────────**
**Payload:**
```GET /cdn-cgi/trace HTTP/1.1[crlf]Host: Bug_Kalian[crlf][crlf]GET-RAY / HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]```
**────────────────────────**
**SCRIPT MODIFIED BY SCRIPT PREMIUM**
**────────────────────────**
**❞Silahkan salin buat Testimoni**
```◇━━━━━━━━━━━━━━━━━◇
💰PEMBELIAN BERHASIL💰
◇━━━━━━━━━━━━━━━━━◇
-» PRODUK : SSH-WS
-» USER   : {user}
-» SERVER : {server.strip()}
-» CONFIG : {config.strip()}
-» LOGIN  : {login_ip.strip()} IP
-» HARGA  : RP {price.strip()}
-» EXP    : {later}
◇━━━━━━━━━━━━━━━━━◇```
by @R23_VPNSTORE
**────────────────────────**
"""

        # Inline buttons for Telegram and WhatsApp links
        inline = [
            [Button.url("telegram", "t.me/R23_VPNSTORE"),
             Button.url("whatsapp", "wa.me/6285888801241")]
        ]
        await event.respond(msg, buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()

    try:
        # Check user level from the database
        level = get_level_from_db(sender.id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await create_ssh_(event)
        else:
            await event.answer(f'Akses Ditolak..!!', alert=True)
    except Exception as e:
        print(f'Error: {e}')