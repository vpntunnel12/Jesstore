from cybervpn import *
import subprocess
import datetime as DT
import sys
from telethon.sync import TelegramClient
import sqlite3

@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
    chat = event.chat_id
    sender = await event.get_sender()
    
    async with bot.conversation(chat) as conv:
        await event.respond('**Username:**')
        user = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        await event.respond("**Password:**")
        pw = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        await event.respond("**Quota:**")
        quota = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        await event.respond("**Limit-ip:**")
        limit_ip = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        await event.respond("**Expired (in days):**")
        exp = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        await event.edit("`Wait.. Setting up an Account`")
        
        # Create SSH user
        cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
        try:
            subprocess.check_output(cmd, shell=True)
        except subprocess.CalledProcessError:
            await event.respond("**User Sudah ada**")
            return

        # Calculate expiry date
        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))

        # Message with account details
        msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━**
            **❞CREATE SSH WS❞**
**━━━━━━━━━━━━━━━━━━━━━━**
**» Host:** `{DOMAIN}`
**» Username:** `{user.strip()}`
**» Password:** `{pw.strip()}`
**» limit ip:** `{ip}`
**━━━━━━━━━━━━━━━━━━━━━━**
**❞FORMAT HTTP COSTUM❞:**
`{DOMAIN}:80@{user.strip()}:{pw.strip()}`
**━━━━━━━━━━━━━━━━━━━━━━**
**❞FORMAT UDP COSTUM❞:**
`{DOMAIN}:1-65535@{user.strip()}:{pw.strip()}`
**━━━━━━━━━━━━━━━━━━━━━━**
**❞Payload❞:**
```GET /cdn-cgi/trace HTTP/1.1[crlf]Host: Bug_Kalian[crlf][crlf]GET-RAY / HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]```
**━━━━━━━━━━━━━━━━━━━━━━**
**❞Notes pelangan**
**❞simpan detail pembelian akun**
**❞sebagai garansi. kirimkan detail** 
**❞pembelian akun ke admin untuk** 
**❞pengecekan ketika terjadi masalah**
**❞pada config**
**❞Expired:** `{later}`
**━━━━━━━━━━━━━━━━━━━━━━**
**❞Silahkan salin buat Testimoni**
```◇━━━━━━━━━━━━━━━━━◇
💰PEMBELIAN BERHASIL💰
◇━━━━━━━━━━━━━━━━━◇
-» PRODUK : SSH OVPN
-» SERVER : INDONESIA
-» CONFIG : XL VIDIO
-» USER   : {user}
-» LOGIN  : {ip} IP
-» HARGA  : 10.000
-» EXP    : {later}
◇━━━━━━━━━━━━━━━━━◇```
by @R23_VPNSTORE
**━━━━━━━━━━━━━━━━━━━━━━**
"""

        # Inline buttons for Telegram and WhatsApp links
        inline = [
            [Button.url("telegram", "t.me/R23_VPNSTORE"),
             Button.url("whatsapp", "wa.me/6285888801241")]
        ]
        await event.respond(msg, buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()

    try:
        # Check user level from the database
        level = get_level_from_db(sender.id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await create_ssh_(event)
        else:
            await event.answer(f'Akses Ditolak..!!', alert=True)
    except Exception as e:
        print(f'Error: {e}')
