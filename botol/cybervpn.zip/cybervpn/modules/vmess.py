from cybervpn import *
import subprocess
import json
import re
import base64
import datetime as DT
import requests
import time

# ... (kode lainnya)

import subprocess
import json
import base64
import datetime as DT
import re
from telethon import events

@bot.on(events.CallbackQuery(data=b'create-vmess'))
async def create_vmess(event):
    async def create_vmess_(event):
        # Conversation with user for username
        async with bot.conversation(chat) as user_conv:
            await event.respond('**Username :**')
            user = (await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        # Conversation with user for expiration
        async with bot.conversation(chat) as exp_conv:
            await event.respond('**Expired:**')
            exp = (await exp_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        # Conversation with user for IP limit
        async with bot.conversation(chat) as ip_conv:
            await event.respond('**Limit IP :**')
            ip = (await ip_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        # Conversation with user for quota limit
        async with bot.conversation(chat) as Quota_conv:
            await event.respond('**Quota:**')
            Quota = (await Quota_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        # Conversation with user for server
        async with bot.conversation(chat) as server_conv:
            await event.respond('**Server:**')
            server = (await server_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        # Conversation with user for config
        async with bot.conversation(chat) as config_conv:
            await event.respond('**Config:**')
            config = (await config_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        # Conversation with user for Login IP (number of IPs or a list of IPs)
        async with bot.conversation(chat) as login_ip_conv:
            await event.respond('**Login IP:**')
            login_ip = (await login_ip_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        # Conversation with user for price
        async with bot.conversation(chat) as price_conv:
            await event.respond('**Harga Rp:**')
            price = (await price_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        # Prepare command for subprocess
        cmd = f'printf "%s\n" "{user}" "{exp}" "{Quota}" "{ip}" | addws-bot'

        try:
            # Execute the command
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            await event.respond(f"An error occurred while generating VMess: {e}")
            return

        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))

        # Extract VMess URLs from the command output using regex
        b = [x.group() for x in re.finditer("vmess://(.*)", a)]

        if len(b) < 3:
            await event.respond("Error: Not enough VMess URLs generated.")
            return

        # Decode base64 and JSON parse
        try:
            z = base64.b64decode(b[0].replace("vmess://", "")).decode("ascii")
            z = json.loads(z)

            z1 = base64.b64decode(b[1].replace("vmess://", "")).decode("ascii")
            z1 = json.loads(z1)

            z2 = base64.b64decode(b[2].replace("vmess://", "")).decode("ascii")
            z2 = json.loads(z2)
        except Exception as e:
            await event.respond(f"Error parsing VMess data: {e}")
            return

        # Create the formatted response message
        msg = f"""
**────────────────────────**
               **XRAY/VMESS ACCOUNT**
**────────────────────────**
**Remarks      :**  `{user}`
**Host         :** `{DOMAIN}`
**Limit IP     :** `{login_ip}` **IP**
**Limit GB     :** `9999 GB`
**Tpe Config           :** `{config}`
**Total Rp                :** `{price}`
**Location     :** `{server}` 
**Expired on   :** `{later}`
**────────────────────────**
                           **ALL PORTS**
**────────────────────────**
**Port TLS     :** `443`
**Port NTLS    :** `80, 8080`
**Port DNS     :** `443, 53`
**Port gRPC    :** `443`
**Security     :** `auto`
**Network      :** `(WS) or (gRPC)`
**Path         :** `/vmess`
**Servicename  :** `vmess-grpc`
**UUID         :** `{z["id"]}`
**────────────────────────**
                         **VLESS TLS**
**────────────────────────**
```{b[0].strip("'").replace(" ","")}```
**────────────────────────**
                     **VLESS NON-TLS**
**────────────────────────**
```{b[1].strip("'").replace(" ","")}```
**────────────────────────**
                         **VLESS GRPC**
**────────────────────────**
```{b[2].strip("'")}```
**────────────────────────**
**SCRIPT MODIFIED BY SCRIPT PREMIUM**
**────────────────────────**
**❞Silahkan salin buat Testimoni**
```◇━━━━━━━━━━━━━━━━━◇
💰PEMBELIAN BERHASIL💰
◇━━━━━━━━━━━━━━━━━◇
-» PRODUK : VMESS
-» USER   : {user}
-» SERVER : {server} 
-» CONFIG : {config}
-» LOGIN  : {login_ip} IP
-» HARGA  : {price}
-» EXP    : {later}
◇━━━━━━━━━━━━━━━━━◇```
**by** @R23_VPNSTORE
**────────────────────────**
        """

        await event.respond(msg)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()
    
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await create_vmess_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')



# TRIAL VMESS
@bot.on(events.CallbackQuery(data=b'trial-vmess'))
async def trial_vmess(event):
    async def trial_vmess_(event):
        # loading animasi
        await event.edit("Processing.")
        await event.edit("Processing..")
        await event.edit("Processing...")
        await event.edit("Processing....")
        time.sleep(1)
        await event.edit("`Processing Crate Premium Account`")
        time.sleep(1)
        await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
        time.sleep(0)
        await event.edit("`Processing... 100%\n█████████████████████████ `")
        time.sleep(1)
        await event.edit("`Wait.. Setting up an Account`")

        # output cmd
        cmd = f'printf "%s\n" "Trial`</dev/urandom tr -dc X-Z0-9 | head -c4`" "1" "1" "1" | bot-trialws'

        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            print(f'Error: {e}')
            print(f'Subprocess output: {a}')
            await event.respond(f"An error occurred: {e}\nSubprocess output: {a}")
            return  # Stop execution if there's an error

        today = DT.date.today()
        later = today + DT.timedelta(days=1)  # You may need to adjust this, as "exp" is not defined in the scope
        b = [x.group() for x in re.finditer("vmess://(.*)", a)]

        z = base64.b64decode(b[0].replace("vmess://", "")).decode("ascii")
        z = json.loads(z)

        z1 = base64.b64decode(b[1].replace("vmess://", "")).decode("ascii")
        z1 = json.loads(z1)

        msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━**
               **❞TRIAL VMESS❞**
**━━━━━━━━━━━━━━━━━━━━━━**
**❞Port TLS    :** `443`
**❞Port NTLS   :** `80`
**❞UUID    :** `{z["id"]}`
**❞NetWork     :** `(WS) or (gRPC)`
**❞Path        :** `/vmess`
**❞ServiceName :** `vmess-grpc`
**━━━━━━━━━━━━━━━━━━━━━━**
**❞VMESS URL TLS:**
```{b[0].strip("'").replace(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━━**
**❞VMESS URL HTTP:**
```{b[1].strip("'").replace(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━━**
**❞VMESS URL gRPC:** 
```{b[2].strip("'")}```
**━━━━━━━━━━━━━━━━━━━━━━**
**❞Notes pelangan**
**❞simpan detail pembelian akun**
**❞sebagai garansi. kirimkan detail** 
**❞pembelian akun ke admin untuk** 
**❞pengecekan ketika terjadi masalah**
**❞pada config**
**❞Exp jatuh pada:** `{today}`
**━━━━━━━━━━━━━━━━━━━━━━**
**» ** 🤖@R23_VPNSTORE
        """
        await event.respond(msg)
        

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await trial_vmess_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')

#CEK VMESS
@bot.on(events.CallbackQuery(data=b'cek-vmess'))
async def cek_vmess(event):
    async def cek_vmess_(event):
        cmd = 'bash cek-ws'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"""
**◇━━━━━━━━━━━━━━━━━━◇**
   ** ⟨🔸Cek Vmess Account🔸⟩**
**◇━━━━━━━━━━━━━━━━━━◇**
{z}

**Shows Logged In Users Vmess**
""", buttons=[[Button.inline("MAIN MENU", "vmess")]])

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()
    
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await cek_vmess_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')



## CEK member VMESS
@bot.on(events.CallbackQuery(data=b'cek-member'))
async def cek_vmess(event):
    async def cek_vmess_(event):
        cmd = 'bash cek-mws'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"""

{z}

**Shows Users from databases**
""", buttons=[[Button.inline("MAIN MENU", "vmess")]])

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()
    
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await cek_vmess_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')





@bot.on(events.CallbackQuery(data=b'delete-vmess'))
async def delete_vmess(event):
    async def delete_vmess_(event):
        async with bot.conversation(chat) as user:
            await event.respond('**Username:**')
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        cmd = f'printf "%s\n" "{user}" | bot-del-vme'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**Successfully Delete User**")
        else:
            msg = f"""**Successfully Deleted {user} **"""
            await event.respond(msg)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()
    
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await delete_vmess_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')
        

@bot.on(events.CallbackQuery(data=b'renew-vmess'))
async def ren_vmess(event):
    async def ren_vmess_(event):
        # Collect user inputs
        async with bot.conversation(chat) as user_conv:
            await event.respond('**Username:**')
            user = await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = user.raw_text

        async with bot.conversation(chat) as exp_conv:
            await event.respond('**Expired:**')
            exp = await exp_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = exp.raw_text
            
        async with bot.conversation(chat) as ip_conv:
            await event.respond('**Limit IP:**')
            ip = await ip_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            ip = ip.raw_text
            
        async with bot.conversation(chat) as Quota_conv:
            await event.respond('**Limit Quota (GB):**')
            Quota = await Quota_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            Quota = Quota.raw_text  

        # Construct the command for renewing the vmess
        cmd = f'printf "%s\n" "{user}" "{exp}" "{Quota}" "{ip}" | bot-renew-vme'

        try:
            # Execute the renewal command
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
            msg = f"{user} successfully renewed {exp} days, {ip} IP {Quota} GB Quota."
        except subprocess.CalledProcessError as e:
            # Capture specific command errors
            msg = f"Error: {e.output.decode('utf-8')}"
        except Exception as e:
            # Catch any other errors
            msg = f"Unexpected error: {str(e)}"

        # Send the result message
        await event.respond(msg)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()

    try:
        # Check the user's level (only 'admin' can renew)
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await ren_vmess_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        # Handle exceptions for database or other errors
        print(f'Error: {e}')
        await event.respond("There was an issue processing your request.")
		
@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess(event):
    async def vmess_(event):
        inline = [
            [Button.inline("TRIAL VMESS", "trial-vmess"),
             Button.inline("CREATE VMESS", "create-vmess")],
            [Button.inline("USER LOGIN", "cek-vmess"),
             Button.inline("DELETE USER", "delete-vmess")],
            [Button.inline("RENEW USER", "renew-vmess")],
            [Button.inline("LIST USER", "cek-member"),
             Button.inline("MAIN MENU", "menu")]
        ]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
   **◇⟨🔸VMESS SERVICE🔸⟩◇**
              **Admin Manager**
**◇━━━━━━━━━━━━━━━━━◇**
**» Service:** `VMESS`
**» Hostname/IP:** `{DOMAIN}`
**» ISP:** `{z["isp"]}`
**» Country:** `{z["country"]}`
**» ** @R23_VPNSTORE
**◇━━━━━━━━━━━━━━━━━◇**
"""
        await event.edit(msg, buttons=inline)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await vmess_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')



