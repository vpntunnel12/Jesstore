from cybervpn import *
import subprocess
import json
import re
import base64
import datetime as DT
from telethon import events
import requests


# CREATE VMESS
@bot.on(events.CallbackQuery(data=b'create-vmess'))
async def create_vmess(event):
    chat = event.chat_id
    sender = event.sender_id
    
    async def create_vmess_(event):
        # Collect necessary information from the user
        async with bot.conversation(chat) as user_conv:
            await event.respond('**Username:**')
            user = (await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender))).raw_text
        
        async with bot.conversation(chat) as exp_conv:
            await event.respond('**Expiration (days):**')
            exp = (await exp_conv.wait_event(events.NewMessage(incoming=True, from_users=sender))).raw_text
        
        async with bot.conversation(chat) as login_ip_conv:
            await event.respond('**Login IP (number of IPs or list):**')
            login_ip = (await login_ip_conv.wait_event(events.NewMessage(incoming=True, from_users=sender))).raw_text
        
        # Generate VMess command
        cmd = f'printf "%s\n" "{user}" "{exp}" | addws-bot'
        
        try:
            # Execute the command
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            await event.respond(f"An error occurred while generating VMess: {e}")
            return

        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))

        # Extract VMess URLs using regex
        b = [x.group() for x in re.finditer("vmess://(.*)", a)]

        if len(b) < 3:
            await event.respond("Error: Not enough VMess URLs generated.")
            return

        # Decode base64 and JSON parse
        try:
            z = base64.b64decode(b[0].replace("vmess://", "")).decode("ascii")
            z = json.loads(z)

            z1 = base64.b64decode(b[1].replace("vmess://", "")).decode("ascii")
            z1 = json.loads(z1)

            z2 = base64.b64decode(b[2].replace("vmess://", "")).decode("ascii")
            z2 = json.loads(z2)
        except Exception as e:
            await event.respond(f"Error parsing VMess data: {e}")
            return

        # Prepare the response message
        msg = f"""
────────────────────────
          **XRAY/VMESS ACCOUNT**
────────────────────────
**Remarks :** `{user}`
**Host :** `{DOMAIN}`
**LOGIN :** `{login_ip}` **IP**
**Expired on :** `{later}`
────────────────────────
                           **ALL PORTS**
────────────────────────
**Port TLS :** `443`
**Port NTLS :** `80` `8080`
**Port DNS  :** `443` `53`
**Port gRPC  :** `443`
**Security :** `auto`
**Network  :** `(WS) or (gRPC)`
**Path :** `/vmess`
**Servicename:** `vmess-grpc`
**UUID :** `{z["id"]}`
────────────────────────
                         **VMESS TLS**
────────────────────────
```{b[0].strip("'").replace(" ","")}```
────────────────────────
                     **VMESS NON-TLS**
────────────────────────
```{b[1].strip("'").replace(" ","")}```
────────────────────────
                         **VMESS GRPC**
────────────────────────
```{b[2].strip("'")}```
────────────────────────
**by** @RiswanJabar
────────────────────────
   """
        
        await event.respond(msg)

    user_id = str(event.sender_id)
    try:
        level = get_level_from_db(user_id)
        if level == 'admin':
            await create_vmess_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        await event.respond(f"Error: {e}")


# TRIAL VMESS
@bot.on(events.CallbackQuery(data=b'trial-vmess'))
async def trial_vmess(event):
    async def trial_vmess_(event):
        # Generate Trial VMess command
        cmd = f'printf "%s\n" "Trial`</dev/urandom tr -dc X-Z0-9 | head -c4`" "1" "1" "1" | bot-trialws'

        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            await event.respond(f"An error occurred: {e}")
            return

        today = DT.date.today()
        later = today + DT.timedelta(days=1)
        b = [x.group() for x in re.finditer("vmess://(.*)", a)]

        z = base64.b64decode(b[0].replace("vmess://", "")).decode("ascii")
        z = json.loads(z)

        z1 = base64.b64decode(b[1].replace("vmess://", "")).decode("ascii")
        z1 = json.loads(z1)

        msg = f"""
────────────────────────
             **❞TRIAL VMESS❞**
────────────────────────
**Port TLS    :** `443`
**Port NTLS   :** `80`
**UUID    :** `{z["id"]}`
**NetWork     :** `(WS) or (gRPC)`
**Path        :** `/vmess`
**ServiceName :** `vmess-grpc`
────────────────────────
**VMESS URL TLS:**
```{b[0].strip("'").replace(" ","")}```
────────────────────────
**VMESS URL HTTP:**
```{b[1].strip("'").replace(" ","")}```
────────────────────────
**❞VMESS URL gRPC:** 
```{b[2].strip("'")}```
────────────────────────
**❞Exp jatuh pada:** `{today}`
────────────────────────
**» ** 🤖@RiswanJabar
        """
        await event.respond(msg)

    user_id = str(event.sender_id)
    try:
        level = get_level_from_db(user_id)
        if level == 'admin':
            await trial_vmess_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        await event.respond(f"Error: {e}")


# CEK VMESS
@bot.on(events.CallbackQuery(data=b'cek-vmess'))
async def cek_vmess(event):
    async def cek_vmess_(event):
        cmd = 'bash cek-ws'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"""
**◇━━━━━━━━━━━━━━━━━━◇**
   ** ⟨🔸Cek Vmess Account🔸⟩**
**◇━━━━━━━━━━━━━━━━━━◇**
{z}

**Shows Logged In Users Vmess**
""", buttons=[[Button.inline("MAIN MENU", "vmess")]])

    user_id = str(event.sender_id)
    try:
        level = get_level_from_db(user_id)
        if level == 'admin':
            await cek_vmess_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        await event.respond(f"Error: {e}")


# DELETE VMESS
@bot.on(events.CallbackQuery(data=b'delete-vmess'))
async def delete_vmess(event):
    async def delete_vmess_(event):
        async with bot.conversation(chat) as user:
            await event.respond('**Username:**')
            user = (await user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text
        cmd = f'printf "%s\n" "{user}" | bot-del-vme'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            await event.respond(f"An error occurred while deleting VMess user: {e}")
        else:
            msg = f"**Successfully Deleted {user}**"
            await event.respond(msg)

    user_id = str(event.sender_id)
    try:
        level = get_level_from_db(user_id)
        if level == 'admin':
            await delete_vmess_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        await event.respond(f"Error: {e}")


# RENEW VMESS
@bot.on(events.CallbackQuery(data=b'renew-vmess'))
async def ren_vmess(event):
    async def ren_vmess_(event):
        # Collect user inputs for renewal
        async with bot.conversation(chat) as user_conv:
            await event.respond('**Username:**')
            user = (await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text
        
        async with bot.conversation(chat) as exp_conv:
            await event.respond('**Expiration (days):**')
            exp = (await exp_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text
        
        async with bot.conversation(chat) as ip_conv:
            await event.respond('**Limit IP:**')
            ip = (await ip_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text
        
        async with bot.conversation(chat) as Quota_conv:
            await event.respond('**Limit Quota (GB):**')
            Quota = (await Quota_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text  

        # Construct the command for renewing VMess
        cmd = f'printf "%s\n" "{user}" "{exp}" "{Quota}" "{ip}" | bot-renew-vme'

        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
            msg = f"{user} successfully renewed {exp} days, {ip} IP {Quota} GB Quota."
        except subprocess.CalledProcessError as e:
            msg = f"Error: {e.output.decode('utf-8')}"
        except Exception as e:
            msg = f"Unexpected error: {str(e)}"

        # Send the result message
        await event.respond(msg)

    user_id = str(event.sender_id)
    try:
        level = get_level_from_db(user_id)
        if level == 'admin':
            await ren_vmess_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        await event.respond(f"Error: {e}")


# VMESS MENU
@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess(event):
    async def vmess_(event):
        inline = [
            [Button.inline("🆓TRIAL VMESS🆓", "trial-vmess"),
             Button.inline("➕CREATE VMESS➕", "create-vmess")],
            [Button.inline("🔑USER LOGIN🔑", "cek-vmess"),
             Button.inline("❌DELETE USER❌", "delete-vmess")],
            [Button.inline("🔄RENEW USER🔄", "renew-vmess")],
            [Button.inline("📜LIST USER📜", "cek-member"),
             Button.inline("🏠MAIN MENU🏠", "menu")]
        ]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
   **◇⟨🔸VMESS SERVICE🔸⟩◇**
              **Admin Manager**
**◇━━━━━━━━━━━━━━━━━◇**
**» Service:** `VMESS`
**» Hostname/IP:** `{DOMAIN}`
**» ISP:** `{z["isp"]}`
**» Country:** `{z["country"]}`
**» ** @RiswanJabar
**◇━━━━━━━━━━━━━━━━━◇**
"""
        await event.edit(msg, buttons=inline)

    user_id = str(event.sender_id)
    try:
        level = get_level_from_db(user_id)
        if level == 'admin':
            await vmess_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        await event.respond(f"Error: {e}")