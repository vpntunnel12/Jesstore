import subprocess
from cybervpn import *

@bot.on(events.CallbackQuery(data=b'renew-ssh-member'))
async def renew_ssh_member(event):
    async def renew_ssh_member_(event):
        async with bot.conversation(chat) as user_conv:
            await event.respond('**Username:**')
            user = (await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).message.message.strip()

        async with bot.conversation(chat) as exp_conv:
            await event.respond("**Perhatian! perpanjang akun akan mengenakan biaya sesuai create account sebelum perpanjang akun apakah sesuai user yang mau di perpanjang jika user salah maka bukan tanggung jawab kami 🙏 jika setuju silahkan klik tombol yang ada di bawah**", buttons=[
                [Button.inline(" 30 Day ", "30")]
            ])
            exp = await exp_conv.wait_event(events.CallbackQuery)
            exp = exp.data.decode("ascii")

        async with bot.conversation(chat) as ip_conv:
            await event.respond("Choose Expiry Day", buttons=[
                [Button.inline(" 2 IP ", "2")]
            ])
            ip = await ip_conv.wait_event(events.CallbackQuery)
            ip = ip.data.decode("ascii")
            
            await process_user_balance_ssh(event, user_id)

        cmd = f'printf "%s\n" "{user}" "{exp}" "1000" "{ip}" | renewws'

        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**User Not Found**")
        else:
            msg = f"""**Successfully Renewed  {user} exp {exp} Days Limit {ip} IP Quota 1000GB**"""
            await event.respond(msg)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')
        if level == 'user':
            await renew_ssh_member_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')

