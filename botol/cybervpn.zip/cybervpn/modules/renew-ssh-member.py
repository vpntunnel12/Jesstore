import subprocess
from cybervpn import *

@bot.on(events.CallbackQuery(data=b'renew-ssh-member'))
async def ren_vmess(event):
    async def ren_vmess_(event):
        async with bot.conversation(chat) as user_conv:
            await event.respond('**Perhatian! renew akun akan mengenakan biaya sesuai create account**')
            await event.respond('**Username:**')
            user = await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = user.raw_text

        async with bot.conversation(chat) as exp_conv:
            await event.respond("**Choose Expiry Day**", buttons=[
                [Button.inline(" 30 Day ", "30")]
            ])
            exp = await exp_conv.wait_event(events.CallbackQuery)
            exp = exp.data.decode("ascii")

        async with bot.conversation(chat) as ip_conv:
            await event.respond("**Choose Expiry Day**", buttons=[
                [Button.inline(" 2 IP ", "2")]
            ])
            ip = await ip_conv.wait_event(events.CallbackQuery)
            ip = ip.data.decode("ascii")

            
            
            

            await process_user_balance_ssh(event, user_id)

        cmd = f'printf "%s\n" "{user}" "{exp}" "100" "{ip}" | renewws'

        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**User Not Found**")
        else:
            msg = f"""**Successfully Renewed  {user} {exp} Days Limit {ip} IP Quota 100GB**"""
            await event.respond(msg)
