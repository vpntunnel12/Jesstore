from cybervpn import *
from telethon import events, Button
from datetime import datetime

# Fungsi untuk menampilkan daftar pengguna
async def show_user_info(event):
    try:
        users_data = tampilkan_semua_user()
        if users_data:
            user_info_str = "\n**━━━━━━━━━━━━━━━━━━**\n".join(users_data)
            msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
**     🕊 list your member 🕊**
**◇━━━━━━━━━━━━━━━━━◇**
{user_info_str}
**◇━━━━━━━━━━━━━━━━━◇**
**Total user:** `{get_user_count()}`
**◇━━━━━━━━━━━━━━━━━◇**
            """
            buttons = [[Button.inline("‹ Main Menu ›", "menu")]]
            await event.respond(msg, buttons=buttons)
        else:
            await event.respond("Data pengguna tidak tersedia saat ini.")
    except Exception as e:
        print(f'Error: {e}')
        await event.respond(f"Terjadi kesalahan: {e}")

# Fungsi untuk memeriksa apakah status admin sudah kadaluarsa
def is_admin_expired(user_id):
    expiration_date = get_admin_expiration_from_db(user_id)  # Ambil tanggal kadaluarsa dari database
    if expiration_date:
        current_date = datetime.now()
        return current_date > expiration_date  # Jika tanggal kadaluarsa sudah lewat, return True
    return False

@bot.on(events.CallbackQuery(data=b'show-user'))
async def show_user(event):
    user_id = str(event.sender_id)

    try:
        level = get_level_from_db(user_id)
        print(f'Memanggil level dari database: {level}')

        if level == 'admin':
            if is_admin_expired(user_id):  # Mengecek apakah admin sudah kadaluarsa
                await event.answer(f'Akses admin Anda telah kadaluarsa.', alert=True)
            else:
                await show_user_info(event)  # Tampilkan daftar pengguna jika status admin masih aktif
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')