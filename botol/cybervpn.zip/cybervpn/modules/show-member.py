from cybervpn import *
from telethon import events, Button
from telethon.tl.types import User

@bot.on(events.CallbackQuery(data=b'show-user'))
async def show_user(event):
    async def show_user_(event):
        try:
            # Retrieve the list of all users (or user details)
            users_data = tampilkan_semua_user()

            if users_data:
                user_info_str = ""

                for user in users_data:
                    # Assuming `user` is an object containing Telegram user details
                    username = user.username if user.username else "N/A"
                    full_name = f"{user.first_name} {user.last_name}" if user.first_name else "N/A"

                    # Construct a string with the username and full name
                    user_info_str += f"""
**Username:** @{username}
**Full Name:** {full_name}
**═══════════════════════**
                    """
                
                # Construct the message with user details
                msg = f"""
**═══════════════════════**
           **🕊 List of Your Resellers 🕊**
**═══════════════════════**
{user_info_str}
**═══════════════════════**
**Total Resellers:** `{get_user_count()}`
**═══════════════════════**
                """
                buttons = [[Button.inline("‹ Main Menu ›", "menu")]]
                await event.respond(msg, buttons=buttons)
            else:
                await event.respond("Data pengguna tidak tersedia saat ini.")

        except Exception as e:
            print(f'Error: {e}')
            await event.respond(f"An error occurred: {e}")

    user_id = str(event.sender_id)

    try:
        # Fetch the reseller level from the database
        reseller_level = get_level_from_db(user_id)
        print(f'Retrieved Reseller level from database: {reseller_level}')

        if reseller_level == 'admin':
            await show_user_(event)
        else:
            await event.answer(f'Akses Ditolak. Reseller Level: {reseller_level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')