from cybervpn import *
from telethon import events, Button

# Fungsi untuk mendapatkan username berdasarkan user_id
async def get_username_from_id(client, user_id):
    try:
        # Mendapatkan entitas pengguna berdasarkan ID
        user = await client.get_entity(user_id)
        
        # Jika pengguna memiliki username, kembalikan username tersebut
        if user.username:
            return user.username
        else:
            return "No username"  # Jika tidak ada username
    except Exception as e:
        print(f"Error mengambil username untuk user ID {user_id}: {e}")
        return "Unknown user"  # Mengembalikan jika gagal mengambil username

# Event handler untuk menangani callback 'show-user'
@bot.on(events.CallbackQuery(data=b'show-user'))
async def show_user(event):
    async def show_user_(event):
        try:
            users_data = tampilkan_semua_user()  # Mengambil daftar ID pengguna

            if users_data:
                user_info_str = ""
                for user_id in users_data:
                    # Mendapatkan username untuk setiap ID pengguna
                    username = await get_username_from_id(event.client, user_id)
                    
                    # Menambahkan informasi pengguna ke string
                    user_info_str += f"**User ID:** `{user_id}`\n**Username:** @{username}\n"
                    user_info_str += "═══════════════════════\n"  # Separator antara pengguna

                msg = f"""
**═══════════════════════**
**    🕊 Daftar Anggota Anda 🕊**
**═══════════════════════**

{user_info_str}

**═══════════════════════**
**Total Pengguna:** `{get_user_count()}`
**═══════════════════════**
                """
                buttons = [[Button.inline("‹ Menu Utama ›", "menu")]]
                await event.respond(msg, buttons=buttons)
            else:
                await event.respond("Data pengguna tidak tersedia saat ini.")  # Jika tidak ada pengguna

        except Exception as e:
            print(f'Error: {e}')
            await event.respond(f"Terjadi kesalahan: {e}")

    user_id = str(event.sender_id)

    try:
        level = get_level_from_db(user_id)
        print(f'Mengambil level dari database: {level}')

        if level == 'admin':  # Memeriksa apakah pengirim adalah admin
            await show_user_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)  # Menolak akses jika bukan admin
    except Exception as e:
        print(f'Error: {e}')