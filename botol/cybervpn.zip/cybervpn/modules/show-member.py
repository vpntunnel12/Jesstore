from cybervpn import *
from telethon import events, Button

@bot.on(events.CallbackQuery(data=b'add-user'))
async def add_user(event):
    async def add_user_(event):
        try:
            # Request for new user information (you can modify this as needed)
            msg = """
Please provide the new user's details:
1. `user_id` of the user.
2. `username` of the user (optional).
3. `level` (e.g., admin, user).
"""
            await event.respond(msg)
            
            # Wait for the user to respond with details
            response = await bot.wait_for(events.NewMessage(from_users=event.sender_id))
            
            # Process the response to get user data
            user_info = response.text.split("\n")
            
            # Example to parse user input (you might want to improve validation)
            user_id = user_info[0].split(":")[1].strip()
            username = user_info[1].split(":")[1].strip() if len(user_info) > 1 else "No username"
            level = user_info[2].split(":")[1].strip()

            # Add user to the database
            success = add_user_to_db(user_id, username, level)

            if success:
                await event.respond(f"User with ID {user_id} added successfully as {level}.")
            else:
                await event.respond("Failed to add the user. Please try again.")
        
        except Exception as e:
            print(f'Error: {e}')
            await event.respond(f"An error occurred: {e}")

    user_id = str(event.sender_id)

    try:
        # Retrieve the level of the user requesting the action (admin check)
        level = get_level_from_db(user_id)

        if level == 'admin':
            await add_user_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {member}', alert=True)

    except Exception as e:
        print(f'Error: {e}')
        await event.respond(f"An error occurred: {e}")