from datetime import datetime
from telethon import events, Button

# Fungsi dummy untuk mengambil tanggal kedaluwarsa dari database
def get_expiration_date_from_db(user_id):
    # Gantilah dengan logika nyata untuk mengambil tanggal kedaluwarsa dari database
    return datetime(2025, 1, 1)  # Contoh tanggal kedaluwarsa di masa depan

# Fungsi dummy untuk mengambil level pengguna dari database
def get_level_from_db(user_id):
    # Gantilah dengan logika nyata untuk mengambil level pengguna dari database
    return "admin"  # Contoh level pengguna adalah admin

# Fungsi dummy untuk mengambil semua data pengguna
def tampilkan_semua_user():
    # Gantilah dengan logika nyata untuk mengambil data pengguna dari database atau sumber lainnya
    return ["User 1", "User 2", "User 3"]  # Contoh daftar pengguna

# Fungsi untuk menghitung jumlah pengguna
def get_user_count():
    # Mengembalikan jumlah total pengguna
    return len(tampilkan_semua_user())  # Menghitung jumlah pengguna

@bot.on(events.CallbackQuery(data=b'show-user'))
async def show_user(event):
    async def show_user_(event):
        try:
            # Mengambil data pengguna
            users_data = tampilkan_semua_user()

            if users_data:
                # Menyiapkan string dengan daftar pengguna
                user_info_str = "\n**━━━━━━━━━━━━━━━━━━**\n".join(users_data)
                msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
**     🕊 Daftar Anggota Anda 🕊**
**◇━━━━━━━━━━━━━━━━━◇**
{user_info_str}
**◇━━━━━━━━━━━━━━━━━◇**
**Jumlah Pengguna:** `{get_user_count()}`
**◇━━━━━━━━━━━━━━━━━◇**
                """
                # Tombol untuk kembali ke menu utama
                buttons = [[Button.inline("‹ Menu Utama ›", "menu")]]
                await event.respond(msg, buttons=buttons)
            else:
                await event.respond("Data pengguna tidak tersedia saat ini.")  # Jika tidak ada data pengguna

        except Exception as e:
            print(f'Error: {e}')
            await event.respond(f"Terjadi kesalahan: {e}")

    user_id = str(event.sender_id)

    try:
        # Mengambil level dan tanggal kedaluwarsa pengguna
        level = get_level_from_db(user_id)  # Mengambil level pengguna
        expiration_date = get_expiration_date_from_db(user_id)  # Mengambil tanggal kedaluwarsa
        current_date = datetime.now()  # Mendapatkan tanggal dan waktu saat ini

        print(f'Level pengguna: {level}, tanggal kedaluwarsa: {expiration_date}')

        # Memeriksa apakah akses sudah kedaluwarsa
        if expiration_date and expiration_date < current_date:
            await event.answer("Akses Anda telah kedaluwarsa.", alert=True)
            return

        # Menampilkan data hanya jika level pengguna adalah admin
        if level == 'admin':
            await show_user_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)  # Jika bukan admin, akses ditolak

    except Exception as e:
        print(f'Error: {e}')
        await event.answer(f"Terjadi kesalahan: {e}")