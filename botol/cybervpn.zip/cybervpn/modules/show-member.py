from datetime import datetime
from cybervpn import *
from telethon import events, Button

@bot.on(events.CallbackQuery(data=b'show-user'))
async def show_user(event):
    async def show_user_data():
        try:
            users_data = tampilkan_semua_user()

            if users_data:
                user_info_str = "\n**━━━━━━━━━━━━━━━━━━**\n".join(users_data)
                msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
**     🕊 List of Users 🕊**
**◇━━━━━━━━━━━━━━━━━◇**
{user_info_str}
**◇━━━━━━━━━━━━━━━━━◇**
**Total user count:** `{get_user_count()}`
**◇━━━━━━━━━━━━━━━━━◇**
                """
                buttons = [[Button.inline("‹ Main Menu ›", "menu")]]
                await event.respond(msg, buttons=buttons)
            else:
                await event.respond("Data pengguna tidak tersedia saat ini.")

        except Exception as e:
            print(f'Error fetching user data: {e}')
            await event.respond(f"An error occurred: {e}")

    try:
        user_id = str(event.sender_id)
        level, admin_expiry_date_str = get_level_from_db(user_id), get_admin_expiry_from_db(user_id)  # Assuming this function exists
        print(f'Retrieved level: {level}, Admin expiry: {admin_expiry_date_str}')

        if level == 'admin':
            # Convert admin expiry date string to a datetime object
            admin_expiry_date = datetime.strptime(admin_expiry_date_str, "%Y-%m-%d %H:%M:%S")  # Adjust format as needed
            current_time = datetime.now()

            # Check if admin status has expired
            if admin_expiry_date < current_time:
                await event.answer('Your admin privileges have expired.', alert=True)
            else:
                await show_user_data()
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)

    except Exception as e:
        print(f'Error retrieving user level or expiry date: {e}')
        await event.respond(f"An error occurred: {e}")