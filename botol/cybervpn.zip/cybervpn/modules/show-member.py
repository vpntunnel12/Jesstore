from cybervpn import *
from telethon import events, Button

@bot.on(events.CallbackQuery(data=b'show-user'))
async def show_user(event):
    async def show_user_(event):
        try:
            # Mendapatkan data semua pengguna
            users_data = tampilkan_semua_user()  # Pastikan fungsi ini mengembalikan data yang valid

            if users_data:
                # Pastikan users_data berisi data yang benar dan formatnya tepat
                user_info_str = "\n**═══════════════════════**\n".join(users_data)
                
                # Mendapatkan total top-up untuk pengguna saat ini
                total_topup = get_total_topup(event.sender_id)
                
                # Mendapatkan saldo pengguna saat ini
                user_balance = get_balance(event.sender_id)
                
                # Menyusun pesan yang akan dikirim
                msg = f"""
**═══════════════════════**
           **🕊 List Reseller Anda 🕊**
**═══════════════════════**
{user_info_str}
**═══════════════════════**
**Total Reseller:** `{get_user_count()}`
**Total Top-up untuk Pengguna Ini:** `{total_topup}`
**Saldo Pengguna Saat Ini:** `{user_balance}`
**═══════════════════════**
                """
                # Menambahkan tombol untuk kembali ke menu utama
                buttons = [[Button.inline("‹ Menu Utama ›", "menu")]]
                await event.respond(msg, buttons=buttons)
            else:
                await event.respond("Data pengguna tidak tersedia saat ini.")

        except Exception as e:
            # Menangani error jika terjadi masalah
            print(f'Error: {e}')
            await event.respond(f"Terjadi kesalahan: {e}")

    user_id = str(event.sender_id)

    try:
        # Mengambil level akses pengguna
        level = get_level_from_db(user_id)
        print(f'Level pengguna yang diambil dari database: {level}')

        if level == 'admin':
            # Jika level pengguna adalah admin, tampilkan data pengguna
            await show_user_(event)
        else:
            # Jika level bukan admin, tampilkan pesan akses ditolak
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')
        await event.respond(f"Terjadi kesalahan saat memeriksa level akses: {e}")