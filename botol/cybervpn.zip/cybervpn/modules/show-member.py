from cybervpn import *
from telethon import events, Button

from telethon import Button, events

# Simulate fetching user data
def tampilkan_semua_user_with_names_and_balance():
    # (same as your current implementation)
    pass

# Function to get total user count
def get_user_count():
    return len(tampilkan_semua_user_with_names_and_balance())

# Simulate fetching level from DB
def get_level_from_db(user_id):
    return "admin"  # Simulating the admin level

@bot.on(events.CallbackQuery(data=b'show-user'))
async def show_user(event):
    async def show_user_(event, page=1):
        try:
            users_data = tampilkan_semua_user_with_names_and_balance()

            if users_data:
                users_per_page = 5
                total_pages = (len(users_data) // users_per_page) + (1 if len(users_data) % users_per_page else 0)
                start_index = (page - 1) * users_per_page
                end_index = start_index + users_per_page

                user_info_str = "\n".join([
                    f"**Name:** {user['name']}\n**ID:** {user['id']}\n**Level:** {user['level']}\n**Balance:** {user['saldo']} USD"
                    for user in users_data[start_index:end_index]
                ])

                msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
**     🕊 List of Users 🕊**
**◇━━━━━━━━━━━━━━━━━◇**
{user_info_str}
**◇━━━━━━━━━━━━━━━━━◇**
**Total users:** `{get_user_count()}`
**◇━━━━━━━━━━━━━━━━━◇**
Page {page} of {total_pages}
                """
                
                buttons = [
                    [Button.inline("‹ Main Menu ›", "menu")],
                    [Button.inline("Previous", f"show-user-prev-{page}") if page > 1 else Button.inline("Previous", disabled=True),
                     Button.inline("Next", f"show-user-next-{page}") if page < total_pages else Button.inline("Next", disabled=True)]
                ]
                await event.respond(msg, buttons=buttons)
            else:
                await event.respond("No user data available.")
        except Exception as e:
            print(f'Error: {e}')
            await event.respond(f"An error occurred: {e}")

    user_id = str(event.sender_id)
    try:
        level = get_level_from_db(user_id)
        if level == 'admin':
            await show_user_(event)
        else:
            await event.answer(f'Access Denied. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')