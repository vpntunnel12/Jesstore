from cybervpn import *
import subprocess
import datetime as DT
from telethon.sync import TelegramClient
import sqlite3
import random
from telethon import events

# Example of the get_level_from_db function
def get_level_from_db(user_id):
    try:
        # Assuming you have a SQLite DB to fetch user levels.
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()
        cursor.execute("SELECT level FROM users WHERE user_id = ?", (user_id,))
        result = cursor.fetchone()
        conn.close()
        if result:
            return result[0]  # Return the level from the database.
        else:
            return None
    except Exception as e:
        print(f"Error fetching level from DB: {e}")
        return None


@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
    user_id = str(event.sender_id)

    async def trial_ssh_(event):
        user = "Trial-" + str(random.randint(100, 1000))
        pw = "1"  # You should consider better password handling (randomly generated).
        exp = 1  # Expiry days.
        today = DT.date.today()
        later = today + DT.timedelta(days=exp)

        # User creation command
        cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
        
        try:
            subprocess.check_output(cmd, shell=True)
        except subprocess.CalledProcessError:
            await event.respond("**User Already Exists**")
        else:
            msg = f"""
**═════════════════════════**
              **❞TRIAL SSH WS❞**
**═════════════════════════**
**❞Host:** `{DOMAIN}`
**❞Username:** `{user.strip()}`
**❞Password:** `{pw.strip()}`
**═════════════════════════**
**❞UDP CUSTOM:**
`{DOMAIN}:1-65535@{user.strip()}:{pw.strip()}`
**═════════════════════════**
**❞SSH CUSTOM:**
`{DOMAIN}:80@{user.strip()}:{pw.strip()}`
**═════════════════════════**
**❞Payload WebSocket⟩**
```GET /cdn-cgi/trace HTTP/1.1[crlf]Host: Bug_Kalian[crlf][crlf]GET-RAY / HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]```
**═════════════════════════**
**❞Expiry Date:** `{later}`
**═════════════════════════**
☞ó ‌つò☞ 𝓡𝓲𝓼𝔀𝓪𝓷𝓙𝓪𝓫𝓪𝓻 𝓢𝓽𝓸𝓻𝓮
**═════════════════════════**
"""
            await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await trial_ssh_(event)
        else:
            await event.answer(f'Akses Ditolak...!!', alert=True)
    except Exception as e:
        print(f'Error: {e}')
        await event.respond("An error occurred while processing your request.")