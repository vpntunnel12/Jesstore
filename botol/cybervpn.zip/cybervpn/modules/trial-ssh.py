from cybervpn import *
import subprocess
import datetime as DT
import sys
from telethon.sync import TelegramClient
import sqlite3
import random

@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
    user_id = str(event.sender_id)
    async def trial_ssh_(event):
        user = "Trial-" + str(random.randint(100, 1000))
        pw = "1"
        exp = "1"
        ip = "1"
        
        
    	
        cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
        try:
            subprocess.check_output(cmd, shell=True)
        except:
            await event.respond("**User Already Exist**")
        else:
            today = DT.date.today()
            later = today + DT.timedelta(days=int(exp))
            msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
**◇⟨🔸Ssh & OpenVpn 🔸⟩◇**
**◇━━━━━━━━━━━━━━━━━◇**
**» Domain:** `{DOMAIN}`
**» Username:** `{user.strip()}`
**» Password:** `{pw.strip()}`
**◇━━━━━━━━━━━━━━━━━◇**
**» Port OpenSsh :** 443, 80, 22
**» Poer Dropbear :** 443, 109
**» Port Ssh Ws :** 80, 8080
**» Port Ssh Ws Ssl/Tls :** 443
**» Port Ssh UDP :** 1-65535 
**» Port Ovpn Ssl :** 443
**» Port Ovpn TCP :** 443, 1194
**» Port Ovpn UDP :** 2200
**» BadVPN UDP :** 7100, 7300, 7300
**◇━━━━━━━━━━━━━━━━━◇**
** UDP FOR HTTP CUSTOM⟩**
`{DOMAIN}:1-65535@{user.strip()}:{pw.strip()}`
**◇━━━━━━━━━━━━━━━━━◇**
**FORMAT SSH**
`{DOMAIN}:80@{user.strip()}:{pw.strip()}`
**◇━━━━━━━━━━━━━━━━━◇**
**⟨OpenVpn⟩**
https://{DOMAIN}:81/
**◇━━━━━━━━━━━━━━━━━◇**
**⟨Payload Websocket⟩**
```GET /cdn-cgi/trace HTTP/1.1[crlf]Host: Bug_Kalian[crlf][crlf]GET-RAY / HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]```
**◇━━━━━━━━━━━━━━━━━◇**
**» Expired Until:** `{today}`
**◇━━━━━━━━━━━━━━━━━◇**
**» ** 🤖@Riswanvpnstore
"""
            inline = [
                [Button.url("telegram", "t.me/Riswanvpnstore"),
                 Button.url("whatsapp", "wa.me/6285888801241")]
            ]
            await event.respond(msg, buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await trial_ssh_(event)
        else:
            await event.answer(f'Akses Ditolak...!!', alert=True)
    except Exception as e:
        print(f'Error: {e}')

