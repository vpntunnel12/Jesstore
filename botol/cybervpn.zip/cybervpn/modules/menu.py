from cybervpn import *
from telethon import events, Button
import requests

url = "https://raw.githubusercontent.com/scriswan/fodder/main/statusku"

response = requests.get(url)


if response.status_code == 200:
    print(response.text)
else:
    print("Gagal mendapatkan konten dari URL")

@bot.on(events.NewMessage(pattern=r"(?:.menu|/start|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def start_menu(event):
    user_id = str(event.sender_id)

    if check_user_registration(user_id):
        try:
            saldo_aji, level = get_saldo_and_level_from_db(user_id)

            if level == "user":
                member_inline = [
                    [Button.inline("⚡SSH⚡", "ssh")],
                    [Button.inline("⚡VMESS⚡", "vmess-member"),
                     Button.inline("⚡VLESS⚡", "vless-member")],
                     [Button.inline("⚡TROJAN⚡", "trojan-member"),
                      Button.inline("💳TOPUP💳", f"topup")]
                   
                ]

                member_msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━━━━**
                  **♣️RZ VPNSTORE♣️**
**━━━━━━━━━━━━━━━━━━━━━━━━━━**
**  ➢SERVICE STATUS ** `Onlene` 🟢
**» ssh status             :** `{get_ssh_status()}`
**» ssh xray status     :** `{get_xray_status()}`
**» udp status            :** `{get_udp_status()}`
**» slowdns status    :** `{get_slowdns_status()}`
**» dropbear status   :** `{get_dropbear_status()}`
**» websocket status:** `{get_ws_status()}`

**🌐 CyberVPN Bot 🌐**
**Selamat datang di layanan CyberVPN!**
**Silakan pilih menu di bawah ini**

**1️⃣ Akun VP**
   **- 🔑 Buat Akun Baru**
   **- 🛠️ Perbarui Aku**
   **- ❌ Hapus Akun**
   
**2️⃣ Status Server**
   **- 📡 Lihat user Aktif**

**3️⃣ Layanan Premium**
   **- 🚀 Upgrade ke Premium**
   **- 💰 Harga Paket Rp.5000**
   **- 🔒 Akun Premium Saya**

**4️⃣ Informasi Pengguna**
   **- 📆 Masa Aktif Akun 30 days**

**5️⃣ Bantuan & Suppor**t
   **- ❓ FAQ**
   **- 🛠️ Hubungi Admin** @R23_VPNSTORE
   **- 📜 Panduan Penggunaan**

`📌 CyberVPN selalu melindungi privasi Anda dan` `memastikan pengalaman internet aman & cepat`
**━━━━━━━━━━━━━━━━━━━━━━━━━━**
**» 🇲🇨Version:** `v4.7.7`
**» 🇲🇨Your ID ** `{user_id}`
**» 🇲🇨Your SALDO : ** `RP.{saldo_aji}`
**━━━━━━━━━━━━━━━━━━━━━━━━━━**
"""
                x = await event.edit(member_msg, buttons=member_inline)
                if not x:
                    await event.reply(member_msg, buttons=member_inline)


            

            elif level == "admin":
                admin_inline = [
                    [Button.inline("Panel SSH", "ssh")],
                    [Button.inline("panel VMESS", "vmess"),
                     Button.inline("panel VLESS", "vless")],
                    [Button.inline("panel TRJAN", "trojan"),
                     Button.inline("panel SS -R", "shadowsocks")],
                    [Button.inline("panel NOOBZ", "noobzvpns"),
                     Button.inline("ADD MEMBER", "registrasi-member"),
                     Button.inline("DEL MEMBER", "delete-member")],
                     [Button.inline("LIST MEMBER", "show-user")],
                    [Button.inline("💰ADD MONEY💰 ", "addsaldo")],
                    [Button.inline("👙CHECKING VPS👙", "info"),
                     Button.inline("👙FEATURES SET👙", "setting")],
                    [Button.url("📩Whatsapp📩", "https://wa.me/6285888801241"),
                     Button.url("📤BuyScript📤", "https://wa.me/6285888801241")]
                ]
                
                admin_msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━━━━**
                  **♣️RZ VPNSTORE♣️**
**━━━━━━━━━━━━━━━━━━━━━━━━━━**
**  ➢SERVICE STATUS ** `Onlene` 🟢
**» ssh status             :** `{get_ssh_status()}`
**» ssh xray status     :** `{get_xray_status()}`
**» udp status            :** `{get_udp_status()}`
**» slowdns status    :** `{get_slowdns_status()}`
**» dropbear status   :** `{get_dropbear_status()}`
**» websocket status:** `{get_ws_status()}`
**━━━━━━━━━━━━━━━━━━━━━━━━━━**
**» 🇲🇨Version:** `v3.1.1`
**» 🇲🇨Your ID ** `{user_id}`
**» 🇲🇨Total Pengguna:** `{get_user_count()}`
**━━━━━━━━━━━━━━━━━━━━━━━━━━**
"""
                x = await event.edit(admin_msg, buttons=admin_inline)
                if not x:
                    await event.reply(admin_msg, buttons=admin_inline)

        except Exception as e:
            print(f"Error: {e}")

    else:
        await event.reply(
            f' `Siilahkan Registrasi Terlebih Dahulu` ',
            buttons=[[(Button.inline("Registrasi", "registrasi"))]]
        )

