from cybervpn import *
from telethon import events, Button
import requests

# Database untuk menyimpan user admin
admin_list = []

# Fungsi untuk menambah admin
def add_admin(user_id):
    if user_id not in admin_list:
        admin_list.append(user_id)
        # Simpan admin_list ke file atau database jika diperlukan
        print(f"User {user_id} telah ditambahkan sebagai admin.")
        return True
    return False

# Fungsi untuk memeriksa apakah user adalah admin
def is_admin(user_id):
    return user_id in admin_list

# URL dan pengambilan status dari URL
url = "https://raw.githubusercontent.com/scriswan/fodder/main/statusku"

response = requests.get(url)
if response.status_code == 200:
    print(response.text)
else:
    print("Gagal mendapatkan konten dari URL")

# Fungsi untuk memulai menu
@bot.on(events.NewMessage(pattern=r"(?:.menu|/start|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def start_menu(event):
    user_id = str(event.sender_id)
    first_name = event.sender.first_name  # Ambil nama depan pengguna
    last_name = event.sender.last_name if event.sender.last_name else ""  # Ambil nama belakang jika ada

    # Cek apakah pengguna sudah terdaftar
    if check_user_registration(user_id):
        try:
            saldo_aji, level = get_saldo_and_level_from_db(user_id)

            # Ambil informasi lokasi
            try:
                location_info = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
            except requests.exceptions.RequestException as e:
                print(f"Error fetching location info: {e}")
                location_info = {"country": "Unknown", "region": "Unknown", "city": "Unknown", "isp": "Unknown"}

            # Hitung jumlah akun
            ssh_count = subprocess.check_output('cat /etc/passwd | grep "home" | grep "false" | wc -l', shell=True).decode("ascii").strip()
            vmess_count = subprocess.check_output('cat /etc/vmess/.vmess.db | grep "###" | wc -l', shell=True).decode("ascii").strip()
            vless_count = subprocess.check_output('cat /etc/vless/.vless.db | grep "###" | wc -l', shell=True).decode("ascii").strip()
            trojan_count = subprocess.check_output('cat /etc/trojan/.trojan.db | grep "###" | wc -l', shell=True).decode("ascii").strip()

            # Menu untuk user biasa
            if level == "user":
                member_inline = [
                    [Button.inline("⚡SSH⚡", "ssh")],
                    [Button.inline("⚡VMESS⚡", "vmess-member"),
                     Button.inline("⚡VLESS⚡", "vless-member")],
                    [Button.inline("⚡TROJAN⚡", "trojan-member"),
                     Button.inline("💳DEPOSIT💳", f"topup")],
                    [Button.url("👉BANSOS👈", "http://t.me/Bansosvpnbot"),  
                     Button.url("🌍GRUP VPN🌍", "https://t.me/grupvpnriswan")]
                ]
                
                member_msg = f"""
**🛍️ Menu Jualan Vpn Store🛍**
**━━━━━━━━━━━━━━━━━━━━━━**
**»🏷️ Host:** `{DOMAIN}`
**»🏷️ ISP:** `{location_info["isp"]}`
**»🏷️ Location:** `{location_info["country"]}`
**━━━━━━━━━━━━━━━━━━━━━━**
**✨ Harga Layanan ✨**
**📌 Price SSH:   Rp. 8.000**
**📌 Price VMESS:  Rp. 8.000**
**📌 Price VLESS:     Rp. 8.000**
**📌 Price TROJAN:  Rp. 8.000**
**━━━━━━━━━━━━━━━━━━━━━━**
**🖥️ Jumlah Akun Tersedia**
**»🛒Ssh:** `{ssh_count}` `account`
**»🛒Vmess:** `{vmess_count}` `account`
**»🛒Vless:**       `{vless_count}` `account`
**»🛒Trojan:**        `{trojan_count}` `account`
**━━━━━━━━━━━━━━━━━━━━━━**
**👤 Informasi Pengguna 👤**
**» Penguna:** `{first_name} {last_name}`
**» ID Pengguna:** `{user_id}`
**» Total Pengguna:** `{get_user_count()}`
**» Saldo Anda: Rp.** `{saldo_aji}`
**━━━━━━━━━━━━━━━━━━━━━━**
**📡 Versi Bot:** `4.5`
**━━━━━━━━━━━━━━━━━━━━━━**
"""
                x = await event.edit(member_msg, buttons=member_inline)
                if not x:
                    await event.reply(member_msg, buttons=member_inline)

            # Menu untuk admin
            elif level == "admin":
                admin_inline = [
                    [Button.url("⚙️GRUP OWNER⚙️", "https://t.me/grupvpnriswan")],
                    [Button.inline("⚡SSH WS⚡", "ssh"),
                     Button.inline("⚡VMESS⚡", "vmess")],
                    [Button.inline("⚡VLESS⚡", "vless"),
                     Button.inline("⚡TROJAN⚡", "trojan")],
                    [Button.inline("⚙️INFO VPS⚙️", "info"),
                     Button.inline("⚙️SETINGS⚙️", "setting")],
                    [Button.inline("📝 Verifikasi Member", "verify_member")]  # Tombol untuk verifikasi member
                ]

                admin_msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━**
              **🔶Admin Riswan🔶**
**━━━━━━━━━━━━━━━━━━━━━━**
**»🏷️Host:** `{DOMAIN}`
**»🏷️ISP:** `{location_info["isp"]}`
**»🏷️Location:** `{location_info["country"]}`
**━━━━━━━━━━━━━━━━━━━━━━**
**🖥️ Jumlah Akun Tersedia**
**»🛒Ssh:** `{ssh_count}` `account`
**»🛒Vmess:** `{vmess_count}` `account`
**»🛒Vless:**       `{vless_count}` `account`
**»🛒Trojan:**        `{trojan_count}` `account`
**━━━━━━━━━━━━━━━━━━━━━━**
**👤 Informasi Pengguna 👤**
**» Admin:** `{first_name} {last_name}`
**» ID Admin:** `{user_id}`
**» Total Pengguna:** `{get_user_count()}`
**» Saldo Anda: Rp.** `{saldo_aji}`
**━━━━━━━━━━━━━━━━━━━━━━**
**📡 Versi Bot:** `4.5`
**━━━━━━━━━━━━━━━━━━━━━━**
"""
                x = await event.edit(admin_msg, buttons=admin_inline)
                if not x:
                    await event.reply(admin_msg, buttons=admin_inline)

        except Exception as e:
            print(f"Error: {e}")

    else:
        await event.reply(
            f' `Silakan Registrasi Terlebih Dahulu` ',
            buttons=[[(Button.inline("Registrasi", "registrasi"))]]
        )

# Tombol verifikasi member
@bot.on(events.CallbackQuery(data=b'verify_member'))
async def verify_member(event):
    user_id = str(event.sender_id)
    
    if is_admin(user_id):  # Pastikan hanya admin yang bisa verifikasi
        # Mengirimkan pesan untuk memilih member yang ingin diverifikasi
        await event.reply("Silakan pilih member yang ingin Anda verifikasi menjadi admin.")
        # Tambahkan mekanisme untuk memilih member dan menambahkannya ke daftar admin
    else:
        await event.reply("Hanya admin yang dapat melakukan verifikasi member.")