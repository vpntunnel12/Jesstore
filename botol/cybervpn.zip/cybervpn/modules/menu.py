from cybervpn import *
from telethon import events, Button
import requests

url = "https://raw.githubusercontent.com/scriswan/fodder/main/statusku"

response = requests.get(url)


if response.status_code == 200:
    print(response.text)
else:
    print("Gagal mendapatkan konten dari URL")

@bot.on(events.NewMessage(pattern=r"(?:.menu|/start|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def start_menu(event):
    user_id = str(event.sender_id)

    if check_user_registration(user_id):
        try:
            saldo_aji, level = get_saldo_and_level_from_db(user_id)

            if level == "user":
                member_inline = [
                    
                 [Button.inline("⚡SSH⚡", "ssh")],
                    [Button.inline("⚡VMESS⚡", "vmess-member"),
                    
                     
                      Button.inline("💳TOPUP💳", f"topup")]
                      
                   
                ]

                member_msg = f"""
█▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█
█░░╦─╦╔╗╦─╔╗╔╗╔╦╗╔╗░░█
█░░║║║╠─║─║─║║║║║╠─░░█
█░░╚╩╝╚╝╚╝╚╝╚╝╩─╩╚╝░░█
█▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█

Owner   = @R23_VPNSTORE
──────────────────────
Chat ID  = `{user_id}`
Balance  = Rp:`{saldo_aji}`
Member = `{get_user_count()}`
──────────────────────
SS-HWS   = RP 5000
VMESS    = RP 5000
──────────────────────
TRIAL = TAMPA BATAS TRIAL
TERSEDIA 2 PREMIUM SERVER
@SVID1_bot  = ID 🇮🇩
@SVSG1_bot = SG 🇸🇬
──────────────────────
Status •¯•» Member
──────────────────────
Bonus   = 25x Transaction
Bonus   = Rp5000
──────────────────────
Panel Member Vpn Premium
──────────────────────
"""
                x = await event.edit(member_msg, buttons=member_inline)
                if not x:
                    await event.reply(member_msg, buttons=member_inline)


            elif level == "admin":
                admin_inline = [
                   [Button.inline("AKUN SSH", "ssh")],
                    [Button.inline("AKUN VMESS", "vmess"),
                     Button.inline("AKUN VLESS", "vless")],
                    [Button.inline("AKUN TROJAN", "trojan"),
                     Button.inline("ADD RESSLLER", "registrasi-member")],
                     [Button.inline("HAPUS RESSELLER", "delete-member")],
                     [Button.inline("DAFTAR RESSELER", "show-user")],
                    [Button.inline("ADD SALDO RESSELLER", "addsaldo")],
                    [Button.inline("CEK INFO VPS", "info"),
                     Button.inline("PENGATURAN", "setting")],
                    [Button.url("TELEGRAM", "https://t.me/R23_VPNSTORE"),
                     Button.url("WHATSAPP", "https://wa.me/6285888801241")]
                ]

                admin_msg = f"""
█▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█
█░░╦─╦╔╗╦─╔╗╔╗╔╦╗╔╗░░█
█░░║║║╠─║─║─║║║║║╠─░░█
█░░╚╩╝╚╝╚╝╚╝╚╝╩─╩╚╝░░█
█▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█

👤Owner = @R23_VPNSTORE
──────────────────────
👤Chat ID  = `{user_id}`
💰Balance = Rp:`{saldo_aji}`
👤Members = `{get_user_count()}`
🌍Host = `{DOMAIN}`
──────────────────────
"""
                x = await event.edit(admin_msg, buttons=admin_inline)
                if not x:
                    await event.reply(admin_msg, buttons=admin_inline)

        except Exception as e:
            print(f"Error: {e}")

    else:
        await event.reply(
            f'**Siilahkan Registrasi Terlebih Dahulu**',
            buttons=[[(Button.inline("Registrasi", "registrasi"))]]
        )

