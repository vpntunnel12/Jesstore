from cybervpn import *
from telethon import events, Button
import requests
import subprocess

# URL for fetching the status content
url = "https://raw.githubusercontent.com/scriswan/fodder/main/statusku"

# Get status content from the URL
response = requests.get(url)
if response.status_code == 200:
    print(response.text)
else:
    print("Gagal mendapatkan konten dari URL")

# Handle the /start or /menu command
@bot.on(events.NewMessage(pattern=r"(?:.menu|/start|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def start_menu(event):
    user_id = str(event.sender_id)
    first_name = event.sender.first_name  # Fetch user's first name
    last_name = event.sender.last_name if event.sender.last_name else ""  # Fetch last name if available

    # Check if the user is registered
    if check_user_registration(user_id):
        try:
            saldo_aji, level = get_saldo_and_level_from_db(user_id)

            # Fetch location information
            try:
                location_info = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
            except requests.exceptions.RequestException as e:
                print(f"Error fetching location info: {e}")
                location_info = {"country": "Unknown", "region": "Unknown", "city": "Unknown", "isp": "Unknown"}

            # Get the number of SSH and VMESS accounts
            ssh_count = subprocess.check_output('cat /etc/passwd | grep "home" | grep "false" | wc -l', shell=True).decode("ascii").strip()
            vmess_count = subprocess.check_output('cat /etc/vmess/.vmess.db | grep "###" | wc -l', shell=True).decode("ascii").strip()

            # Regular user menu
            if level == "user":
                member_inline = [
                    [Button.inline("🔑 CREATE SSH 🔑", "create-ssh-member"),
                     Button.inline("🔑 CREATE VMESS 🔑", "create-vmess-member")],
                    [Button.inline("🛠️ TRIAL SSH 🛠️", "trial-ssh-member"),
                     Button.inline("🛠️ TRIAL VMESS 🛠️", "trial-vmess-member")],
                    [Button.inline("🔄 RENEW SSH 🔄", "renew-ssh-member"),
                     Button.inline("🔄 RENEW VMESS 🔄", "renew-vmess-member")],
                    [Button.url("⚙️ GROUP ⚙️", "https://t.me/vpnjabar"),
                     Button.url("👤 ADMIN 👤", "https://t.me/RiswanJabar")]
                ]

                member_msg = f"""
 **◇━━━━━━━━━━━━━━━━━◇**
 **»🔹VPN Resseller Bot**
 **◇━━━━━━━━━━━━━━━━━◇**
 **»🔹Location:** `{location_info["country"]}`
 **◇━━━━━━━━━━━━━━━━━◇**
 **»🔹Price Produk** 
 **»🔹Price SSH    Rp.5.000** 
 **»🔹Price VMESS  Rp.5.000** 
 **◇━━━━━━━━━━━━━━━━━◇**
 **»🔹SSH:** `{ssh_count} Account`
 **»🔹VMESS:** `{vmess_count} Account`
 **◇━━━━━━━━━━━━━━━━━◇**
 **»🔹User :** `{user_id}`
 **»🔹Total User :** `{get_user_count()}`
 **»🔹Your Saldo :** `{saldo_aji}`
 **◇━━━━━━━━━━━━━━━━━◇**
                """
                x = await event.edit(member_msg, buttons=member_inline)
                if not x:
                    await event.reply(member_msg, buttons=member_inline)

            # Admin menu
            elif level == "admin":
                admin_inline = [
                    [Button.url("🔒GRUP OWNER🔒", "https://t.me/vpnjabar")],
                    [Button.inline("💻SSH WS💻", "ssh"),
                     Button.inline("💻VMESS💻", "vmess")],
                    [Button.inline("📊INFO VPS📊", "info"),
                     Button.inline("⚙️SETTINGS⚙️", "setting")]
                ]
                
                admin_msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━**
**»🔹Khusus Admin RiswanStore🔹**
**━━━━━━━━━━━━━━━━━━━━━━**
**»🔹Host:** `{DOMAIN}`
**»🔹Location:** `{location_info["country"]}`
**━━━━━━━━━━━━━━━━━━━━━━**
**»🔹Price Produk** 
**»🔹Price SSH    Rp.10.000** 
**»🔹Price VMESS  Rp.10.000** 
**━━━━━━━━━━━━━━━━━━━━━━**
**»🔹SSH:** `{ssh_count} Account`
**»🔹VMESS:** `{vmess_count} Account`
**━━━━━━━━━━━━━━━━━━━━━━**
**»🔹ID Admin:** `{user_id}`
**»🔹Total User:** `{get_user_count()}`
**»🔹Saldo Admin: Rp.** `{saldo_aji}`
**━━━━━━━━━━━━━━━━━━━━━━**
                """
                x = await event.edit(admin_msg, buttons=admin_inline)
                if not x:
                    await event.reply(admin_msg, buttons=admin_inline)

        except Exception as e:
            print(f"Error: {e}")

    # User not registered
    else:
        await event.reply(
f'**━━━━━━━━━━━━━━━━━━━━━━**\n'
f'**Selamat Datang Member**\n\n'
f'**Nama:** {first_name} {last_name}\n\n'
f'**ID Anda:** `{user_id}`\n\n'
f'**Total Member:** `{get_user_count()}`\n\n'
f'**Harga Rp:** `5000`\n\n'
f'**Status:** `Aktif`\n\n'
f'**━━━━━━━━━━━━━━━━━━━━━━**\n\n'
f'**Layanan Anda:**\n'
f'**SSH:** `Aktif`\n' 
f'**VMESS:** `Aktif`\n' 
f'**━━━━━━━━━━━━━━━━━━━━━━**\n\n'
f'**Akses Ditolak:** Anda Bukan Member\n\n',
        buttons=[[
            Button.url("Hubungi Admin", "https://t.me/RiswanJabar")
        ]]
    )