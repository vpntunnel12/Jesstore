from cybervpn import *
from telethon import events, Button
import requests

url = "https://raw.githubusercontent.com/scriswan/fodder/main/statusku"

response = requests.get(url)


if response.status_code == 200:
    print(response.text)
else:
    print("Gagal mendapatkan konten dari URL")

@bot.on(events.NewMessage(pattern=r"(?:.menu|/start|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def start_menu(event):
    user_id = str(event.sender_id)

    if check_user_registration(user_id):
        try:
            saldo_aji, level = get_saldo_and_level_from_db(user_id)

            if level == "user":
                member_inline = [
                    [Button.inline("💳DEPOSIT💳", f"topup")],
                    Button.inline("PANEL SSH" "ssh"),
                    [Button.inline("PANEL VMESS" "vmess-member")],
                      
                   
                ]

                member_msg = f"""
█▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█
█░░╦─╦╔╗╦─╔╗╔╗╔╦╗╔╗░░█
█░░║║║╠─║─║─║║║║║╠─░░█
█░░╚╩╝╚╝╚╝╚╝╚╝╩─╩╚╝░░█
█▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█

Admin   : @R23_VPNSTORE
──────────────────────
Chat ID  : `{user_id}`
Balance : Rp:`{saldo_aji}`
──────────────────────
SSHWS   : RP 5000
VMESS    : RP 5000
──────────────────────
Trial      : NO LIMIT
──────────────────────
Status •¯•» Member
──────────────────────
Bonus   : 25x Transaction
Bonus   : Rp5000
──────────────────────
Bonus Rp5000 Setelah 25 TRX
──────────────────────
"""
                x = await event.edit(member_msg, buttons=member_inline)
                if not x:
                    await event.reply(member_msg, buttons=member_inline)


            elif level == "admin":
                admin_inline = [
                   [Button.inline("AKUN SSH", "ssh")],
                    [Button.inline("AKUN VMESS", "vmess"),
                     Button.inline("AKUN VLESS", "vless")],
                    [Button.inline("AKUN TROJAN", "trojan"),
                     Button.inline("ADD RESSLLER", "registrasi-member")],
                     [Button.inline("HAPUS RESSELLER", "delete-member")],
                     [Button.inline("DAFTAR RESSELER", "show-user")],
                    [Button.inline("ADD SALDO RESSELLER", "addsaldo")],
                    [Button.inline("CEK INFO VPS", "info"),
                     Button.inline("PENGATURAN", "setting")],
                    [Button.url("TELEGRAM", "https://t.me/R23_VPNSTORE"),
                     Button.url("WHATSAPP", "https://wa.me/6285888801241")]
                ]

                admin_msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━━**
           **≡ BOT RZ VPNSTORE ≡**
**━━━━━━━━━━━━━━━━━━━━━━━━**
**📊 Kuota Vpn: 1000GB**
**😭 Trial Vpn 1GB**
**🌐 Limit IP: 2HP**
**💵 Harga Resseler: Rp5,000**
**💵 Harga Members: Rp.10,000**
**🔢 Akun Yang Sudah Dibuat**
**🏷️ Tidak Bisa Di ganti lagi**
**━━━━━━━━━━━━━━━━━━━━━━━━**
**💰Minimal topup Rssseller**
**⚠️Join Rp.25,000**
**━━━━━━━━━━━━━━━━━━━━━━━━**
**🌍Host:** `{DOMAIN}`
**🪄Id User:** `{user_id}`
**💰Saldo user:** Rp.`{saldo_aji}`
**👤Resseller:** {get_user_count()}
**━━━━━━━━━━━━━━━━━━━━━━━━**
"""
                x = await event.edit(admin_msg, buttons=admin_inline)
                if not x:
                    await event.reply(admin_msg, buttons=admin_inline)

        except Exception as e:
            print(f"Error: {e}")

    else:
        await event.reply(
            f'**Siilahkan Registrasi Terlebih Dahulu**',
            buttons=[[(Button.inline("Registrasi", "registrasi"))]]
        )

