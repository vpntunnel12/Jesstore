from datetime import datetime
from cybervpn import *
from telethon import events, Button
import subprocess
import requests

# Fungsi untuk mengambil info user, lokasi, dan statistik akun
@bot.on(events.NewMessage(pattern=r"(?:.menu|/start|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def start_menu(event):
    user_id = str(event.sender_id)
    first_name = event.sender.first_name
    last_name = event.sender.last_name if event.sender.last_name else ""

    # Mendapatkan waktu saat ini
    current_time = datetime.now().strftime("%H:%M:%S")  # Format HH:MM:SS

    # Fungsi untuk mendapatkan informasi aktifitas VPS (Ini placeholder, sesuaikan jika diperlukan)
    def get_vps_active_days():
        try:
            # Misalnya: Anda bisa mengambil informasi ini dari server atau database Anda
            active_days = subprocess.check_output("uptime -p", shell=True).decode("utf-8").strip()  # Contoh
            return active_days
        except Exception as e:
            return "Unknown"

    vps_active_days = get_vps_active_days()

    # Fungsi untuk menghitung hanya akun VMess yang sebenarnya, mengecualikan akun trial
    def get_vmess_count():
        try:
            # Asumsikan akun trial ditandai dengan kata kunci "trial", bisa disaring untuk menghindarinya
            vmess_lines = subprocess.check_output('cat /etc/vmess/.vmess.db', shell=True).decode("ascii").splitlines()
            real_vmess_count = sum(1 for line in vmess_lines if "trial" not in line)  # Menghindari baris dengan 'trial'
            return str(real_vmess_count)
        except Exception as e:
            return "0"

    vmess_count = get_vmess_count()

    # Menghitung jumlah akun lainnya (SSH, VLESS, TROJAN)
    ssh_count = subprocess.check_output('cat /etc/passwd | grep "home" | grep "false" | wc -l', shell=True).decode("ascii").strip()
    vless_count = subprocess.check_output('cat /etc/vless/.vless.db | grep "###" | wc -l', shell=True).decode("ascii").strip()
    trojan_count = subprocess.check_output('cat /etc/trojan/.trojan.db | grep "###" | wc -l', shell=True).decode("ascii").strip()

    # Batas maksimal akun VMess
    max_vmess_accounts = 30

    # Menghitung sisa akun VMess
    remaining_vmess = max_vmess_accounts - int(vmess_count)

    # Mencoba mengambil informasi lokasi dari API IP
    try:
        location_info = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
    except requests.exceptions.RequestException as e:
        print(f"Error fetching location info: {e}")
        location_info = {"country": "Unknown", "region": "Unknown", "city": "Unknown", "isp": "Unknown"}

    city = location_info.get("city", "Unknown City")

    # Untuk pengguna biasa
    if check_user_registration(user_id):
        try:
            saldo_aji, level = get_saldo_and_level_from_db(user_id)

            # Untuk pengguna biasa
            if level == "user":
                member_inline = [
                    [Button.inline("📡 SSH Ws", "ssh"),
                     Button.inline("🌐 VMess", "vmess-member")],
                    [Button.inline("🔐 Vless", "vless-member"),
                     Button.inline("⚡ Trojan", "trojan-member")],
                    [Button.url("💬 Join Telegram", "https://t.me/vpnjabar")],
                    [Button.inline("💳 Top Up", f"topup")]
                ]

                member_msg = f"""

📦**Akun Tersedia:**
• **Akun SSH:** `{ssh_count} Akun`
• **Akun VLESS:** `{vless_count} Akun`
• **Akun VMESS:** `{vmess_count} Akun`
• **Akun TROJAN:** `{trojan_count} Akun`
**═════════════════════════**
🔑 **ID Anda:** `{user_id}`
🔢 **Total Reseller:** `{get_user_count()}`
💳 **Saldo:** `Rp.{saldo_aji}`
**═════════════════════════**

**═════════════════════════**
• **STOK AKUN VMESS 30**
• **Jumlah VMess:** `{vmess_count}`
• **Tersisa:** `{remaining_vmess}` Akun
**═════════════════════════**
        **By x 𝓡𝓲𝓼𝓮𝓻𝓲𝓯𝓱𝓪𝓷𝓱𝓪𝓳 𝓢𝓽𝓲𝓷𝓮 𝓔𝓿𝓷𝓮𝓯**
**═════════════════════════**
"""
                x = await event.edit(member_msg, buttons=member_inline)
                if not x:
                    await event.reply(member_msg, buttons=member_inline)

            # Untuk admin
            elif level == "admin":
                admin_inline = [
                    [Button.inline("🖥️SSH", "ssh"), Button.inline("🌐VMess", "vmess"), Button.inline("🔐Vless", "vless")],
                    [Button.inline("🛡️Trojan", "trojan"), Button.inline("⚙️Pengaturan", "setting")],
                    [Button.inline("📋Daftar Reseller", "show-user")],
                    [Button.inline("🗑️Hapus Reseller", "delete-member"), Button.inline("➕Tambah Reseller", "registrasi-member")],
                    [Button.inline("💰Tambah Saldo", "addsaldo")]
                ]

                admin_msg = f"""
**═════════════════════════**
**⚡Dashboard Admin - RiswanStore⚡**
**═════════════════════════**
📡 **Informasi Host:**
• **Host:** `{DOMAIN}`
• **ISP:** `{location_info["isp"]}`
• **Lokasi:** `{location_info["country"]}`
• **Kota:** `{city}`
**═════════════════════════**
**💸Daftar Harga Admin:**
**• Akun SSH:** `Rp.10.000`
**• Akun VLESS:** `Rp.10.000`
**• Akun VMESS:** `Rp.10.000`
**• Akun TROJAN:** `Rp.10.000`
**═════════════════════════**
🖥️**Informasi Akun:**
• **Akun SSH:** `{ssh_count} Akun`
• **Akun VLESS:** `{vless_count} Akun`
• **Akun VMESS:** `{vmess_count} Akun`
• **Akun TROJAN:** `{trojan_count} Akun`
**═════════════════════════**
📋**Informasi Admin:**
• **ID Admin:** `{user_id}`
• **Total Reseller:** `{get_user_count()}`
• **Saldo Admin:** `Rp.{saldo_aji}`
**═════════════════════════**
👑 **Status:** `Admin@gmail.com`
🕒 **Waktu:** `{current_time}`
🌍 **Aktif:** `{vps_active_days}`
**═════════════════════════**
**Akun VMESS Tersisa:** `{remaining_vmess} Akun Tersisa`
**═════════════════════════**
        **By x 𝓡𝓲𝓼𝓮𝓻𝓲𝓯𝓱𝓪𝓷𝓱𝓪𝓳 𝓢𝓽𝓲𝓷𝓮 𝓔𝓿𝓷𝓮𝓯**
**═════════════════════════**
"""
                x = await event.edit(admin_msg, buttons=admin_inline)
                if not x:
                    await event.reply(admin_msg, buttons=admin_inline)

        except Exception as e:
            print(f"Error: {e}")

    else:
        await event.reply(
f'**═════════════════════════**\n'
f'**Selamat datang di RiswanJabar Store🎉**\n'
f'**Nama:** {first_name} {last_name}\n'
f'**User ID:** `{user_id}`\n'
f'**Total Reseller:** `{get_user_count()}`\n'
f'**═════════════════════════**\n'
f'**Layanan Anda:**\n'
f'**SSH:** `Tersedia ✅`\n'
f'**VMess:** `Tersedia ✅`\n'
f'**VLess:** `Tersedia ✅`\n'
f'**Trojan:** `Tersedia ✅`\n'
f'**═════════════════════════**\n'
f'**Akses Ditolak:** `Anda bukan Reseller`🚫\n'
f'**═════════════════════════**\n'
f'**Ingin Bergabung sebagai Reseller? 🤔**\n'
f'**Modal Awal untuk Bergabung:** `Rp 30.000 💼`\n'
f'**Untuk Reseller:** `Rp 5.000 💸`\n'
f'**Untuk Member:** `Rp 10.000`\n'
f'**Harga Lebih Murah Setelah Menjadi Reseller 🏷️**\n'
f'**═════════════════════════**\n'
f'**💻 PAKET VPS SGDO 🇸🇬**\n'
f'**1️⃣GB RAM, 1 Core:** `IDR 35.000`🇸🇬\n'
f'**2️⃣GB RAM, 1 Core:** `IDR 37.000`🇸🇬\n'
f'**4️⃣GB RAM, 2 Core:** `IDR 55.000`🇸🇬\n'
f'**↪️Instalasi Gratis & Garansi 30 Hari**\n'
f'**↪️Setup Siap, Script Siap Dijual**\n'
f'**↪️Konfigurasi Lengkap**\n'
f'**═════════════════════════**\n',
buttons=[[
    Button.url("JOIN NOW?", "https://t.me/RiswanJabar")
]]
)