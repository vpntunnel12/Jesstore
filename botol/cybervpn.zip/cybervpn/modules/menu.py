from cybervpn import *
from telethon import events, Button
import requests

url = "https://raw.githubusercontent.com/scriswan/fodder/main/statusku"

response = requests.get(url)
if response.status_code == 200:
    print(response.text)
else:
    print("Gagal mendapatkan konten dari URL")

@bot.on(events.NewMessage(pattern=r"(?:.menu|/start|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def start_menu(event):
    user_id = str(event.sender_id)
    first_name = event.sender.first_name  # Fetch user's first name
    last_name = event.sender.last_name if event.sender.last_name else ""  # Fetch last name if available

    if check_user_registration(user_id):
        try:
            saldo_aji, level = get_saldo_and_level_from_db(user_id)
            
            # Safely fetch location info
            try:
                location_info = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
            except requests.exceptions.RequestException as e:
                print(f"Error fetching location info: {e}")
                location_info = {"country": "Unknown", "region": "Unknown", "city": "Unknown", "isp": "Unknown"}

            # Get the number of accounts for SSH, VMESS, VLESS, and TROJAN
            ssh_count = subprocess.check_output('cat /etc/passwd | grep "home" | grep "false" | wc -l', shell=True).decode("ascii").strip()
            vmess_count = subprocess.check_output('cat /etc/vmess/.vmess.db | grep "###" | wc -l', shell=True).decode("ascii").strip()
            vless_count = subprocess.check_output('cat /etc/vless/.vless.db | grep "###" | wc -l', shell=True).decode("ascii").strip()
            trojan_count = subprocess.check_output('cat /etc/trojan/.trojan.db | grep "###" | wc -l', shell=True).decode("ascii").strip()

            # For regular users
            if level == "user":
                member_inline = [
    [Button.inline(" CREATE SSH", "create-ssh-member"),
     Button.inline("CREATE VLESS", "create-vless-member")],
    [Button.inline("CREATE VMESS", "create-vmess-member"),
     Button.inline("CREATE TROJAN", "create-trojan-member")],

    [Button.inline("TRIAL SSH ", "trial-ssh-member"),
     Button.inline("TRIAL VLESS ", "trial-vless-member")],
    [Button.inline("TRIAL VMESS ", "trial-vmess-member"),
     Button.inline("TRIAL TROJAN ", "trial-trojan-member")],

    [Button.inline("RENEW SSH", "renew-ssh-member"),
     Button.inline("RENEW VLESS", "renew-vless-member")],
    [Button.inline("RENEW VMESS", "renew-vmess-member"),
     Button.inline("RENEW TROJAN", "renew-trojan-member")],

    [Button.url("GROUP", "https://t.me/vpnjabar"),
     Button.url("ADMIN", "https://t.me/RiswanJabar")]
]

                member_msg = f"""
**═════════════════════════**
**»🔹VPN Resseller Bot RiswanJabar**
**═════════════════════════**
**»🔹Location:** `{location_info["country"]}`
**═════════════════════════**
**»🔹Price Produk Reseller** 
**»🔹Price SSH    Rp.5.000** 
**»🔹Price VLESS  Rp.5.000** 
**»🔹Price VMESS  Rp.5.000** 
**»🔹Price TROJAN Rp.5.000** 
**═════════════════════════**
**»🔹𝚂𝚜𝚑:** `{ssh_count} Account`
**»🔹𝚅l𝚎𝚜𝚜:** `{vless_count} Account`
**»🔹𝚅m𝚎𝚜𝚜:** `{vmess_count} Account`
**»🔹𝚃𝚛𝚘𝚓𝚊𝚗:** `{trojan_count} Account`
**═════════════════════════**
**»🔹Status:** `Reseller`
**»🔹Id User  Anda:** `{user_id}`
**»🔹Total Reseller :** `{get_user_count()}`
**»🔹Your Saldo :** `{saldo_aji}`
**═════════════════════════**
**»🔹Trx 5x bonus** `10.000`
"""
                x = await event.edit(member_msg, buttons=member_inline)
                if not x:
                    await event.reply(member_msg, buttons=member_inline)

            # For admins
            elif level == "admin":
                admin_inline = [
    [Button.inline("Ssh ws", "ssh"), Button.inline("Vmess", "vmess"), Button.inline("Vless", "vless")],
    [Button.inline("Trojan", "trojan"), Button.inline("Setings", "setting"), Button.inline("Add saldo", "addsaldo")],
    [Button.inline("List Reseller", "show-user")],
    [Button.inline("Hapus Reseller", "delete-member")],
    [Button.inline("Add Admin X Reseller", "registrasi-member")]
]
                admin_msg = f"""
**═════════════════════════**
**»🔹Kusus Admin RiswanStore🔹**
**═════════════════════════**
**»🔹Host:** `{DOMAIN}`
**»🔹Location:** `{location_info["country"]}`
**═════════════════════════**
**»🔹Price Produk Admin** 
**»🔹Price SSH    Rp.10.000** 
**»🔹Price VLESS  Rp.10.000** 
**»🔹Price VMESS  Rp.10.000** 
**»🔹Price TROJAN Rp.10.000** 
**═════════════════════════**
**»🔹Ssh:** `{ssh_count} Account`
**»🔹Vless:** `{vless_count} Account`
**»🔹Vmess:** `{vmess_count} Account`
**»🔹Trojan:**    `{trojan_count} Account`
**═════════════════════════**
**»🔹ID Admin:** `{user_id}`
**»🔹Total Reseller** `{get_user_count()}`
**»🔹Saldo Admin: Rp.** `{saldo_aji}`
**═════════════════════════**
**»🔹Status:** `Admin`
**═════════════════════════**
"""
                x = await event.edit(admin_msg, buttons=admin_inline)
                if not x:
                    await event.reply(admin_msg, buttons=admin_inline)

        except Exception as e:
            print(f"Error: {e}")

    else:
        await event.reply(
f'**═════════════════════════**\n'
f'**Welcome To RiswanJabar Store🎉**\n'
f'**Nama:** {first_name} {last_name}\n'
f'**ID Anda:** `{user_id}`\n'
f'**Total Reseller:** `{get_user_count()}`\n'
f'**Harga:** `Rp 5.000 💰`\n'
f'**Status:** `Aktif ✅`\n'
f'**═════════════════════════**\n'
f'**Layanan Anda:**\n'
f'**SSH:** `Aktif ✅`\n'
f'**VMess:** `Aktif ✅`\n'
f'**VLess:** `Aktif ✅`\n'
f'**Trojan:** `Aktif ✅`\n'
f'**═════════════════════════**\n'
f'**Akses Ditolak:** `Anda Bukan Reseller` 🚫\n'
f'**═════════════════════════**\n'
f'**Tertarik Jadi Reseller?🤔**\n'
f'**Bergabung Sebagai Reseller:** `Rp 25.000💼`\n'
f'**Harga Khusus Reseller** `Rp 5.000💸`\n'
f'**Harga Khusus member** `Rp 10.000`\n'
f'**Harga Lebih Murah Setelah Bergabung🏷️**\n'
f'**═════════════════════════**\n'
f'**💻PAKET VPS SGDO 🇸🇬**\n'
f'**1️⃣GB RAM, 1 Core:** `IDR 35.000`🇸🇬\n'
f'**2️⃣GB RAM, 1 Core:** `IDR 37.000`🇸🇬\n'
f'**4️⃣GB RAM, 2 Core:** `IDR 55.000`🇸🇬\n'
f'**↪️ Free Instalasi & Garansi 30 Hari**\n'
f'**↪️ Setup Siap Pakai, Skrip Siap Jual**\n'
f'**↪️ Dengan Konfigurasi Lengkap**\n'
f'**═════════════════════════**\n',

buttons=[[
    Button.url("Join Disini Bosqu📨", "https://t.me/RiswanJabar")
]]
)