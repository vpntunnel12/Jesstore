from datetime import datetime
from cybervpn import *
from telethon import events, Button
import subprocess
import requests
from telethon.errors import UserNotParticipantError

# Grup yang harus dimiliki oleh pengguna
GROUP_USERNAME = tunnelingstore  # Ganti dengan nama grup yang sesuai

# Fungsi untuk mengambil info pengguna, lokasi, dan statistik akun
@bot.on(events.NewMessage(pattern=r"(?:.menu|/start|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def start_menu(event):
    user_id = str(event.sender_id)
    first_name = event.sender.first_name
    last_name = event.sender.last_name if event.sender.last_name else ""

    # Mendapatkan waktu saat ini
    current_time = datetime.now().strftime("%H:%M:%S")  # Format HH:MM:SS

    # Memeriksa apakah pengguna sudah menjadi anggota grup yang diperlukan
    try:
        # Memeriksa apakah pengguna adalah anggota grup
        user = await bot.get_entity(user_id)
        member = await bot.get_participant(GROUP_USERNAME, user_id)
    except UserNotParticipantError:
        # Jika pengguna belum bergabung, kirim pesan untuk bergabung dengan grup
        await event.reply(
            "Anda perlu bergabung dengan grup terlebih dahulu untuk mengakses layanan ini.\nSilakan bergabung dengan grup dan coba lagi.",
            buttons=[Button.url("Bergabung dengan Grup", f"https://t.me/{GROUP_USERNAME}")]
        )
        return

    # Fungsi untuk mendapatkan hari aktif VPS (Ini adalah placeholder, sesuaikan dengan kebutuhan)
    def get_vps_active_days():
        try:
            # Contoh: Anda bisa mengambil informasi ini dari server atau database Anda
            active_days = subprocess.check_output("uptime -p", shell=True).decode("utf-8").strip()  # Sebagai contoh
            return active_days
        except Exception as e:
            return "Tidak Diketahui"

    vps_active_days = get_vps_active_days()

    # Memeriksa apakah pengguna sudah terdaftar
    if check_user_registration(user_id):
        try:
            saldo_aji, level = get_saldo_and_level_from_db(user_id)

            # Mengambil info lokasi dengan aman
            try:
                location_info = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
            except requests.exceptions.RequestException as e:
                print(f"Terjadi kesalahan saat mengambil informasi lokasi: {e}")
                location_info = {"country": "Tidak Diketahui", "region": "Tidak Diketahui", "city": "Tidak Diketahui", "isp": "Tidak Diketahui"}

            # Mendapatkan statistik akun
            ssh_count = subprocess.check_output('cat /etc/passwd | grep "home" | grep "false" | wc -l', shell=True).decode("ascii").strip()
            vmess_count = subprocess.check_output('cat /etc/vmess/.vmess.db | grep "###" | wc -l', shell=True).decode("ascii").strip()
            vless_count = subprocess.check_output('cat /etc/vless/.vless.db | grep "###" | wc -l', shell=True).decode("ascii").strip()
            trojan_count = subprocess.check_output('cat /etc/trojan/.trojan.db | grep "###" | wc -l', shell=True).decode("ascii").strip()

            city = location_info.get("city", "Kota Tidak Diketahui")

            # Untuk pengguna biasa
            if level == "user":
                member_inline = [
                    [Button.inline("📡 SSH Ws", "ssh"),
                     Button.inline("🌐 VMess", "vmess-member")],
                    [Button.inline("🔐 Vless", "vless-member"),
                     Button.inline("⚡ Trojan", "trojan-member")],
                    [Button.url("💬 Bergabung dengan Telegram", "https://t.me/vpnjabar")],
                    [Button.inline("💳 Top Up", f"topup")]
                ]

                member_msg = f"""
**═════════════════════════**
 **⚡RiswanJabar - VPN Reseller Bot⚡**
**═════════════════════════**
🌐 **ISP:** `{location_info["isp"]}`
🏙️ **Lokasi:** `{location_info["country"]}`
📍 **Kota:** `{city}`
**═════════════════════════**
📦**Akun Tersedia:**
• **Akun SSH:** `{ssh_count} Akun`
• **Akun VLESS:** `{vless_count} Akun`
• **Akun VMESS:** `{vmess_count} Akun`
• **Akun TROJAN:** `{trojan_count} Akun`
**═════════════════════════**
🔑 **ID Anda:** `{user_id}`
🔢 **Total Reseller:** `{get_user_count()}`
💳 **Saldo:** `Rp.{saldo_aji}`
**═════════════════════════**
🎉 **Bonus Transaksi 10x:** `Rp.5,000`
👤 **Status:** `Reseller@gmail.com`
🕒 **Waktu:** `{current_time}`
**═════════════════════════**
        **By x 𝓡𝓲𝓼𝓮𝓻𝓲𝓯𝓱𝓪𝓷𝓱𝓪𝓳 𝓢𝓽𝓲𝓷𝓮 𝓔𝓿𝓷𝓮𝓯**
**═════════════════════════**
"""
                x = await event.edit(member_msg, buttons=member_inline)
                if not x:
                    await event.reply(member_msg, buttons=member_inline)

            # Untuk admin
            elif level == "admin":
                admin_inline = [
                    [Button.inline("🖥️SSH", "ssh"), Button.inline("🌐VMess", "vmess"), Button.inline("🔐Vless", "vless")],
                    [Button.inline("🛡️Trojan", "trojan"), Button.inline("⚙️Settings", "setting")],
                    [Button.inline("📋List Resellers", "show-user")],
                    [Button.inline("🗑️Hapus Reseller", "delete-member"), Button.inline("➕Tambah Reseller", "registrasi-member")],
                    [Button.inline("💰Tambah Saldo", "addsaldo")]
                ]

                admin_msg = f"""
**═════════════════════════**
**⚡Dashboard Admin - RiswanStore⚡**
**═════════════════════════**
📡 **Informasi Host:**
• **Host:** `{DOMAIN}`
• **ISP:** `{location_info["isp"]}`
• **Lokasi:** `{location_info["country"]}`
• **Kota:** `{city}`
**═════════════════════════**
**💸Daftar Harga Admin:**
**• Akun SSH:** `Rp.10.000`
**• Akun VLESS:** `Rp.10.000`
**• Akun VMESS:** `Rp.10.000`
**• Akun TROJAN:** `Rp.10.000`
**═════════════════════════**
🖥️**Informasi Akun:**
• **Akun SSH:** `{ssh_count} Akun`
• **Akun VLESS:** `{vless_count} Akun`
• **Akun VMESS:** `{vmess_count} Akun`
• **Akun TROJAN:** `{trojan_count} Akun`
**═════════════════════════**
📋**Informasi Admin:**
• **ID Admin:** `{user_id}`
• **Total Reseller:** `{get_user_count()}`
• **Saldo Admin:** `Rp.{saldo_aji}`
**═════════════════════════**
👑 **Status:** `Admin@gmail.com`
🕒 **Waktu:** `{current_time}`
🌍 **Aktif:** `{vps_active_days}`
**═════════════════════════**
        **By x 𝓡𝓲𝓼𝓮𝓻𝓲𝓯𝓱𝓪𝓷𝓱𝓪𝓳 𝓢𝓽𝓲𝓷𝓮 𝓔𝓿𝓷𝓮𝓯**
**═════════════════════════**
"""
                x = await event.edit(admin_msg, buttons=admin_inline)
                if not x:
                    await event.reply(admin_msg, buttons=admin_inline)

        except Exception as e:
            print(f"Error: {e}")

    else:
        await event.reply(
            f'**Silakan Registrasi Terlebih Dahulu**',
            buttons=[[(Button.inline("Registrasi", "registrasi"))]]
        )