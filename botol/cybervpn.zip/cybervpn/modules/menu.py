from cybervpn import *
from telethon import events, Button
import requests

url = "https://raw.githubusercontent.com/scriswan/fodder/main/statusku"

response = requests.get(url)
if response.status_code == 200:
    print(response.text)
else:
    print("Gagal mendapatkan konten dari URL")

@bot.on(events.NewMessage(pattern=r"(?:.menu|/start|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def start_menu(event):
    user_id = str(event.sender_id)

    if check_user_registration(user_id):
        try:
            saldo_aji, level = get_saldo_and_level_from_db(user_id)
            
            # Safely fetch location info
            try:
                location_info = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
            except requests.exceptions.RequestException as e:
                print(f"Error fetching location info: {e}")
                location_info = {"country": "Unknown", "region": "Unknown", "city": "Unknown", "isp": "Unknown"}

            # Get the number of accounts for SSH, VMESS, VLESS, and TROJAN
            ssh_count = subprocess.check_output('cat /etc/passwd | grep "home" | grep "false" | wc -l', shell=True).decode("ascii").strip()
            vmess_count = subprocess.check_output('cat /etc/vmess/.vmess.db | grep "###" | wc -l', shell=True).decode("ascii").strip()
            vless_count = subprocess.check_output('cat /etc/vless/.vless.db | grep "###" | wc -l', shell=True).decode("ascii").strip()
            trojan_count = subprocess.check_output('cat /etc/trojan/.trojan.db | grep "###" | wc -l', shell=True).decode("ascii").strip()

            # For regular users
            if level == "user":
                member_inline = [
                    [Button.inline("⚡SSH⚡", "ssh")],
                    [Button.inline("⚡VMESS⚡", "vmess-member"),
                     Button.inline("⚡VLESS⚡", "vless-member")],
                    [Button.inline("⚡TROJAN⚡", "trojan-member"),
                     Button.inline("💳TOPUP💳", f"topup")]
                ]

                member_msg = f"""
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
**»Hostname:** `{DOMAIN}`
**»ISP:** `{location_info["isp"]}`
**»Country:** `{location_info["country"]}`
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
             **🤖bot Penel Member🤖**
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
**2️⃣ Layanan Premium**
**🚀 Upgrade ke Premium Sekarang!**
**💰 Harga Spesial: Rp.8000**
**💵 Top-up Minimum Rp.8000** 
**⚠️ untuk Mendapatkan Keuntungan**
**🔒 Cek Akun Premium Saya**
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
**🔧 Status Layanan ➢ ** `Online` 🟢
**🖥 SSH Status:** `{get_ssh_status()}`
**🌐 XRay Status:** `{get_xray_status()}`
**🔄 UDP Status:** `{get_udp_status()}`
**🛡️ Dropbear Status:** `{get_dropbear_status()}`
**🌐 webSocket Status:** `{get_ws_status()}`
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
**📈 Versi bot:** `V 4.7`
**🆔 ID Pengguna Anda:** `{user_id}`
**💸 Saldo Anda:** `{saldo_aji}`
**📊 Jumlah Akun:**
- **SSH:** `{ssh_count}` akun
- **VMESS:** `{vmess_count}` akun
- **VLESS:** `{vless_count}` akun
- **TROJAN:** `{trojan_count}` akun
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
"""
                x = await event.edit(member_msg, buttons=member_inline)
                if not x:
                    await event.reply(member_msg, buttons=member_inline)

            # For admins
            elif level == "admin":
                admin_inline = [
                    [Button.inline("𝗦𝗦𝗛 𝗢𝗩𝗣𝗡", "ssh"),
                     Button.inline("𝗩𝗠𝗘𝗦𝗦", "vmess")],
                    [Button.inline("𝗩𝗟𝗘𝗦𝗦", "vless"),
                     Button.inline("𝗧𝗥𝗢𝗝𝗔𝗡", "trojan")],
                    [Button.inline("𝗔𝗗𝗗 𝗠𝗘𝗠𝗕𝗘𝗥", "registrasi-member")],
                    [Button.inline("𝗛𝗣𝗨𝗦 𝗠𝗘𝗠𝗕𝗘𝗥", "delete-member"),
                     Button.inline("𝗟𝗜𝗦𝗧 𝗠𝗘𝗠𝗕𝗘𝗥", "show-user")],
                    [Button.inline("𝗔𝗗𝗗 𝗦𝗔𝗟𝗗𝗢", "addsaldo")],
                    [Button.inline("𝗜𝗡𝗙𝗢 𝗩𝗣𝗦", "info"),
                     Button.inline("𝗦𝗘𝗧𝗜𝗡𝗚𝗦", "setting")],
                    [Button.url("𝗧𝗘𝗟𝗘𝗚𝗥𝗔𝗠", "https://t.me/Riswanvpnstore"),
                     Button.url("𝗪𝗛𝗔𝗧𝗦𝗔𝗣𝗣", "https://wa.me/6285888801241")]
                ]
                
                admin_msg = f"""
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
**»Hostname:** `{DOMAIN}`
**»ISP:** `{location_info["isp"]}`
**»Country:** `{location_info["country"]}`
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
                  **🤖bot panel admin🤖**
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
**🔧Service Status ➢** `Online` 🟢
**🖥SSH Status:** `{get_ssh_status()}`
**🌐XRay Status:** `{get_xray_status()}`
**🔄UDP Status:** `{get_udp_status()}`
**🛡️Dropbear Status:** `{get_dropbear_status()}`
**🌐webSocket Status:** `{get_ws_status()}`
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
**📈Version:** `v5.7.7`
**🆔Your ID User:** `{user_id}`
**💸Your Balance RP.** `{saldo_aji}`
**👤Total Pengguna:** `{get_user_count()}`
**📊 Jumlah Akun:**
- **SSH:** `{ssh_count}` akun
- **VMESS:** `{vmess_count}` akun
- **VLESS:** `{vless_count}` akun
- **TROJAN:** `{trojan_count}` akun
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
"""
                x = await event.edit(admin_msg, buttons=admin_inline)
                if not x:
                    await event.reply(admin_msg, buttons=admin_inline)

        except Exception as e:
            print(f"Error: {e}")

    else:
        await event.reply(
            f' `Siilahkan Registrasi Terlebih Dahulu` ',
            buttons=[[(Button.inline("Registrasi", "registrasi"))]]
        )