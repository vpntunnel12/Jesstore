from cybervpn import *
from telethon import events, Button
import requests

url = "https://raw.githubusercontent.com/scriswan/fodder/main/statusku"

response = requests.get(url)


if response.status_code == 200:
    print(response.text)
else:
    print("Gagal mendapatkan konten dari URL")

@bot.on(events.NewMessage(pattern=r"(?:.menu|/start|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def start_menu(event):
    user_id = str(event.sender_id)

    if check_user_registration(user_id):
        try:
            saldo_aji, level = get_saldo_and_level_from_db(user_id)

            if level == "user":
                member_inline = [
                    [Button.inline("⚡SSH⚡", "ssh")],
                    [Button.inline("⚡VMESS⚡", "vmess-member"),
                     Button.inline("⚡VLESS⚡", "vless-member")],
                     [Button.inline("⚡TROJAN⚡", "trojan-member"),
                      Button.inline("💳TOPUP💳", f"topup")]
                   
                ]

                member_msg = f"""
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
          **🌐 CyberVPN Bot Menu 🌐**
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
**1️⃣ Akun Premium VIP**
**🔑 Buat Akun Baru**
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
**3️⃣ Layanan Premium**
**🚀 Upgrade ke Premium**
**💰 Harga Paket Rp.8000**
**💵 Min Top-up Rp.8000**
**🔒 Akun Premium Saya**
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
**4️⃣ Informasi Pengguna**
**📆 Masa Aktif Akun: 30 days**
**5️⃣ Bantuan & Support**
**❓ FAQ**
**🛠️ Hubungi Admin:** @R23_VPNSTORE
**📜 Panduan Penggunaan**
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
**🔧Service Status ➢** `Online` 🟢
**🖥SSH Status:** `{get_ssh_status()}`
**🌐XRay Status:** `{get_xray_status()}`
**🔄UDP Status:** `{get_udp_status()}`
**🛡️Dropbear Status:** `{get_dropbear_status()}`
**🌐webSocket Status:** `{get_ws_status()}`
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
**📈Version:** `v5.7.7`
**🆔Your ID User:** `{user_id}`
**💸Your Balance RP.** `{saldo_aji}`
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
"""
                x = await event.edit(member_msg, buttons=member_inline)
                if not x:
                    await event.reply(member_msg, buttons=member_inline)


            

            elif level == "admin":
                admin_inline = [
                    [Button.inline("Panel SSH", "ssh")],
                    [Button.inline("panel VMESS", "vmess"),
                     Button.inline("panel VLESS", "vless")],
                    [Button.inline("panel TRJAN", "trojan"),
                     Button.inline("panel SS -R", "shadowsocks")],
                    [Button.inline("panel NOOBZ", "noobzvpns"),
                     Button.inline("ADD MEMBER", "registrasi-member"),
                     Button.inline("DEL MEMBER", "delete-member")],
                     [Button.inline("LIST MEMBER", "show-user")],
                    [Button.inline("💰ADD MONEY💰 ", "addsaldo")],
                    [Button.inline("👙CHECKING VPS👙", "info"),
                     Button.inline("👙FEATURES SET👙", "setting")],
                    [Button.url("📩Whatsapp📩", "https://wa.me/6285888801241"),
                     Button.url("📤BuyScript📤", "https://wa.me/6285888801241")]
                ]
                
                admin_msg = f"""
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
                  **🤖 BOT MENU 🤖**
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
**🔧Service Status ➢** `Online` 🟢
**🖥SSH Status:** `{get_ssh_status()}`
**🌐XRay Status:** `{get_xray_status()}`
**🔄UDP Status:** `{get_udp_status()}`
**🛡️Dropbear Status:** `{get_dropbear_status()}`
**🌐webSocket Status:** `{get_ws_status()}`
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
**📈Version:** `v5.7.7`
**🆔Your ID User:** `{user_id}`
**💸Your Balance RP.** `{saldo_aji}`
**👤Total Pengguna:** `{get_user_count()}`
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
"""
                x = await event.edit(admin_msg, buttons=admin_inline)
                if not x:
                    await event.reply(admin_msg, buttons=admin_inline)

        except Exception as e:
            print(f"Error: {e}")

    else:
        await event.reply(
            f' `Siilahkan Registrasi Terlebih Dahulu` ',
            buttons=[[(Button.inline("Registrasi", "registrasi"))]]
        )

