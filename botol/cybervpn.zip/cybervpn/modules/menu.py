from datetime import datetime
from cybervpn import *
from telethon import events, Button
import subprocess
import requests

# Function to fetch user info, location, and account statistics
@bot.on(events.NewMessage(pattern=r"(?:.menu|/start|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def start_menu(event):
    user_id = str(event.sender_id)
    first_name = event.sender.first_name
    last_name = event.sender.last_name if event.sender.last_name else ""

    # Get the current time
    current_time = datetime.now().strftime("%H:%M:%S")  # Format as HH:MM:SS

    # Function to get VPS active days (This is a placeholder, adjust it as needed)
    def get_vps_active_days():
        try:
            # Example: You can fetch this information from your server/database
            active_days = subprocess.check_output("uptime -p", shell=True).decode("utf-8").strip()  # Just as an example
            return active_days
        except Exception as e:
            return "Unknown"

    vps_active_days = get_vps_active_days()

    # Check if the user is registered
    if check_user_registration(user_id):
        try:
            saldo_aji, level = get_saldo_and_level_from_db(user_id)

            # Safely fetch location info
            try:
                location_info = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
            except requests.exceptions.RequestException as e:
                print(f"Error fetching location info: {e}")
                location_info = {"country": "Unknown", "region": "Unknown", "city": "Unknown", "isp": "Unknown"}

            # Get account statistics
            ssh_count = subprocess.check_output('cat /etc/passwd | grep "home" | grep "false" | wc -l', shell=True).decode("ascii").strip()
            vmess_count = subprocess.check_output('cat /etc/vmess/.vmess.db | grep "###" | wc -l', shell=True).decode("ascii").strip()
            vless_count = subprocess.check_output('cat /etc/vless/.vless.db | grep "###" | wc -l', shell=True).decode("ascii").strip()
            trojan_count = subprocess.check_output('cat /etc/trojan/.trojan.db | grep "###" | wc -l', shell=True).decode("ascii").strip()

            city = location_info.get("city", "Unknown City")

            # For regular users
            if level == "user":
                member_inline = [
                    [Button.inline("📡 SSH Ws", "ssh"),
                     Button.inline("🌐 VMess", "vmess-member")],
                    [Button.inline("🔐 Vless", "vless-member"),
                     Button.inline("⚡ Trojan", "trojan-member")],
                    [Button.url("💬 Join Telegram", "https://t.me/RiswanJabar")],
                    [Button.inline("💳 Top Up", f"topup")]
                ]

                member_msg = f"""
**═════════════════════════**
🔹 **RiswanJabar - VPN Reseller Bot**
**═════════════════════════**
🌐 **ISP:** `{location_info["isp"]}`
🏙️ **Location:** `{location_info["country"]}`
📍 **City:** `{city}`
**═════════════════════════**
💵 **Product Prices:**
    • **SSH:** `Rp.5.000`
    • **VLESS:** `Rp.5.000`
    • **VMESS:** `Rp.5.000`
    • **TROJAN:** `Rp.5.000`
**═════════════════════════**
📦 **Available Accounts:**
• **SSH Accounts:** `{ssh_count} Account`
• **VLESS Accounts:** `{vless_count} Account`
• **VMESS Accounts:** `{vmess_count} Account`
• **TROJAN Accounts:** `{trojan_count} Account`
**═════════════════════════**
🔑 **Your ID:** `{user_id}`
🔢 **Total Resellers:** `{get_user_count()}`
💳 **Balance:** `Rp. {saldo_aji}`
**═════════════════════════**
🎉 **Bonus Transaction x7:** `Rp.10,000`
👤 **Your Status:** `Reseller`
🕒 **Time:** `{current_time}`
🌍 **Active For:** `{vps_active_days}`
**═════════════════════════**
   **☞ó ͜つò☞ 𝓡𝓲𝓼𝓮𝓻𝓲𝓯𝓱𝓪𝓷𝓱𝓪𝓳 𝓢𝓽𝓲𝓷𝓮 𝓔𝓿𝓷𝓮𝓯**
**═════════════════════════**
"""
                x = await event.edit(member_msg, buttons=member_inline)
                if not x:
                    await event.reply(member_msg, buttons=member_inline)

            # For admins
            elif level == "admin":
                admin_inline = [
    [Button.inline("SSH", "ssh"), Button.inline("VMess", "vmess"), Button.inline("Vless", "vless")],
    [Button.inline("Trojan", "trojan"), Button.inline("Settings", "setting"), Button.inline("Add Balance", "addsaldo")],
    [Button.inline("List Resellers", "show-user"), Button.inline("Add Wallet", "wallet")],
    [Button.inline("Delete Reseller", "delete-member"), Button.inline("Add or Reseller", "registrasi-member")]
]

                admin_msg = f"""
**═════════════════════════**
**🔹 Admin Dashboard - RiswanStore 🔹**
**═════════════════════════**
📡 **Host Information:**
• **Host:** `{DOMAIN}`
• **ISP:** `{location_info["isp"]}`
• **Location:** `{location_info["country"]}`
• **City:** `{city}`
**═════════════════════════**
🖥️ **Account Information:**
• **SSH Accounts:** `{ssh_count} Account`
• **VLESS Accounts:** `{vless_count} Account`
• **VMESS Accounts:** `{vmess_count} Account`
• **TROJAN Accounts:** `{trojan_count} Account`
**═════════════════════════**
📋 **Admin Information:**
• **Admin ID:** `{user_id}`
• **Total Resellers:** `{get_user_count()}`
• **Admin Balance:** `Rp.{saldo_aji}`
**═════════════════════════**
👑 **Status:** `Admin`
🕒 **Time:** `{current_time}`
🌍 **Active For:** `{vps_active_days}`
**═════════════════════════**
   **☞ó ͜つò☞ 𝓡𝓲𝓼𝓮𝓻𝓲𝓯𝓱𝓪𝓷𝓱𝓪𝓳 𝓢𝓽𝓲𝓷𝓮 𝓔𝓿𝓷𝓮𝓯**
**═════════════════════════**
"""
                x = await event.edit(admin_msg, buttons=admin_inline)
                if not x:
                    await event.reply(admin_msg, buttons=admin_inline)

        except Exception as e:
            print(f"Error: {e}")

    else:
        await event.reply(
f'**═════════════════════════**\n'
f'**Welcome to RiswanJabar Store🎉**\n'
f'**Name:** {first_name} {last_name}\n'
f'**User ID:** `{user_id}`\n'
f'**Total Resellers:** `{get_user_count()}`\n'
f'**═════════════════════════**\n'
f'**Your Services:**\n'
f'**SSH:** `Available ✅`\n'
f'**VMess:** `Available ✅`\n'
f'**VLess:** `Available ✅`\n'
f'**Trojan:** `Available ✅`\n'
f'**═════════════════════════**\n'
f'**Access Denied:** `You are not a Reseller`🚫\n'
f'**═════════════════════════**\n'
f'**Want to Join as a Reseller? 🤔**\n'
f'**Initial Capital to Join:** `Rp 30.000 💼`\n'
f'**For Resellers:** `Rp 5.000 💸`\n'
f'**For Members:** `Rp 10.000`\n'
f'**Better Prices After Becoming Reseller 🏷️**\n'
f'**═════════════════════════**\n'
f'**💻 VPS PACKAGES SGDO 🇸🇬**\n'
f'**1️⃣GB RAM, 1 Core:** `IDR 35.000`🇸🇬\n'
f'**2️⃣GB RAM, 1 Core:** `IDR 37.000`🇸🇬\n'
f'**4️⃣GB RAM, 2 Core:** `IDR 55.000`🇸🇬\n'
f'**↪️Free Installation & 30-Day Guarantee**\n'
f'**↪️Setup Ready, Script Ready to Sell**\n'
f'**↪️Complete Configuration**\n'
f'**═════════════════════════**\n',
buttons=[[
    Button.url("JOIN NOW?", "https://t.me/RiswanJabar")
]]
)