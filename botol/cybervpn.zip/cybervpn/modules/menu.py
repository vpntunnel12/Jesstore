from cybervpn import *
from telethon import events, Button
import requests

from telethon import events, Button
import requests

# Mock data for account counts
ssh_accounts = ['ssh_account1', 'ssh_account2', 'ssh_account3']
vmess_accounts = ['vmess_account1', 'vmess_account2']
vless_accounts = ['vless_account1', 'vless_account2', 'vless_account3', 'vless_account4']
trojan_accounts = ['trojan_account1']

# Functions to return the number of accounts for each service
def get_ssh_account_count():
    return len(ssh_accounts)

def get_vmess_account_count():
    return len(vmess_accounts)

def get_vless_account_count():
    return len(vless_accounts)

def get_trojan_account_count():
    return len(trojan_accounts)

# Fetch location info
url = "http://ip-api.com/json/?fields=country,region,city,timezone,isp"
response = requests.get(url)
location_info = response.json() if response.status_code == 200 else {}

# Bot event handler for '/start' or '/menu'
@bot.on(events.NewMessage(pattern=r"(?:.menu|/start|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def start_menu(event):
    user_id = str(event.sender_id)

    # Mock data for user balance and level (replace with your own logic)
    saldo_aji = "10000"
    level = "user"  # Can be 'user' or 'admin'

    # Fetch account counts
    ssh_count = get_ssh_account_count()
    vmess_count = get_vmess_account_count()
    vless_count = get_vless_account_count()
    trojan_count = get_trojan_account_count()

    # Message structure based on user level
    if level == "user":
        member_inline = [
            [Button.inline("⚡SSH⚡", "ssh")],
            [Button.inline("⚡VMESS⚡", "vmess-member"), Button.inline("⚡VLESS⚡", "vless-member")],
            [Button.inline("⚡TROJAN⚡", "trojan-member"), Button.inline("💳TOPUP💳", f"topup")]
        ]

        member_msg = f"""
        **☉━━━━━━━━━━━━━━━━━━━━━━━☉**
        **»Hostname:** `{DOMAIN}`
        **»ISP:** `{location_info["isp"]}`
        **»Country:** `{location_info["country"]}`
        **☉━━━━━━━━━━━━━━━━━━━━━━━☉**
        **🤖bot Penel Member🤖**
        **☉━━━━━━━━━━━━━━━━━━━━━━━☉**
        **2️⃣ Layanan Premium**
        **🚀 Upgrade ke Premium Sekarang!**
        **💰 Harga Spesial: Rp.8000**
        **💵 Top-up Minimum Rp.8000** 
        **⚠️ untuk Mendapatkan Keuntungan**
        **🔒 Cek Akun Premium Saya**
        **☉━━━━━━━━━━━━━━━━━━━━━━━☉**
        **🔧 Status Layanan ➢ ** `Online` 🟢
        **🖥 SSH Status:** `{get_ssh_status()}`
        **🌐 XRay Status:** `{get_xray_status()}`
        **🔄 UDP Status:** `{get_udp_status()}`
        **🛡️ Dropbear Status:** `{get_dropbear_status()}`
        **🌐 webSocket Status:** `{get_ws_status()}`
        **☉━━━━━━━━━━━━━━━━━━━━━━━☉**
        **📈 Versi bot:** `V 4.7`
        **🆔 ID Pengguna Anda:** `{user_id}`
        **💸 Saldo Anda:** `{saldo_aji}`
        **☉━━━━━━━━━━━━━━━━━━━━━━━☉**
        **📊 Jumlah Akun:**
        **SSH:** `{ssh_count}`
        **VMESS:** `{vmess_count}`
        **VLESS:** `{vless_count}`
        **TROJAN:** `{trojan_count}`
        **☉━━━━━━━━━━━━━━━━━━━━━━━☉**
        """
        x = await event.edit(member_msg, buttons=member_inline)
        if not x:
            await event.reply(member_msg, buttons=member_inline)

    elif level == "admin":
        admin_inline = [
            [Button.inline("𝗦𝗦𝗛 𝗢𝗩𝗣𝗡", "ssh"), Button.inline("𝗩𝗠𝗘𝗦𝗦", "vmess")],
            [Button.inline("𝗩𝗟𝗘𝗦𝗦", "vless"), Button.inline("𝗧𝗥𝗢𝗝𝗔𝗡", "trojan")],
            [Button.inline("𝗔𝗗𝗗 𝗠𝗘𝗠𝗕𝗘𝗥", "registrasi-member")],
            [Button.inline("𝗛𝗣𝗨𝗦 𝗠𝗘𝗠𝗕𝗘𝗥", "delete-member"), Button.inline("𝗟𝗜𝗦𝗧 𝗠𝗘𝗠𝗕𝗘𝗥", "show-user")],
            [Button.inline("𝗔𝗗𝗗 𝗦𝗔𝗟𝗗𝗢", "addsaldo")],
            [Button.inline("𝗜𝗡𝗙𝗢 𝗩𝗣𝗦", "info"), Button.inline("𝗦𝗘𝗧𝗜𝗡𝗚𝗦", "setting")],
            [Button.url("𝗧𝗘𝗟𝗘𝗚𝗥𝗔𝗠", "https://t.me/Riswanvpnstore"), Button.url("𝗪𝗛𝗔𝗧𝗦𝗔𝗣𝗣", "https://wa.me/6285888801241")]
        ]

        admin_msg = f"""
        **☉━━━━━━━━━━━━━━━━━━━━━━━☉**
        **»Hostname:** `{DOMAIN}`
        **»ISP:** `{location_info["isp"]}`
        **»Country:** `{location_info["country"]}`
        **☉━━━━━━━━━━━━━━━━━━━━━━━☉**
        **🤖bot panel admin🤖**
        **☉━━━━━━━━━━━━━━━━━━━━━━━☉**
        **🔧Service Status ➢** `Online` 🟢
        **🖥SSH Status:** `{get_ssh_status()}`
        **🌐XRay Status:** `{get_xray_status()}`
        **🔄UDP Status:** `{get_udp_status()}`
        **🛡️Dropbear Status:** `{get_dropbear_status()}`
        **🌐webSocket Status:** `{get_ws_status()}`
        **☉━━━━━━━━━━━━━━━━━━━━━━━☉**
        **📈Version:** `v5.7.7`
        **🆔Your ID User:** `{user_id}`
        **💸Your Balance RP.** `{saldo_aji}`
        **👤Total Pengguna:** `{get_user_count()}`
        **☉━━━━━━━━━━━━━━━━━━━━━━━☉**
        **📊 Jumlah Akun:**
        **SSH:** `{ssh_count}`
        **VMESS:** `{vmess_count}`
        **VLESS:** `{vless_count}`
        **TROJAN:** `{trojan_count}`
        **☉━━━━━━━━━━━━━━━━━━━━━━━☉**
        """
        x = await event.edit(admin_msg, buttons=admin_inline)
        if not x:
            await event.reply(admin_msg, buttons=admin_inline)