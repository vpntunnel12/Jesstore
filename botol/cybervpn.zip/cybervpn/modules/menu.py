from cybervpn import *
from telethon import events, Button
import requests

url = "https://raw.githubusercontent.com/scriswan/fodder/main/statusku"

response = requests.get(url)
if response.status_code == 200:
    print(response.text)
else:
    print("Gagal mendapatkan konten dari URL")

@bot.on(events.NewMessage(pattern=r"(?:.menu|/start|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def start_menu(event):
    user_id = str(event.sender_id)
    first_name = event.sender.first_name  # Fetch user's first name
    last_name = event.sender.last_name if event.sender.last_name else ""  # Fetch last name if available

    if check_user_registration(user_id):
        try:
            saldo_aji, level = get_saldo_and_level_from_db(user_id)
            
            # Safely fetch location info
            try:
                location_info = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
            except requests.exceptions.RequestException as e:
                print(f"Error fetching location info: {e}")
                location_info = {"country": "Unknown", "region": "Unknown", "city": "Unknown", "isp": "Unknown"}

            # Get the number of accounts for SSH, VMESS, VLESS, and TROJAN
            ssh_count = subprocess.check_output('cat /etc/passwd | grep "home" | grep "false" | wc -l', shell=True).decode("ascii").strip()
            vmess_count = subprocess.check_output('cat /etc/vmess/.vmess.db | grep "###" | wc -l', shell=True).decode("ascii").strip()
            vless_count = subprocess.check_output('cat /etc/vless/.vless.db | grep "###" | wc -l', shell=True).decode("ascii").strip()
            trojan_count = subprocess.check_output('cat /etc/trojan/.trojan.db | grep "###" | wc -l', shell=True).decode("ascii").strip()

            # For regular users
            if level == "user":
                member_inline = [
    [Button.inline("⚡SSH⚡", "ssh")],
    [Button.inline("⚡VMESS⚡", "vmess-member"),
     Button.inline("⚡VLESS⚡", "vless-member")],
    [Button.inline("⚡TROJAN⚡", "trojan-member")],
    [Button.url("⚙️GRUOP⚙️", "https://t.me/grupvpnriswan"),
     Button.url("👤ADMIN👤", "https://t.me/R23_VPNSTORE")] 
]

                member_msg = f"""

**Selamat Datang di Member VPN Kami!**

**Terima kasih telah bergabung dengan** 
**layanan VPN kami. Di sini, Anda akan** 
**menikmati akses cepat dan aman ke** 
**internet dengan berbagai pilihan** 
**SSH, VMESS, VLESS, dan TROJAN.** 
**Nikmati pengalaman browsing** 
**tanpa hambatan dan pastikan** 
**data Anda tetap aman.**

**Jika ada pertanyaan atau bantuan** 
**yang Anda butuhkan, jangan ragu**
**untuk menghubungi kami. Kami** 
**siap membantu Anda!**

**Semoga pengalaman Anda**
**menyenankan dan aman!**

**🌐Host:** `{DOMAIN}`
**🌐ISP:** `{location_info["isp"]}`
**🌐Location:** `{location_info["country"]}`

**🖥️Jumlah Akun Tersedia**
**🛒Ssh:** `{ssh_count}` `account`
**🛒Vmess:** `{vmess_count}` `account`
**🛒Vless:**       `{vless_count}` `account`
**🛒Trojan:**        `{trojan_count}` `account`

**👤 Informasi Pengguna 👤**
**↪️Nama Member :** `{first_name} {last_name}`
**↪️ID Member :** `{user_id}`
**↪️Total Member :** `{get_user_count()}`
**↪️Saldo Anda: Rp.** `{saldo_aji}`

**📡 Versi Bot:** `4.5`

"""
                x = await event.edit(member_msg, buttons=member_inline)
                if not x:
                    await event.reply(member_msg, buttons=member_inline)

            # For admins
            elif level == "admin":
                admin_inline = [
                 [Button.url("⚙️GRUP OWNER⚙️", "https://t.me/grupvpnriswan")],
                  [Button.inline("⚡SSH WS⚡", "ssh"),
                     Button.inline("⚡VMESS⚡", "vmess")],
                     
                    [Button.inline("⚡VLESS⚡", "vless"),
                    Button.inline("⚡TROJAN⚡", "trojan")],
                    [Button.inline("⚙️INFO VPS⚙️", "info"),
                     Button.inline("⚙️SETINGS⚙️", "setting")],
                ]
                
                admin_msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━**
              **🔶Admin Riswan🔶**
**━━━━━━━━━━━━━━━━━━━━━━**
**»🏷️Host:** `{DOMAIN}`
**»🏷️ISP:** `{location_info["isp"]}`
**»🏷️Location:** `{location_info["country"]}`
**━━━━━━━━━━━━━━━━━━━━━━**
**🖥️ Jumlah Akun Tersedia**
**»🛒Ssh:** `{ssh_count}` `account`
**»🛒Vmess:** `{vmess_count}` `account`
**»🛒Vless:**       `{vless_count}` `account`
**»🛒Trojan:**        `{trojan_count}` `account`
**━━━━━━━━━━━━━━━━━━━━━━**
**👤 Informasi Pengguna 👤**
**» Admin:** `{first_name} {last_name}`
**» ID Admin:** `{user_id}`
**» Total Pengguna:** `{get_user_count()}`
**» Saldo Anda: Rp.** `{saldo_aji}`
**━━━━━━━━━━━━━━━━━━━━━━**
**📡 Versi Bot:** `4.5`
**━━━━━━━━━━━━━━━━━━━━━━**
"""
                x = await event.edit(admin_msg, buttons=admin_inline)
                if not x:
                    await event.reply(admin_msg, buttons=admin_inline)

        except Exception as e:
            print(f"Error: {e}")

    else:
        await event.reply(
    f' `Akses Ditolak: Anda Bukan Member` ',
    buttons=[[(Button.url("Hubungi Admin", "https://t.me/R23_VPNSTORE"))]]
)