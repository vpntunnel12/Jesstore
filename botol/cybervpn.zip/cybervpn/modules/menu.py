from datetime import datetime
from cybervpn import *
from telethon import events, Button
import subprocess
import requests

# Function to fetch user info, location, and account statistics
@bot.on(events.NewMessage(pattern=r"(?:.menu|/start|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def start_menu(event):
    user_id = str(event.sender_id)
    first_name = event.sender.first_name
    last_name = event.sender.last_name if event.sender.last_name else ""

    # Get the current time
    current_time = datetime.now().strftime("%H:%M:%S")  # Format as HH:MM:SS

    # Function to get VPS active days (This is a placeholder, adjust it as needed)
    def get_vps_active_days():
        try:
            # Example: You can fetch this information from your server/database
            active_days = subprocess.check_output("uptime -p", shell=True).decode("utf-8").strip()  # Just as an example
            return active_days
        except Exception as e:
            return "Unknown"

    vps_active_days = get_vps_active_days()

    # Check if the user is registered
    if check_user_registration(user_id):
        try:
            saldo_aji, level = get_saldo_and_level_from_db(user_id)

            # Safely fetch location info
            try:
                location_info = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
            except requests.exceptions.RequestException as e:
                print(f"Error fetching location info: {e}")
                location_info = {"country": "Unknown", "region": "Unknown", "city": "Unknown", "isp": "Unknown"}

            # Get account statistics
            ssh_count = subprocess.check_output('cat /etc/passwd | grep "home" | grep "false" | wc -l', shell=True).decode("ascii").strip()
            vmess_count = subprocess.check_output('cat /etc/vmess/.vmess.db | grep "###" | wc -l', shell=True).decode("ascii").strip()
            vless_count = subprocess.check_output('cat /etc/vless/.vless.db | grep "###" | wc -l', shell=True).decode("ascii").strip()
            trojan_count = subprocess.check_output('cat /etc/trojan/.trojan.db | grep "###" | wc -l', shell=True).decode("ascii").strip()

            city = location_info.get("city", "Unknown City")

            # For regular users
            if level == "user":
                member_inline = [
    [Button.inline("📡 SSH Ws", "ssh"), Button.inline("🌐 VMess", "vmess-member")],
    [Button.inline("🔐 Vless", "vless-member"), Button.url("💬 Join Grup", "https://t.me/vpnjabar")],
    [Button.inline("💳 Top Up", "topup")]
]
                member_msg = f"""
**═════════════════════════**
 **⚡RiswanJabar - VPN Reseller Bot⚡**
**═════════════════════════**
🌐 **ISP:** `{location_info["isp"]}`
🏙️ **Location:** `{location_info["country"]}`
📍 **City:** `{city}`
**═════════════════════════**
💵**Product Prices Resellers:**
**• SSH Accounts:** `Rp.5.000`
**• VLESS Accounts:** `Rp.7.000`
**• VMESS Accounts:** `Rp.7.000`
**═════════════════════════**
📦**Available Accounts:**
• **SSH Accounts:** `{ssh_count} Account`
• **VLESS Accounts:** `{vless_count} Account`
• **VMESS Accounts:** `{vmess_count} Account`
**═════════════════════════**
🔑 **Your ID:** `{user_id}`
🔢 **Total Resellers:** `{get_user_count()}`
💳 **Balance:** `Rp.{saldo_aji}`
**═════════════════════════**
**🔥setiap kali melakukan transaksi,**
**🔥bonus saldo yang diterima bersifat**
**🔥acak, jadi jumlahnya bisa berbeda**
**═════════════════════════**
👤 **Status:** `Reseller@gmail.com`
🕒 **Time:** `{current_time}`
**═════════════════════════**
        **By x 𝓡𝓲𝓼𝓮𝓻𝓲𝓯𝓱𝓪𝓷𝓱𝓪𝓳 𝓢𝓽𝓲𝓷𝓮 𝓔𝓿𝓷𝓮𝓯**
**═════════════════════════**
"""
                x = await event.edit(member_msg, buttons=member_inline)
                if not x:
                    await event.reply(member_msg, buttons=member_inline)

 # Untuk admin
            elif level == "admin":
                admin_inline = [
                    [Button.inline("🖥️SSH", "ssh"), Button.inline("🌐VMess", "vmess"), Button.inline("🔐Vless", "vless")],
                    [Button.inline("🛡️Trojan", "trojan"), Button.inline("⚙️Pengaturan", "setting")],
                    [Button.inline("📋Daftar Reseller", "show-user")],
                    [Button.inline("🗑️Hapus Reseller", "delete-member"), Button.inline("➕Tambah Reseller", "registrasi-member")],
                    [Button.inline("💰Tambah Saldo", "addsaldo")]
                ]
                admin_msg = f"""
**═════════════════════════**
**⚡Admin Dashboard - RiswanStore⚡**
**═════════════════════════**
📡 **Host Information:**
• **Host:** `{DOMAIN}`
• **ISP:** `{location_info["isp"]}`
• **Location:** `{location_info["country"]}`
• **City:** `{city}`
**═════════════════════════**
**💸Price List Admin:**
**• SSH Accounts:** `Rp.10.000`
**• VLESS Accounts:** `Rp.10.000`
**• VMESS Accounts:** `Rp.10.000`
**• TROJAN Accounts:** `Rp.10.000`
**═════════════════════════**
🖥️**Account Information:**
• **SSH Accounts:** `{ssh_count} Account`
• **VLESS Accounts:** `{vless_count} Account`
• **VMESS Accounts:** `{vmess_count} Account`
• **TROJAN Accounts:** `{trojan_count} Account`
**═════════════════════════**
📋**Admin Information:**
• **Admin ID:** `{user_id}`
• **Total Resellers:** `{get_user_count()}`
• **Admin Balance:** `Rp.{saldo_aji}`
**═════════════════════════**
👑 **Status:** `Admin@gmail.com`
🕒 **Time:** `{current_time}`
🌍 **Active:** `{vps_active_days}`
**═════════════════════════**
        **By x 𝓡𝓲𝓼𝓮𝓻𝓲𝓯𝓱𝓪𝓷𝓱𝓪𝓳 𝓢𝓽𝓲𝓷𝓮 𝓔𝓿𝓷𝓮𝓯**
**═════════════════════════**
"""
                x = await event.edit(admin_msg, buttons=admin_inline)
                if not x:
                    await event.reply(admin_msg, buttons=admin_inline)

        except Exception as e:
            print(f"Error: {e}")

    else:
        await event.reply(
            f'**Siilahkan Registrasi Terlebih Dahulu**',
            buttons=[[(Button.inline("Registrasi", "registrasi"))]]
        )

