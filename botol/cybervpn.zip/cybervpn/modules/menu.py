from cybervpn import *
from telethon import events, Button
import requests
from datetime import datetime, timedelta

# URL to fetch data from (you might use this or a similar one for your bot)
url = "https://raw.githubusercontent.com/scriswan/fodder/main/statusku"

response = requests.get(url)
if response.status_code == 200:
    print(response.text)
else:
    print("Gagal mendapatkan konten dari URL")

from datetime import datetime, timedelta
import subprocess
import requests

@bot.on(events.NewMessage(pattern=r"(?:.menu|/start|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def start_menu(event):
    user_id = str(event.sender_id)
    first_name = event.sender.first_name  # Ambil nama depan pengguna
    last_name = event.sender.last_name if event.sender.last_name else ""  # Ambil nama belakang jika ada

    if check_user_registration(user_id):
        try:
            saldo_aji, level = get_saldo_and_level_from_db(user_id)
            
            # Mengambil informasi lokasi dengan aman
            try:
                location_info = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
            except requests.exceptions.RequestException as e:
                print(f"Error fetching location info: {e}")
                location_info = {"country": "Unknown", "region": "Unknown", "city": "Unknown", "isp": "Unknown"}

            # Mengambil jumlah akun untuk SSH, VMESS, VLESS, dan TROJAN
            ssh_count = subprocess.check_output('cat /etc/passwd | grep "home" | grep "false" | wc -l', shell=True).decode("ascii").strip()
            vmess_count = subprocess.check_output('cat /etc/vmess/.vmess.db | grep "###" | wc -l', shell=True).decode("ascii").strip()
            vless_count = subprocess.check_output('cat /etc/vless/.vless.db | grep "###" | wc -l', shell=True).decode("ascii").strip()
            trojan_count = subprocess.check_output('cat /etc/trojan/.trojan.db | grep "###" | wc -l', shell=True).decode("ascii").strip()

            # Mengambil tanggal pembuatan VPS
            creation_date = get_vps_creation_date(user_id)
            remaining_days = calculate_remaining_days(creation_date, validity_days=30)  # 30 adalah masa aktif VPS dalam hari

            # Untuk pengguna biasa
            if level == "user":
                member_inline = [
                    [Button.inline("Buat ssh", "create-ssh-member"),
                     Button.inline("Buat vless", "create-vless-member")],
                    [Button.inline("Buat vmess", "create-vmess-member"),
                     Button.inline("Buat trojan", "create-trojan-member")],

                    [Button.inline("Trial ssh", "trial-ssh-member"),
                     Button.inline("Trial vless", "trial-vless-member")],
                    [Button.inline("Trial vmess", "trial-vmess-member"),
                     Button.inline("Trial trojan", "trial-trojan-member")],

                    [Button.inline("Renew ssh", "renew-ssh-member"),
                     Button.inline("Renew vless", "renew-vless-member")],
                    [Button.inline("Renew vmess", "renew-vmess-member"),
                     Button.inline("Renew trojan", "renew-trojan-member")],

                    [Button.url("GROUP", "https://t.me/vpnjabar"),
                     Button.url("ADMIN", "https://t.me/RiswanJabar")]
                ]

                member_msg = f"""
**═════════════════════════**
🔹 **VPN Reseller Bot - RiswanJabar**
**═════════════════════════**
🌐 **ISP:** `{location_info["isp"]}`
🌍 **Lokasi:** `{location_info["country"]}`
🏙️ **Kota:** `{location_info["city"]}`
**═════════════════════════**
💵 **Harga Produk Reseller:**
- **SSH:** `Rp.5.000`
- **VLESS:** `Rp.5.000`
- **VMESS:** `Rp.5.000`
- **TROJAN:** `Rp.5.000`
**═════════════════════════**
📦 **Jumlah Akun Tersedia:**
- **Akun SSH:** `{ssh_count} Akun`
- **Akun VLESS:** `{vless_count} Akun`
- **Akun VMESS:** `{vmess_count} Akun`
- **Akun TROJAN:** `{trojan_count} Akun`
**═════════════════════════**
👤 **Status Akun:** `Reseller`
👤 **Nama:** `{first_name} {last_name}`
🔑 **ID Anda:** `{user_id}`
🔢 **Total Reseller:** `{get_user_count()}`
💳 **Saldo Anda:** `{saldo_aji}`
**═════════════════════════**
🎉 **Bonus Trx 5x:** `Rp 10,000`
**═════════════════════════**
"""
                x = await event.edit(member_msg, buttons=member_inline)
                if not x:
                    await event.reply(member_msg, buttons=member_inline)

            # Untuk admin
            elif level == "admin":
                admin_inline = [
                    [Button.inline("Ssh ws", "ssh"), Button.inline("Vmess", "vmess"), Button.inline("Vless", "vless")],
                    [Button.inline("Trojan", "trojan"), Button.inline("Setings", "setting"), Button.inline("Add saldo", "addsaldo")],
                    [Button.inline("List Reseller", "show-user")],
                    [Button.inline("Hapus Reseller", "delete-member")],
                    [Button.inline("Add Admin X Reseller", "registrasi-member")]
                ]
                admin_msg = f"""
**═════════════════════════**
**🔹 Dashboard Admin - RiswanStore 🔹**
**═════════════════════════**
**📡 Informasi Host:**
**• Host:** `{DOMAIN}`
**• ISP:** `{location_info["isp"]}`
**• Lokasi:** `{location_info["country"]}`
**• Kota:** `{location_info["city"]}`
**═════════════════════════**
**💸Daftar Harga:**
**• SSH:** `Rp.10.000`
**• VLESS:** `Rp.10.000`
**• VMESS:** `Rp.10.000`
**• TROJAN:** `Rp.10.000`
**═════════════════════════**
**🖥️ Informasi Akun:**
**• Akun SSH:** `{ssh_count} Akun`
**• Akun VLESS:** `{vless_count} Akun`
**• Akun VMESS:** `{vmess_count} Akun`
**• Akun TROJAN:** `{trojan_count} Akun`
**═════════════════════════**
**📋Info Admin:**
**• Nama:** `{first_name} {last_name}`
**• ID Admin:** `{user_id}`
**• Total Reseller:** `{get_user_count()}`
**• Saldo Admin Rp:** `{saldo_aji}`
**═════════════════════════**
**🎯 Aksi Admin:**
**• 1. Kelola Akun**
**• 2. Cek Reseller**
**• 3. Tambah Saldo**
**• 4. Lihat Log**
**═════════════════════════**
**👑 Status:** `Admin`
**═════════════════════════**
"""
                x = await event.edit(admin_msg, buttons=admin_inline)
                if not x:
                    await event.reply(admin_msg, buttons=admin_inline)

        except Exception as e:
            print(f"Error: {e}")

    else:
        await event.reply(
f'**═════════════════════════**\n'
f'**Selamat Datang di RiswanJabar Store🎉**\n'
f'**Nama:** {first_name} {last_name}\n'
f'**ID Pengguna:** `{user_id}`\n'
f'**Total Reseller:** `{get_user_count()}`\n'
f'**═════════════════════════**\n'
f'**Layanan Anda:**\n'
f'**SSH:** `Tersedia ✅`\n'
f'**VMess:** `Tersedia ✅`\n'
f'**VLess:** `Tersedia ✅`\n'
f'**Trojan:** `Tersedia ✅`\n'
f'**═════════════════════════**\n'
f'**Ditolak:** `Anda Bukan Reseller`🚫\n'
f'**═════════════════════════**\n'
f'**Ingin Bergabung Sebagai Reseller?🤔**\n'
f'**Modal Awal Join:** `Rp 30.000💼`\n'
f'**Khusus Reseller:** `Rp 5.000💸`\n'
f'**Kusus Member:** `Rp 10.000`\n'
f'**Harga Lebih Murah Setelah**\n'
f'**Menjadi Reseller🏷️**\n'
f'**═════════════════════════**\n'
f'**💻PAKET VPS SGDO 🇸🇬**\n'
f'**1️⃣GB RAM, 1 Core:** `IDR 35.000`🇸🇬\n'
f'**2️⃣GB RAM, 1 Core:** `IDR 37.000`🇸🇬\n'
f'**4️⃣GB RAM, 2 Core:** `IDR 55.000`🇸🇬\n'
f'**↪️Gratis Instalasi & Garansi 30 Hari**\n'
f'**↪️Setup Siap Pakai, Skrip Siap Dijual**\n'
f'**↪️Dengan Konfigurasi Lengkap**\n'
f'**═════════════════════════**\n',
buttons=[[
    Button.url("JOIN SEKARANG ?", "https://t.me/RiswanJabar")
]]
)