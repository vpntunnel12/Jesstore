from cybervpn import *
import subprocess
import datetime as DT
import sys
from telethon.sync import TelegramClient
import sqlite3

@bot.on(events.CallbackQuery(data=b'create-ssh-member'))
async def create_ssh(event):
    user_id = str(event.sender_id)
    
    async def create_ssh_(event):
        # Collect Username
        async with bot.conversation(chat) as user_conv:
            await event.respond('**Username:**')
            user_msg = await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = user_msg.raw_text.strip()

        # Collect Password
        async with bot.conversation(chat) as pw_conv:
            await event.respond("**Password:**")
            pw_msg = await pw_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            pw = pw_msg.raw_text.strip()

        # Collect Expiry Duration
        async with bot.conversation(chat) as exp_conv:
            await event.respond("**Expired:**", buttons=[
                [Button.inline("30 Day", "30")]
            ])
            exp_msg = await exp_conv.wait_event(events.CallbackQuery)
            exp = int(exp_msg.data.decode("ascii"))

        # Collect IP Limit
        async with bot.conversation(chat) as ip_conv:
            await event.respond("**Limit IP:**", buttons=[
                [Button.inline("2 IP", "2")]
            ])
            ip_msg = await ip_conv.wait_event(events.CallbackQuery)
            ip = int(ip_msg.data.decode("ascii"))

        # Process the user balance (Ensure this function is defined elsewhere)
        await process_user_balance_ssh(event, user_id)

        # Execute useradd command
        cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
        try:
            subprocess.check_output(cmd, shell=True)
        except subprocess.CalledProcessError as e:
            await event.respond("**User Already Exists or Error in User Creation**")
            return
        
        # Prepare expiration date
        today = DT.date.today()
        later = today + DT.timedelta(days=exp)
        
        # Prepare the response message
        msg = f"""
**═════════════════════════**
            **❞CREATE SSH WS❞**
**═════════════════════════**
**❞Host:**  `{DOMAIN}`
**❞Username:**  `{user}`
**❞Password:**  `{pw}`
**═════════════════════════**
**❞UDP CUSTOM:**
`{DOMAIN}:1-65535@{user}:{pw}`
**═════════════════════════**
**❞SSH CUSTOM:**
`{DOMAIN}:80@{user}:{pw}`
**═════════════════════════**
**❞Payload WebSocket⟩**
```GET /cdn-cgi/trace HTTP/1.1[crlf]Host: Bug_Kalian[crlf][crlf]GET-RAY / HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]```
**═════════════════════════**
**❞Expired on:** `{later}`
**═════════════════════════**
☞ó ‌つò☞ 𝓡𝓲𝓼𝔀𝓪𝓷𝓙𝓪𝓫𝓪𝓻 𝓢𝓽𝓸𝓻𝓮
**═════════════════════════**
"""
        # Send the response message
        await event.respond(msg, buttons=inline)
    
    # Main event handler
    chat = event.chat_id
    sender = await event.get_sender()
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await create_ssh_(event)
        else:
            await event.answer(f'Akses Ditolak.!!', alert=True)
    except Exception as e:
        print(f'Error: {e}')
        await event.respond("An error occurred while fetching user level or creating SSH.")