from cybervpn import *
import requests
import subprocess
import time
import datetime as DT
import re

@bot.on(events.CallbackQuery(data=b'create-vless'))
async def create_vless(event):
    async def create_vless_(event):
        # Get username from user
        async with bot.conversation(chat) as user_conv:
            await event.respond('**Username :**')
            user = (await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        # Get expiration date from user
        async with bot.conversation(chat) as exp_conv:
            await event.respond('**Expired:**')
            exp = (await exp_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        # Get login IP from user
        async with bot.conversation(chat) as login_ip_conv:
            await event.respond('**Login IP:**')
            login_ip = (await login_ip_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        await event.edit("`Wait.. Setting up an Account`")
        cmd = f'printf "%s\n" "{user}" "{exp}" "{Quota}" "{login_ip}" | addvless-bot'
        
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            await event.respond(f"Terjadi kesalahan: {e}")
            return  # Stop execution if there's an error

        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))
        x = [x.group() for x in re.finditer("vless://(.*)", a)]
        
        if x:
            uuid = re.search("vless://(.*?)@", x[0]).group(1)
            msg = f"""
**═════════════════════════**
            **XRAY/VLESS ACCOUNT**
**═════════════════════════**
**Remarks:** `{user}`
**Host:** `{DOMAIN}`
**Limit IP:** `{login_ip}` **IP**
**Expired on:** `{later}`
**═════════════════════════**
**Port TLS:** `443`
**Port NTLS:** `80` `8080`
**Port DNS:** `443` `53`
**Port gRPC:** `443`
**Security:** `auto`
**Network:** `(WS) or (gRPC)`
**Path:** `/vless`
**Servicename:** `vless-grpc`
**UUID:** `{uuid}`
**═════════════════════════**
**VLESS TLS:**
```{x[0]}```
**═════════════════════════**
**VLESS NON-TLS:**
```{x[1].replace(" ","")}```
**═════════════════════════**
**VLESS GRPC:**
```{x[2].replace(" ","")}```
**═════════════════════════**
            """
            await event.respond(msg)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        if level == 'admin':
            await create_vless_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        await event.respond(f'Error: {e}')

# Other event handlers such as 'cek-vless', 'renew-vless', etc., can be structured similarly.