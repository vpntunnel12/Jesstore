from cybervpn import *
import sqlite3
import datetime as DT
import subprocess
import random
import re
import base64
import json
import time
from telethon import events

# ... (kode lainnya)


from telethon import Button, events
import json
import base64
import time
import subprocess
import datetime as DT
import re

# Variabel konfigurasi
MAX_ACCOUNTS = 30  # Maksimal akun yang dapat dibuat oleh setiap pengguna
DOMAIN = "riswan.rasiya.cloud"  # Ganti dengan domain Anda
total_account_count = 0  # Variabel global untuk jumlah total akun yang telah dibuat

# Fungsi untuk mendapatkan jumlah akun yang telah dibuat oleh pengguna dari database (atau variabel sementara)
def get_user_account_count(user_id):
    # Logika untuk mengambil jumlah akun dari database atau tempat penyimpanan data
    # Bisa menggunakan database atau penyimpanan file, untuk sementara kita simulasikan dengan angka
    return 0  # Ubah ini dengan logika penyimpanan yang sesuai

# Fungsi untuk menambah jumlah akun yang telah dibuat oleh pengguna
def increment_user_account_count(user_id):
    # Logika untuk menambah jumlah akun yang telah dibuat oleh pengguna
    pass  # Implementasikan penyimpanan di sini

# Fungsi untuk menambah jumlah total akun yang telah dibuat
def increment_total_account_count():
    global total_account_count
    total_account_count += 1

# Menu utama dengan tombol inline
@bot.on(events.CallbackQuery(data=b'menu-vmess'))
async def menu_vmess(event):
    # Membuat menu interaktif dengan tombol inline
    buttons = [
        [Button.inline("💼 Buat Akun VMess", "create-vmess-member")],
        [Button.inline("📋 Cek Akun Saya", "check-my-accounts")],
        [Button.inline("❌ Keluar", "exit-menu")]
    ]
    await event.respond("**Menu Member VMess**\nPilih opsi di bawah:", buttons=buttons)

# Aksi ketika memilih tombol 'Buat Akun VMess'
@bot.on(events.CallbackQuery(data=b'create-vmess-member'))
async def create_vmess(event):
    async def create_vmess_(event):
        user_id = str(event.sender_id)

        # Mengecek apakah pengguna sudah mencapai batas pembuatan akun (30 akun)
        if get_user_account_count(user_id) >= MAX_ACCOUNTS:
            await event.respond("Anda telah mencapai batas pembuatan akun (30 akun). Tidak dapat membuat akun lagi.")
            return

        # Percakapan dengan pengguna untuk username
        async with bot.conversation(event.chat_id) as user_conv:
            await event.respond('**Username:**')
            user = (await user_conv.wait_event(events.NewMessage(incoming=True, from_users=event.sender_id))).raw_text

        # Percakapan dengan pengguna untuk masa aktif akun (exp)
        async with bot.conversation(event.chat_id) as exp_conv:
            await event.respond("**Pilih Masa Aktif (Hari)**", buttons=[
                [Button.inline(" 30 Hari ", "30")]
            ])
            exp = (await exp_conv.wait_event(events.CallbackQuery)).data.decode("ascii")

        # Percakapan dengan pengguna untuk batasan IP
        async with bot.conversation(event.chat_id) as ip_conv:
            await event.respond("**Pilih Batas IP**", buttons=[
                [Button.inline(" 2 IP ", "2")]
            ])
            ip = (await ip_conv.wait_event(events.CallbackQuery)).data.decode("ascii")

        # Simulasi proses pembuatan akun
        await event.edit("`Tunggu sebentar... Menyiapkan Akun VMess`")
        await event.edit("Memproses..")
        await event.edit("Memproses...")
        time.sleep(1)
        await event.edit("`Memproses Akun Premium`")
        time.sleep(1)
        await event.edit("`Memproses... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Memproses... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Memproses... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Memproses... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Memproses... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Memproses... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Memproses... 84%\n█████████████████████▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Memproses... 100%\n█████████████████████████ `")

        # Menghasilkan akun VMess menggunakan perintah subprocess
        cmd = f'printf "%s\n" "{user}" "{exp}" "1000" "{ip}" | addws-bot'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            print(f'Error: {e}')
            await event.respond(f"Terjadi kesalahan: {e}")
            return

        # Persiapkan tanggal dan ekstrak informasi VMess
        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))
        creation_date = today.strftime('%Y-%m-%d')

        b = [x.group() for x in re.finditer("vmess://(.*)", a)]

        z = base64.b64decode(b[0].replace("vmess://", "")).decode("ascii")
        z = json.loads(z)

        # Format dan kirim pesan kepada pengguna
        msg = f"""
**═════════════════════════**
**⚡BUAT AKUN VMESS PREMIUM⚡**
**═════════════════════════**
**Remarks:** `{user}`
**Host Server:** `{DOMAIN}`
**Login:** `2` **IP**
**Port TLS:** `443, 400-900`
**Port NTLS:** `80, 8080, 8081-9999 `
**UUID:** `{z["id"]}`
**NetWork:** `(WS) atau (gRPC)`
**Path:** `/vmess`
**ServiceName:** `vmess-grpc`
**═════════════════════════**
**VMESS URL TLS:**
```{b[0].strip("'").replace(" ","")}```
**═════════════════════════**
**VMESS URL HTTP:**
```{b[1].strip("'").replace(" ","")}```
**═════════════════════════**
**VMESS URL gRPC:** 
```{b[2].strip("'")}```
**═════════════════════════**
**🗓️Tanggal Pembuatan:** `{creation_date}`
**🗓️Aktip Sampai Tanggal:** `{later}`
**🗓️Durasi:** `{exp}`  **days**
**═════════════════════════**
**☞ó ‌つò☞ 𝓡𝓲𝓼𝓮 𝓙𝓪𝓫𝓪𝓻 𝓢𝓽𝓸𝓻𝓮**
**═════════════════════════**
"""
        await event.respond(msg)

        # Menambahkan jumlah akun yang dibuat oleh pengguna dan jumlah total akun yang dibuat
        increment_user_account_count(user_id)
        increment_total_account_count()

        # Menampilkan jumlah total akun yang telah dibuat
        print(f"Total akun yang telah dibuat: {total_account_count}")

    await create_vmess_(event)

# Aksi ketika memilih tombol 'Cek Akun Saya'
@bot.on(events.CallbackQuery(data=b'check-my-accounts'))
async def check_my_accounts(event):
    user_id = str(event.sender_id)

    # Ambil jumlah akun yang telah dibuat oleh pengguna
    user_account_count = get_user_account_count(user_id)

    # Kirimkan informasi akun yang telah dibuat
    if user_account_count > 0:
        await event.respond(f"Anda telah membuat **{user_account_count}** akun VMess.")
    else:
        await event.respond("Anda belum membuat akun VMess apapun.")

# Aksi ketika memilih tombol 'Keluar'
@bot.on(events.CallbackQuery(data=b'exit-menu'))
async def exit_menu(event):
    await event.respond("Terima kasih telah menggunakan layanan kami! Sampai jumpa.")