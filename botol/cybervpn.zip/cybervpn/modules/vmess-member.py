from cybervpn import *
import sqlite3
import datetime as DT
import subprocess
import random
import re
import base64
import json
import time
from telethon import events

# ... (kode lainnya)


@bot.on(events.CallbackQuery(data=b'create-vmess-member'))
async def create_vmess(event):
    async def create_vmess_(event):
        async with bot.conversation(chat) as user_conv:
            await event.respond('**Username:**')
            user = (await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text


        async with bot.conversation(chat) as exp_conv:
            await event.respond("**Choose Expiry Day**", buttons=[
                [Button.inline(" 30 Day ", "30")]
            ])
            exp = (await exp_conv.wait_event(events.CallbackQuery)).data.decode("ascii")

        async with bot.conversation(chat) as ip_conv:
            await event.respond("**Choose IP limit**", buttons=[
                [Button.inline(" 2 IP ", "2")]
            ])
            ip = (await ip_conv.wait_event(events.CallbackQuery)).data.decode("ascii")



            await event.edit("`Wait.. Setting up a VMess Account`")


        await event.edit("Processing..")
        await event.edit("Processing...")
        await event.edit("Processing....")
        time.sleep(1)
        await event.edit("`Processing Create Premium Account`")
        time.sleep(1)
        await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 100%\n█████████████████████████ `")
        await event.edit("`akun mu ini`")
        await process_user_balance_vmess(event, user_id)

        cmd = f'printf "%s\n" "{user}" "{exp}" "1000" "{ip}" | addws-bot'
        
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            print(f'Error: {e}')
            print(f'Subprocess output: {a}')
            await event.respond(f"An error occurred: {e}\nSubprocess output: {a}")
            return  # Stop execution if there's an error

        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))
        b = [x.group() for x in re.finditer("vmess://(.*)", a)]

        z = base64.b64decode(b[0].replace("vmess://", "")).decode("ascii")
        z = json.loads(z)

        z1 = base64.b64decode(b[1].replace("vmess://", "")).decode("ascii")
        z1 = json.loads(z1)

        msg = f"""
**•─────────────⚝─────────────•**
                      **❞CREATE VMESS❞**
**•─────────────⚝─────────────•**
**❞Remarks :** `{user}`
**❞Host Server :** `{DOMAIN}`
**❞Port TLS    :** `443, 400-900`
**❞Port NTLS   :** `80, 8080, 8081-9999 `
**❞UUID    :** `{z["id"]}`
**❞NetWork     :** `(WS) or (gRPC)`
**❞Path        :** `/vmess`
**❞ServiceName :** `vmess-grpc`
**•─────────────⚝─────────────•**
**❞VMESS URL TLS:**
```{b[0].strip("'").replace(" ","")}```
**•─────────────⚝─────────────•**
**❞VMESS URL HTTP:**
```{b[1].strip("'").replace(" ","")}```
**•─────────────⚝─────────────•**
**❞VMESS URL gRPC:** 
```{b[2].strip("'")}```
**•─────────────⚝─────────────•**
**❞Notes pelangan**
**❞simpan detail pembelian akun**
**❞sebagai garansi. kirimkan detail** 
**❞pembelian akun ke admin untuk** 
**❞pengecekan ketika terjadi masalah**
**❞pada config**
**❞Exp jatuh pada:** `{later}`
**•─────────────⚝─────────────•**
**» ** 🤖@R23_VPNSTORE
        """
        await event.respond(msg)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await create_vmess_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')


# TRIAL VMESS
@bot.on(events.CallbackQuery(data=b'trial-vmess-member'))
async def trial_vmess(event):
    user_id = str(event.sender_id)
    pw = "1"
    exp = "2"
    ip = "2000"
    # Database connection
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()

    # Create table if it doesn't exist
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            user_id TEXT PRIMARY KEY,
            has_trial INTEGER DEFAULT 0,
            last_trial_date TEXT
        )
    ''')
    conn.commit()

    # Function to check if user can trial again today
    def can_user_trial_again(user_id):
        cursor.execute('SELECT last_trial_date FROM users WHERE user_id = ?', (user_id,))
        result = cursor.fetchone()
        today = DT.date.today().isoformat()

        if result is None:
            # If user does not exist in the database, add them
            cursor.execute('INSERT INTO users (user_id, has_trial, last_trial_date) VALUES (?, ?, ?)', (user_id, 0, None))
            conn.commit()
            return True  # User has never trialed, allow trial

        last_trial_date = result[0]

        if last_trial_date is None or last_trial_date != today:
            # If user hasn't trialed today, allow trial
            return True

        # User has already trialed today
        return False

    # Function to mark today's trial date
    def mark_user_trial_today(user_id):
        today = DT.date.today().isoformat()
        cursor.execute('UPDATE users SET last_trial_date = ? WHERE user_id = ?', (today, user_id))
        conn.commit()

    async def trial_vmess_(event):
        # Loading animation
        await event.edit("Processing.")
        await event.edit("Processing..")
        await event.edit("Processing...")
        await event.edit("Processing....")
        time.sleep(1)
        await event.edit("`Processing Create Premium Account`")
        time.sleep(1)

        # Output command
        cmd = f'printf "%s\n" "Riswan-Ssh`</dev/urandom tr -dc X-Z0-9 | head -c4`" "1" "2000" "2000" | bot-trialws'

        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            print(f'Error: {e}')
            await event.respond(f"An error occurred: {e}")
            return  # Stop execution if there's an error

        today = DT.date.today()
        later = today + DT.timedelta(days=2)
        b = [x.group() for x in re.finditer("vmess://(.*)", a)]

        z = base64.b64decode(b[0].replace("vmess://", "")).decode("ascii")
        z = json.loads(z)


        msg = f"""
**•─────────────⚝─────────────•**
                      **❞BANSOS VMESS❞**
**•─────────────⚝─────────────•**
**❞Host Server :** `{DOMAIN}`
**❞Port TLS    :** `443, 400-900`
**❞Port NTLS   :** `80, 8080, 8081-9999 `
**❞UUID    :** `{z["id"]}`
**❞NetWork     :** `(WS) or (gRPC)`
**❞Path        :** `/vmess`
**❞ServiceName :** `vmess-grpc`
**•─────────────⚝─────────────•**
**VMESS URL TLS:**
```{b[0].strip("'").replace(" ","")}```
**•─────────────⚝─────────────•**
**❞VMESS URL HTTP:**
```{b[1].strip("'").replace(" ","")}```
**•─────────────⚝─────────────•**
**❞VMESS URL gRPC:** 
```{b[2].strip("'")}```
**•─────────────⚝─────────────•**
**❞Notes pelangan**
**❞simpan detail pembelian akun**
**❞sebagai garansi. kirimkan detail** 
**❞pembelian akun ke admin untuk** 
**❞pengecekan ketika terjadi masalah**
**❞pada config**
**❞Exp jatuh pada:** `{today}`
**•─────────────⚝─────────────•**
**» ** 🤖@R23_VPNSTORE
        """
        await event.respond(msg)

    try:
        if can_user_trial_again(user_id):
            await trial_vmess_(event)
            mark_user_trial_today(user_id)  # Mark the trial as used for today
        else:
            await event.answer("Anda sudah menggunakan bansos 1 hari ini? coba lagi besok 🙏 .", alert=True)
    except Exception as e:
        print(f'Error: {e}')
#CEK VMESS
@bot.on(events.CallbackQuery(data=b'cek-vmess-member'))
async def cek_vmess(event):
    async def cek_vmess_(event):
        cmd = 'bash cek-ws'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"""
**◇━━━━━━━━━━━━━━━━━━◇**
   ** ⟨🔸Cek Vmess Account🔸⟩**
**◇━━━━━━━━━━━━━━━━━━◇**
{z}

**Shows Logged In Users Vmess**
""", buttons=[[Button.inline("‹ 𝙼𝚊𝚒𝚗 𝙼𝚎𝚗𝚞 ›", "vmess-member")]])

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()
    
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await cek_vmess_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')



## CEK member VMESS
@bot.on(events.CallbackQuery(data=b'cek-member-member'))
async def cek_vmess(event):
    async def cek_vmess_(event):
        cmd = 'bash cek-mws'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"""

{z}

**Shows Users from databases**
""", buttons=[[Button.inline("‹ 𝙼𝚊𝚒𝚗 𝙼𝚎𝚗𝚞 ›", "vmess-member")]])

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()
    
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await cek_vmess_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')





@bot.on(events.CallbackQuery(data=b'delete-vmess'))
async def delete_vmess(event):
	async def delete_vmess_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | bot-del-vme'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**Successfully Renew Or Delete User**")
		else:
			msg = f"""**Successfully Deleted {user} **"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'renew-vmess-member'))
async def ren_vmess(event):
    async def ren_vmess_(event):
        async with bot.conversation(chat) as user_conv:
            await event.respond('**Perhatian! renew akun akan mengenakan biaya sesuai create account')
            await event.respond('**Username:**')
            user = await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = user.raw_text

        async with bot.conversation(chat) as exp_conv:
            await event.respond("**Choose Expiry Day**", buttons=[
                [Button.inline(" 30 Day ", "30")]
            ])
            exp = await exp_conv.wait_event(events.CallbackQuery)
            exp = exp.data.decode("ascii")

        async with bot.conversation(chat) as ip_conv:
            await event.respond("**Choose Expiry Day**", buttons=[
                [Button.inline(" 2 IP ", "2")]
            ])
            ip = await ip_conv.wait_event(events.CallbackQuery)
            ip = ip.data.decode("ascii")

            
            
            

            await process_user_balance_vmess(event, user_id)

        cmd = f'printf "%s\n" "{user}" "{exp}" "2000" "{ip}" | bot-renew-vme'

        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**Successfully Renew Or Delete User**")
        else:
            msg = f"""**Successfully Renewed  {user} {exp} Days Limit {ip} IP Quota 2000GB**"""
            await event.respond(msg)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await ren_vmess_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')

		
@bot.on(events.CallbackQuery(data=b'vmess-member'))
async def vmess(event):
    async def vmess_(event):
        inline = [
            [Button.inline("BANSOS 1 HARI", "trial-vmess-member"),
             Button.inline("ORDER VIP", "create-vmess-member")],
             
            [Button.inline("BACK MENU", "menu")]]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
     **◇⟨🔸VMESS SERVICE🔸⟩◇**
**◇━━━━━━━━━━━━━━━━━◇**
**» Service:** `VMESS`
**» Hostname/IP:** `{DOMAIN}`
**» ISP:** `{z["isp"]}`
**» Country:** `{z["country"]}`
**» ** @R23_VPNSTORE
**◇━━━━━━━━━━━━━━━━━◇**
"""
        await event.edit(msg, buttons=inline)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await vmess_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')



