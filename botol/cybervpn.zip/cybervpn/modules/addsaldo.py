from cybervpn import *
import datetime as DT

# Fungsi untuk mendapatkan level pengguna dari database
def get_level_from_db(user_id):
    # Placeholder untuk query ke database untuk mendapatkan level user (admin, user, dll)
    # Implementasikan fungsi ini sesuai dengan sistem database Anda
    pass

# Fungsi untuk menambah saldo ke user
def tambah_saldo(user_id, saldo):
    # Placeholder untuk fungsi yang menambah saldo ke pengguna
    # Implementasikan fungsi ini untuk berinteraksi dengan database atau API Anda
    pass

@bot.on(events.CallbackQuery(data=b'addsaldo'))
async def saldo_handler(event):
    sender = await event.get_sender()
    user_id = str(event.sender_id)
    chat = event.chat_id
    async with bot.conversation(chat) as id_conv:
        await event.respond('**Masukkan ID Telegram member:**')
        user_input_id = (await id_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

    async with bot.conversation(chat) as saldo_conv:
        await event.respond('**Masukkan Nominal Saldo member :**')
        user_input_saldo = (await saldo_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

    try:
        level = get_level_from_db(user_id)  # Mengambil level user dari database
        print(f'Mengambil level dari database: {level}')

        if level == 'admin':  # Hanya admin yang bisa menambah saldo
            # Validasi apakah saldo yang dimasukkan adalah angka yang valid
            try:
                saldo = float(user_input_saldo)
                tambah_saldo(user_input_id, saldo)
                
                today = DT.date.today()
                later = today + DT.timedelta(days=0)  # Bisa sesuaikan tanggal jika perlu
                msg = f"""
**━━━━━━━━━━━━━━━━━**
**⟨ Berhasil Menambah Saldo Member ⟩**
**━━━━━━━━━━━━━━━━━**
**» ID Anda:** `{user_id}`
**» ID member:** `{user_input_id}`
**» Saldo Ditambahkan:** `IDR.{saldo}`
**» Status:** `Berhasil ✅`
**━━━━━━━━━━━━━━━━**
**» Tanggal Topup:** `{later}`
**━━━━━━━━━━━━━━━━**
"""
                inline = [
                    [Button.url("Telegram", "t.me/R23_VPNSTORE"),
                     Button.url("WhatsApp", "wa.me/6285888801241")]
                ]
                await event.respond(msg, buttons=inline)

                # Kirim notifikasi ke member
                member_msg = f"""
**━━━━━━━━━━━━━━━━━**
**⟨ Notifikasi Topup Berhasil ⟩**
**━━━━━━━━━━━━━━━━━**
**» Akun Anda telah diterima saldo sebesar IDR.{saldo}**
**» Topup berhasil ✅**
**» Tanggal Topup:** `{later}`
**━━━━━━━━━━━━━━━━━**
"""
                # Kirim pesan notifikasi ke user (member)
                try:
                    member = await bot.get_entity(user_input_id)  # Mendapatkan entity user berdasarkan ID
                    await bot.send_message(member, member_msg)
                except Exception as e:
                    print(f'Error saat mengirim notifikasi ke member: {e}')
                    await event.respond("Gagal mengirim notifikasi ke member.")

            except ValueError:
                await event.respond("Input saldo tidak valid. Mohon masukkan angka yang valid.")
        else:
            await event.answer(f"Akses Ditolak. Hanya admin yang dapat melakukan aksi ini.", alert=True)

    except Exception as e:
        print(f'Error: {e}')
        await event.respond("Terjadi kesalahan. Silakan coba lagi nanti.")