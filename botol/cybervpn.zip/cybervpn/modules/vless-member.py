from cybervpn import *
import sqlite3
import datetime as DT
import subprocess
import random
import re
import base64
import json
import time
from telethon import events

@bot.on(events.CallbackQuery(data=b'create-vmess-member'))
async def create_vmess(event):
    async def create_vmess_(event):
        # Percakapan dengan pengguna untuk username
        async with bot.conversation(chat) as user_conv:
            await event.respond('**Username:**')
            user = (await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        # Percakapan dengan pengguna untuk masa aktif akun (exp)
        async with bot.conversation(chat) as exp_conv:
            await event.respond("**Pilih Masa Aktif (Hari)**", buttons=[
                [Button.inline("30 Hari", "30")]
            ])
            exp = (await exp_conv.wait_event(events.CallbackQuery)).data.decode("ascii")

        # Percakapan dengan pengguna untuk memilih harga berdasarkan IP
        async with bot.conversation(chat) as price_conv:
            await event.respond("**Pilih Batas IP dan Harga**", buttons=[
                [Button.inline("2 IP - Rp.7,000 - HP", "2")],
                [Button.inline("5 IP - Rp.15,000 - STB", "5")]
            ])
            ip = (await price_conv.wait_event(events.CallbackQuery)).data.decode("ascii")

        # Tentukan harga berdasarkan pilihan IP
        if ip == "2":
            price = 7000  # Harga untuk 2 IP
        elif ip == "5":
            price = 15000  # Harga untuk 5 IP
        else:
            price = 0  # Harga default jika tidak ada pilihan yang benar

        # Memberitahukan pengguna bahwa akun sedang disiapkan
        await event.edit("`Tunggu sebentar... Menyiapkan Akun VMess`")
        
        # Simulasi proses pembuatan akun
        await event.edit("Memproses..")
        await event.edit("Memproses...")
        await event.edit("Memproses....")
        time.sleep(1)
        await event.edit("`Memproses Akun Premium`")
        time.sleep(1)
        await event.edit("`Memproses... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Memproses... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Memproses... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Memproses... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Memproses... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Memproses... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Memproses... 84%\n█████████████████████▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Memproses... 100%\n█████████████████████████ `")

        await process_user_balance_vmess(event, user_id)

        # Menghasilkan akun VMess menggunakan perintah subprocess
        cmd = f'printf "%s\n" "{user}" "{exp}" "1000" "{ip}" | addws-bot'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            print(f'Error: {e}')
            print(f'Subprocess output: {a}')
            await event.respond(f"Terjadi kesalahan: {e}\nOutput subprocess: {a}")
            return  # Stop eksekusi jika terjadi kesalahan

        # Persiapkan tanggal dan ekstrak informasi VMess
        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))
        creation_date = today.strftime('%Y-%m-%d')
        current_time = DT.datetime.now().strftime("%H:%M:%S")  # Get current time

        b = [x.group() for x in re.finditer("vmess://(.*)", a)]

        z = base64.b64decode(b[0].replace("vmess://", "")).decode("ascii")
        z = json.loads(z)

        z1 = base64.b64decode(b[1].replace("vmess://", "")).decode("ascii")
        z1 = json.loads(z1)

        # Format dan kirim pesan kepada pengguna
        msg = f"""
**═════════════════════════**
**⚡BUAT AKUN VMESS PREMIUM⚡**
**═════════════════════════**
**Remarks:** `{user}`
**Host Server:** `{DOMAIN}`
**Login:** `{ip}`IP
**Harga Rp.{price}**
**Port TLS:** `443, 400-900`
**Port NTLS:** `80, 8080, 8081-9999 `
**UUID:** `{z["id"]}`
**NetWork:** `(WS) atau (gRPC)`
**Path:** `/vmess`
**ServiceName:** `vmess-grpc`
**═════════════════════════**
**VMESS URL TLS:**
```{b[0].strip("'").replace(" ","")}```
**═════════════════════════**
**VMESS URL HTTP:**
```{b[1].strip("'").replace(" ","")}```
**═════════════════════════**
**VMESS URL gRPC:** 
```{b[2].strip("'")}```
**═════════════════════════**
**🗓️Tanggal Pembuatan:** `{creation_date}`
**🕒Jam Pembuatan:** `{current_time}`
**🗓️Aktip Sampai Tanggal:** `{later}`
**🗓️Durasi:** `{exp}`days
**═════════════════════════**
**☞ó ‌つò☞ 𝓡𝓲𝓼𝓮 𝓙𝓪𝓫𝓪𝓻 𝓢𝓽𝓸𝓻𝓮**
**═════════════════════════**
"""
        await event.respond(msg)

        # Kirim notifikasi ke grup
        group_chat_id = -1002029496202  # Ganti dengan ID grup yang sesuai
        notification_msg = f"""
**═══════════════════**
  **🔥Notif Transaksi Seller🔥**
**═══════════════════**
**📅Tanggal:** `{creation_date}`
**🕒 Jam:** `{current_time}`
**═══════════════════**
**🆔ID** `{user_id}`
**🖥️Vmess account created**
**👤Username:** `{user}`
**🔑Login:** `{ip}`IP
**📦Order:** `{exp}`days
**⏳Expired:** `{later}`
**═══════════════════**
**💵Harga** `Rp.{price}`
**═══════════════════**
**👤Admin** @RiswanJabar
**═══════════════════**
"""
        await bot.send_message(group_chat_id, notification_msg)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Mengambil level dari database: {level}')

        if level == 'user':
            await create_vmess_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')

@bot.on(events.CallbackQuery(data=b'cek-vless-member'))
async def cek_vless(event):
    async def cek_vless_(event):
        cmd = 'cek-vless'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"""
**◇━━━━━━━━━━━━━━━━━━◇**
   ** ⟨🔸Cek Vless Account🔸⟩**
**◇━━━━━━━━━━━━━━━━━━◇**
{z}

**Shows Logged In Users Vless**
""", buttons=[[Button.inline("‹ main menu ›", "menu")]])

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await cek_vless_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')

		
@bot.on(events.CallbackQuery(data=b'renew-vless-member'))
async def ren_vless(event):
    async def ren_vless_(event):
        async with bot.conversation(chat) as user:
            await event.respond('**Perhatian! renew akun akan mengenakan biaya sesuai create account')
            await event.respond('**Username:**')
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        async with bot.conversation(chat) as exp:
            await event.respond("**Choose Expiry Day**", buttons=[
                [Button.inline(" 30 Day ", "30")]
            ])
            exp = exp.wait_event(events.CallbackQuery)
            exp = (await exp).data.decode("ascii")

        async with bot.conversation(chat) as ip:
            await event.respond("**Choose limit ip**", buttons=[
                [Button.inline(" 2 ip ", "2")]
            ])
            ip = ip.wait_event(events.CallbackQuery)
            ip = (await ip).data.decode("ascii")

        await process_user_balance_vless(event, user_id)
        await event.edit("Processing..")
        await event.edit("Processing...")
        await event.edit("Processing....")
        time.sleep(1)
        await event.edit("`Processing Create Premium Account`")
        time.sleep(1)
        await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 100%\n█████████████████████████ `")
        await process_user_balance_vless(event, user_id)
        time.sleep(1)
        await event.edit("`Wait.. Setting up an Account`")
        cmd = f'printf "%s\n" "{user}" "{exp}" "1000" "{ip}" | bot-renew-vle'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**Successfully Renew Or Delete User**")
        else:
            msg = f"""**Successfully Renewed {user} {exp} Days, limit ip {ip}, limit Quota 100GB**"""
            await event.respond(msg)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await ren_vless_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')


# CEK member VLESS
@bot.on(events.CallbackQuery(data=b'cek-membervl-member'))
async def cek_vless(event):
    async def cek_vless_(event):
        cmd = 'bash cek-mvs'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"""

{z}

**Shows Users from databases**
""", buttons=[[Button.inline("‹ main menu ›", "menu")]])

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await cek_vless_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')



@bot.on(events.CallbackQuery(data=b'delete-vless'))
async def delete_vless(event):
	async def delete_vless_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing Crate Premium Account`")
		time.sleep(1)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{user}" | bot-del-vle'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**Successfully Renew Or Delete User**")
		else:
			msg = f"""**Successfully Deleted**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)





from cybervpn import *
from telethon import events, Button
import subprocess
import random
import sqlite3
import time
import re
from datetime import datetime, timedelta
from telethon.tl.custom import Button

# Fungsi untuk mendapatkan waktu pembuatan akun dari database atau penyimpanan
def get_user_creation_time(user):
    # Fungsi ini harus mengakses database atau file untuk mendapatkan waktu pembuatan
    # Di sini hanya contoh yang mengembalikan None (artinya tidak ada data)
    return None

# Fungsi untuk menyimpan waktu pembuatan akun di database atau penyimpanan
def update_user_creation_time(user, timestamp):
    # Fungsi ini akan menyimpan waktu pembuatan akun
    # Di sini hanya contoh, bisa diganti dengan akses ke database atau penyimpanan
    print(f"Waktu pembuatan akun {user} disimpan pada: {timestamp}")

@bot.on(events.CallbackQuery(data=b'trial-vless-member'))
async def trial_vless(event):
    async def trial_vless_(event):
        user_id = str(event.sender_id)

        # Cek apakah akun trial masih aktif
        if not has_trial_expired(user_id):
            await event.respond("Anda masih memiliki akun trial aktif. Silakan tunggu hingga masa trial Anda expired sebelum mencoba lagi.")
            return  # Berhenti jika trial masih aktif
        
        # Set waktu kedaluwarsa 60 menit dari sekarang
        current_time = datetime.now()
        exp_time = current_time + timedelta(minutes=60)  # 60 menit dari waktu sekarang
        
        # Simpan waktu pembuatan akun
        update_user_creation_time(user_id, current_time)

        cmd = f'printf "%s\n" "Trial`</dev/urandom tr -dc X-Z0-9 | head -c4`" "1" "1" "1" | bot-trialvless'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            await event.respond("**User Sudah Ada**")
            return
        
        x = [x.group() for x in re.finditer("vless://(.*)", a)]
        print(x)

        # Extract informasi dari URL vless
        remarks = re.search("#(.*)", x[0]).group(1)
        uuid = re.search("vless://(.*?)@", x[0]).group(1)

        msg = f"""
**═════════════════════════**
**⚡AKUN TRIAL VLESS PREMIUM⚡**
**═════════════════════════**
**Port TLS:** `443`
**Port NTLS:** `80`
**UUID:** `{uuid}`
**NetWork:** `(WS) atau (gRPC)`
**Path:** `/vless`
**ServiceName:** `vless-grpc`
**═════════════════════════**
**VLESS URL TLS:**
```{x[0]}```
**═════════════════════════**
**VLESS URL HTTP:**
```{x[1].replace(" ","")}```
**═════════════════════════**
**VLESS URL gRPC:** 
```{x[2].replace(" ","")}```
**═════════════════════════**
**🗓️Masa Aktif 60 Menit:** `{exp_time.strftime("%H:%M")}`
**═════════════════════════**
**☞ó ‌つò☞ 𝓡𝓲𝓼𝓮𝓽 𝓳𝓪𝓫𝓮𝓻 𝓢𝓽𝓸𝓻𝓮**
**═════════════════════════**
"""
        await event.respond(msg)

    user_id = str(event.sender_id)
    
    try:
        level = get_level_from_db(user_id)
        if level == 'user':
            await trial_vless_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')

# Fungsi untuk memeriksa apakah trial sudah kedaluwarsa
def has_trial_expired(user):
    creation_time = get_user_creation_time(user)
    
    if creation_time is None:
        return False  # Jika tidak ada catatan, anggap belum kedaluwarsa
    
    # Hitung waktu kedaluwarsa (60 menit setelah pembuatan)
    expiration_time = creation_time + timedelta(minutes=60)
    current_time = datetime.now()

    # Cek apakah waktu sekarang sudah melebihi waktu kedaluwarsa
    if current_time > expiration_time:
        return True  # Trial sudah kedaluwarsa
    return False  # Trial masih aktif

# Cek apakah trial sudah kedaluwarsa sebelum mengizinkan pengguna menggunakan layanan
@bot.on(events.CallbackQuery(data=b'trial-check'))
async def check_trial_status(event):
    user = str(event.sender_id)
    
    if has_trial_expired(user):
        await event.respond("Trial Anda sudah kedaluwarsa.")
    else:
        await event.respond("Trial Anda masih aktif.")
@bot.on(events.CallbackQuery(data=b'vless-member'))
async def vless(event):
    async def vless_(event):
        inline = [
[Button.inline("Trial Vless", "trial-vless-member"),
 Button.inline("Create Vless", "create-vless-member")],
[Button.inline("Renew Vless", "renew-vless-member")],
[Button.inline("‹ Main Menu ›", "menu")]]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
    **◇⟨🔸VLESS SERVICE🔸⟩◇**
**◇━━━━━━━━━━━━━━━━━◇**
**  Service:** `VLESS`
**  Hostname/IP:** `{DOMAIN}`
**  ISP:** `{z["isp"]}`
**  Country:** `{z["country"]}`
**» ** 🤖@RiswanJabar
**◇━━━━━━━━━━━━━━━━━◇**
"""
        await event.edit(msg, buttons=inline)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await vless_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')

