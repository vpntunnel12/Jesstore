import requests
from cybervpn import *

@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
    async def ssh_member_manager(event):
        inline = [
            [Button.inline("TRIAL SSH", "trial-ssh-member"),
             Button.inline("CREATE SSH", "create-ssh-member")],
             [Button.inline("CEK LOGIN SSH", "login-ssh-member")],
            [Button.inline("CEK ALL USER", "show-ssh-member")],
       [Button.inline("PERPANJANG USER", "renew-ssh-member")],

            [Button.inline("↪️main menu↩️", "menu")]]
        
        location_info = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**┌─────────────────────•**
**│█▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█**
**│█░░╦─╦╔╗╦─╔╗╔╗╔╦╗╔╗░░█**
**│█░░║║║╠─║─║─║║║║║╠─░░█**
**│█░░╚╩╝╚╝╚╝╚╝╚╝╩─╩╚╝░░█**
**│█▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█**
**└─────────────────────•**
**┌─────────────────────•**
**│ISP :** `{location_info["isp"]}`
**│SERVER :** `{location_info["country"]}`
**└─────────────────────•**
**┌─────────────────────•**
**│VPN PREMIUM RZ STORE**
**│RP: 8000 LOGIN 2 HP STB**
**└─────────────────────•**
**┌─────────────────────•**
**│JIKA TOPUP TIDAK MASUK**
**│TINGGAL CHAT ADMIN AJA**
**└─────────────────────•**
**┌─────────────────────•**
**│Owner kami @R23_VPNSTORE**
**└─────────────────────•**
"""
        await event.edit(msg, buttons=inline)

    async def ssh_admin_manager(event):
        inline = [
            [Button.inline("TRIAL SSH", "trial-ssh"),
             Button.inline("CERATE SSH", "create-ssh"),
             Button.inline("DELETE SSH", "delete-ssh")],
            [Button.inline("CEK LOGIN", "login-ssh")],
            [Button.inline("CEK ALL USER", "show-ssh")],
[Button.inline("PERPANJANG USER", "renew-ssh")],
            [Button.inline("↪️main menu↩️", "menu")]]
        
        location_info = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**┌─────────────────────•**
**│█▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█**
**│█░░╦─╦╔╗╦─╔╗╔╗╔╦╗╔╗░░█**
**│█░░║║║╠─║─║─║║║║║╠─░░█**
**│█░░╚╩╝╚╝╚╝╚╝╚╝╩─╩╚╝░░█**
**│█▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█**
**└─────────────────────•**
**┌─────────────────────•**
**│ISP :** `{location_info["isp"]}`
**│SERVER :** `{location_info["country"]}`
**└─────────────────────•**
**┌─────────────────────•**
**│VPN PREMIUM RZ STORE**
**│RP: 8000 LOGIN 2 HP STB**
**└─────────────────────•**
**┌─────────────────────•**
**│JIKA TOPUP TIDAK MASUK**
**│TINGGAL CHAT ADMIN AJA**
**└─────────────────────•**
**┌─────────────────────•**
**│Owner kami @R23_VPNSTORE**
**└─────────────────────•**
"""
        await event.edit(msg, buttons=inline)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await ssh_admin_manager(event)
        else:
            await ssh_member_manager(event)
    except Exception as e:
        print(f'Error: {e}')

