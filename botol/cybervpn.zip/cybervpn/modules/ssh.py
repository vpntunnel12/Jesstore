import requests
from cybervpn import *

@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
    async def ssh_member_manager(event):
        inline = [
            [Button.inline("TRIAL SSH", "trial-ssh-member"),
             Button.inline("CREATE SSH", "create-ssh-member")],
            [Button.inline("‹ main menu ›", "menu")]]
        
        location_info = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**┌─────────────────────•**
**│█▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█**
**│█░░╦─╦╔╗╦─╔╗╔╗╔╦╗╔╗░░█**
**│█░░║║║╠─║─║─║║║║║╠─░░█**
**│█░░╚╩╝╚╝╚╝╚╝╚╝╩─╩╚╝░░█**
**│█▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█**
**└─────────────────────•**
**┌─────────────────────•**
**│ISP :** `{location_info["isp"]}`
**│SERVER :** `{location_info["country"]}`
**└─────────────────────•**
**┌─────────────────────•**
**│VPN PREMIUM RZ STORE**
**│RP: 8000 LOGIN 2 HP STB**
**└─────────────────────•**
**┌─────────────────────•**
**│JIKA TOPUP TIDAK MASUK**
**│TINGGAL CHAT ADMIN AJA**
**└─────────────────────•**
**┌─────────────────────•**
**│Owner kami @R23_VPNSTORE**
**└─────────────────────•**
"""
        await event.edit(msg, buttons=inline)

    async def ssh_admin_manager(event):
        inline = [
            [Button.inline("trial ssh", "trial-ssh"),
             Button.inline("create ssh", "create-ssh"),
             Button.inline("delete ssh", "delete-ssh")],
            [Button.inline("cek login", "login-ssh")],
            [Button.inline("liat all user", "show-ssh")],
[Button.inline("renew ssh", "renew-ssh")],
            [Button.inline("‹ main menu ›", "menu")]]
        
        location_info = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**┌─────────────────────•**
**│█▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█**
**│█░░╦─╦╔╗╦─╔╗╔╗╔╦╗╔╗░░█**
**│█░░║║║╠─║─║─║║║║║╠─░░█**
**│█░░╚╩╝╚╝╚╝╚╝╚╝╩─╩╚╝░░█**
**│█▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█**
**└─────────────────────•**
**┌─────────────────────•**
**│ISP :** `{location_info["isp"]}`
**│SERVER :** `{location_info["country"]}`
**└─────────────────────•**
**┌─────────────────────•**
**│VPN PREMIUM RZ STORE**
**│RP: 8000 LOGIN 2 HP STB**
**└─────────────────────•**
**┌─────────────────────•**
**│JIKA TOPUP TIDAK MASUK**
**│TINGGAL CHAT ADMIN AJA**
**└─────────────────────•**
**┌─────────────────────•**
**│Owner kami @R23_VPNSTORE**
**└─────────────────────•**
"""
        await event.edit(msg, buttons=inline)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await ssh_admin_manager(event)
        else:
            await ssh_member_manager(event)
    except Exception as e:
        print(f'Error: {e}')

