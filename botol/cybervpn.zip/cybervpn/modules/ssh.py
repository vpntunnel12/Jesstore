import requests
from cybervpn import *

@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
    async def ssh_member_manager(event):
        inline = [
            [Button.inline("TRIAL SSH", "trial-ssh-member"),
             Button.inline("ORDER SSH", "create-ssh-member")],
             
            [Button.inline("BACK MENU", "menu")]]
        
        location_info = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
          **◇⟨🔸SSH SERVICE🔸⟩◇**
**» Service:** `SSH WS`
**» Hostname/IP:** `{DOMAIN}`
**» ISP:** `{location_info["isp"]}`
**» Country:** `{location_info["country"]}`
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
             **🤖bot Penel Member🤖**
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
**1️⃣ Akun Premium VIP**
**🔑 Buat Akun Baru**
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
**2️⃣ Layanan Premium**
**🚀 Upgrade ke Premium Sekarang!**
**💰 Harga Spesial: Rp.8000**
**💵 Top-up Minimum Rp.8000** 
**⚠️ untuk Mendapatkan Keuntungan**
**🔒 Cek Akun Premium Saya**
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
**3️⃣ Manfaat Keuntungan Premium**
**⚡ Kecepatan Super Cepat**
**🔒 Keamanan Terjamin dengan**
**✅ Enkripsi Tingkat Tinggi**
**🌍 Akses Global Tanpa Batas**
**💼 Dukungan 24/7 untuk**
**↪️ Pengguna Premium**
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
**4️⃣ Informasi Pengguna**
**📆 Masa Aktif Akun: 30 Hari**
**5️⃣ Bantuan & Support❓ FAQ**
**🛠️ Hubungi Admin:** @R23_VPNSTORE
**📜 Panduan Penggunaan**
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
**🔧 Status Layanan ➢ ** `Online` 🟢
**🖥 SSH Status:** `{get_ssh_status()}`
**🌐 XRay Status:** `{get_xray_status()}`
**🔄 UDP Status:** `{get_udp_status()}`
**🛡️ Dropbear Status:** `{get_dropbear_status()}`
**🌐 webSocket Status:** `{get_ws_status()}`
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
**📈 Versi bot:** `V 4.7`
**🆔 ID Pengguna Anda:** `{user_id}`
**💸 Saldo Anda:** `{saldo_aji}`
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
"""
        await event.edit(msg, buttons=inline)

    async def ssh_admin_manager(event):
        inline = [
               [Button.inline("𝗧𝗥𝗜𝗔𝗟 𝗦𝗦𝗛", "trial-ssh"),
             Button.inline("𝗖𝗘𝗥𝗔𝗧𝗘 𝗦𝗦𝗛", "create-ssh")],
            [Button.inline("𝗗𝗘𝗟𝗘𝗧𝗘 𝗦𝗦𝗛", "delete-ssh"),
             Button.inline("𝗨𝗦𝗘𝗥 𝗟𝗢𝗚𝗜𝗡", "login-ssh")],
            [Button.inline("𝗔𝗟𝗟 𝗨𝗦𝗘𝗥", "show-ssh")],
            [Button.inline("𝗥𝗘𝗡𝗘𝗪", "renew-ssh"),
             Button.inline("𝗠𝗔𝗜𝗡 𝗠𝗘𝗡𝗨", "menu")]
            
            ]
        
        location_info = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**◇━━━━━━━━━━━━━━━━◇**
    **◇⟨🔸SSH SERVICE🔸⟩◇**
           **Admin Manager**
**◇━━━━━━━━━━━━━━━━◇**
**» Service:** `SSH`
**» Hostname/IP:** `{DOMAIN}`
**» ISP:** `{location_info["isp"]}`
**» Country:** `{location_info["country"]}`
**» ** @R23_VPNSTORE
**◇━━━━━━━━━━━━━━━━◇**
"""
        await event.edit(msg, buttons=inline)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await ssh_admin_manager(event)
        else:
            await ssh_member_manager(event)
    except Exception as e:
        print(f'Error: {e}')

