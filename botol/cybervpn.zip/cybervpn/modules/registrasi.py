from cybervpn import *
import subprocess
import datetime as DT

# Daftar ID admin yang sah (ganti dengan ID admin yang sebenarnya)
AUTHORIZED_ADMINS = [123456789, 987654321]  # Ganti dengan ID pengguna admin yang valid

# PIN yang digunakan untuk verifikasi admin
ADMIN_PIN = "051219"  # Ganti dengan PIN yang lebih aman

@bot.on(events.NewMessage(pattern=r"(?:/registrasi)$"))
@bot.on(events.CallbackQuery(data=b'registrasi'))
async def registrasi_handler(event):
    chat = event.chat_id
    sender = await event.get_sender()
    user_id = str(event.sender_id)

    # Verifikasi apakah pengguna adalah admin yang sah
    if int(user_id) not in AUTHORIZED_ADMINS:
        await event.respond("**Akses Ditolak!** Anda tidak diizinkan untuk menggunakan bot ini sebagai admin.")
        return  # Hentikan eksekusi lebih lanjut jika pengguna bukan admin yang sah

    # Fungsi untuk meminta PIN dari admin
    async def get_pin(user_conv):
        await event.edit('**Masukkan PIN untuk melanjutkan pendaftaran:**')
        pin_msg = await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
        
        if pin_msg.raw_text != ADMIN_PIN:
            await event.edit("**PIN Salah!** Anda tidak memiliki akses untuk melanjutkan.")
            return None
        return pin_msg.raw_text

    # Meminta PIN terlebih dahulu sebelum registrasi
    async with bot.conversation(chat) as user_conv:
        pin = await get_pin(user_conv)
        if pin is None:
            return  # Jika PIN salah, hentikan proses lebih lanjut

        # Setelah PIN benar, lanjutkan dengan registrasi
        async def get_username(user_conv):
            await event.edit('**Masukkan username untuk pengguna yang akan didaftarkan:**')
            user_msg = await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            return user_msg.raw_text

        user = await get_username(user_conv)

    saldo = 0
    level = "user"
    register_user(user_id, saldo, level)  # Pastikan fungsi register_user didefinisikan

    today = DT.date.today().strftime("%Y-%m-%d")
    msg = f"""
    **━━━━━━━━━━━━━━━━**
    **⟨🕊Pendaftaran Berhasil🕊⟩**
    **━━━━━━━━━━━━━━━━**
    **» ID Anda:** `{user_id}`
    **» Username:** `{user}`
    **» Saldo:** `IDR.0`
    **» Ketik /menu untuk login**
    **━━━━━━━━━━━━━━━━**
    **» Tanggal Pendaftaran:** `{today}`
    **━━━━━━━━━━━━━━━━**
    """
    inline = [
        [Button.inline("Login", "menu")]
    ]
    await event.respond(msg, buttons=inline)