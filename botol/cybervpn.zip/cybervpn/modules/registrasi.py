from cybervpn import *
import subprocess
import datetime as DT

# Asumsikan 'admin_pin' adalah PIN yang benar untuk menjadi admin
admin_pin = "051219"
expired_days = 30  # Masa berlaku 30 hari dari tanggal pendaftaran

@bot.on(events.NewMessage(pattern=r"(?:/registrasi)$"))
@bot.on(events.CallbackQuery(data=b'registrasi'))
async def registrasi_handler(event):
    chat = event.chat_id
    sender = await event.get_sender()
    user_id = str(event.sender_id)

    async def get_username(user_conv):
        await event.edit('**Masukkan usernamemu:**')
        user_msg = await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
        return user_msg.raw_text

    async def get_pin(user_conv):
        await event.edit('**Masukkan PIN untuk menjadi admin:**')
        pin_msg = await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
        return pin_msg.raw_text

    async with bot.conversation(chat) as user_conv:
        user = await get_username(user_conv)
        
        # Minta PIN jika pengguna ingin menjadi admin
        pin = await get_pin(user_conv)
        
        # Periksa apakah PIN yang dimasukkan benar
        if pin == admin_pin:
            level = "admin"
        else:
            level = "user"

        # Registrasi pengguna dengan level dan saldo awal
        saldo = 0
        register_user(user_id, saldo, level)  # Pastikan fungsi ini menangani penyimpanan data pengguna

    today = DT.date.today()
    expired_date = today + DT.timedelta(days=expired_days)  # Tanggal expired setelah 30 hari

    msg = f"""
**━━━━━━━━━━━━━━━━**
**⟨🕊Pendaftaran Berhasil🕊⟩**
**━━━━━━━━━━━━━━━━**
**» ID Anda:** `{user_id}`
**» Username:** `{user}`
**» Saldo:** `IDR.0`
**» Ketik /menu untuk login**
**━━━━━━━━━━━━━━━━**
**» Tanggal Pendaftaran:** `{today}`
**» Tanggal Expired:** `{expired_date}`
**━━━━━━━━━━━━━━━━**
**» Peran Anda:** `{level}`
**━━━━━━━━━━━━━━━━**
"""
    inline = [
        [Button.inline("Login", "menu")]
    ]
    await event.respond(msg, buttons=inline)