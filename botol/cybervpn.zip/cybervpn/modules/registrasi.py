from cybervpn import *
import subprocess
import datetime as DT

# Asumsikan 'admin_pin' adalah PIN yang benar untuk menjadi admin
admin_pin = "051219"

@bot.on(events.NewMessage(pattern=r"(?:/registrasi)$"))
@bot.on(events.CallbackQuery(data=b'registrasi'))
async def registrasi_handler(event):
    chat = event.chat_id
    sender = await event.get_sender()
    user_id = str(event.sender_id)

    async def get_username(user_conv):
        await event.edit('**Masukkan usernamemu:**')
        user_msg = await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
        return user_msg.raw_text

    async def get_pin(user_conv):
        await event.edit('**Masukkan PIN untuk menjadi admin:**')
        pin_msg = await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
        return pin_msg.raw_text

    try:
        async with bot.conversation(chat) as user_conv:
            user = await get_username(user_conv)
            # Validasi username
            if not user or len(user) < 3:
                await event.edit("**Username tidak valid!** Silakan coba lagi.")
                return

            pin = await get_pin(user_conv)
            # Validasi PIN (hanya angka)
            if not pin.isdigit() or len(pin) != len(admin_pin):
                await event.edit("**PIN tidak valid!** Pastikan PIN yang Anda masukkan benar.")
                return

            # Cek apakah PIN yang dimasukkan benar
            if pin == admin_pin:
                level = "admin"
                # Set tanggal kedaluwarsa admin (15 hari dari sekarang)
                expiration_date = DT.date.today() + DT.timedelta(days=15)
            else:
                level = "user"
                expiration_date = None  # Tidak ada tanggal kedaluwarsa untuk pengguna biasa

            saldo = 0
            # Registrasi pengguna (pastikan fungsi ini menerima dan menyimpan tanggal kedaluwarsa)
            register_user(user_id, saldo, level, expiration_date)

        today = DT.date.today()
        later = today  # Tanggal pendaftaran adalah hari ini
        msg = f"""
        **━━━━━━━━━━━━━━━━**
        **⟨🕊Pendaftaran Berhasil🕊⟩**
        **━━━━━━━━━━━━━━━━**
        **» ID Anda:** `{user_id}`
        **» Username:** `{user}`
        **» Saldo:** `IDR.0`
        **» Ketik /menu untuk login**
        **━━━━━━━━━━━━━━━━**
        **» Tanggal Pendaftaran:** `{later}`
        **━━━━━━━━━━━━━━━━**
        **» Peran Anda:** `{level}`

        """
        if level == "admin":
            msg += f"**» Tanggal Expired Admin:** `{expiration_date}`\n"
        msg += "━━━━━━━━━━━━━━━━"

        inline = [
            [Button.inline("Login", "menu")]
        ]
        await event.respond(msg, buttons=inline)
        
    except Exception as e:
        await event.edit(f"Terjadi kesalahan: {str(e)}")