from cybervpn import *
import subprocess
import datetime as DT

# Daftar ID admin yang sah (ganti dengan ID admin yang sebenarnya)
AUTHORIZED_ADMINS = [123456789, 987654321]  # Ganti dengan ID pengguna admin yang valid

@bot.on(events.NewMessage(pattern=r"(?:/registrasi)$"))
@bot.on(events.CallbackQuery(data=b'registrasi'))
async def registrasi_handler(event):
    chat = event.chat_id
    sender = await event.get_sender()
    user_id = str(event.sender_id)

    # Verifikasi apakah pengguna adalah admin yang sah
    if int(user_id) not in AUTHORIZED_ADMINS:
        await event.respond("**Akses Ditolak!** Anda tidak diizinkan untuk menggunakan bot ini sebagai admin.")
        return  # Hentikan eksekusi lebih lanjut jika pengguna bukan admin yang sah

    async def get_username(user_conv):
        await event.edit('**Masukkan usernamemu:**')
        user_msg = await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
        return user_msg.raw_text

    async with bot.conversation(chat) as user_conv:
        user = await get_username(user_conv)

    saldo = 0
    level = "user"
    register_user(user_id, saldo, level)

    today = DT.date.today()
    later = today  # Menggunakan tanggal hari ini langsung
    msg = f"""
    **━━━━━━━━━━━━━━━━**
    **⟨🕊Pendaftaran Berhasil🕊⟩**
    **━━━━━━━━━━━━━━━━**
    **» ID Anda:** `{user_id}`
    **» Username:** `{user}`
    **» Saldo:** `IDR.0`
    **» Ketik /menu untuk login**
    **━━━━━━━━━━━━━━━━**
    **» Tanggal Pendaftaran:** `{later}`
    **━━━━━━━━━━━━━━━━**
    """
    inline = [
        [
         Button.inline("Login", "menu")]
    ]
    await event.respond(msg, buttons=inline)

    # Kirimkan ID pengguna baru ke admin
    for admin_id in AUTHORIZED_ADMINS:
        admin_msg = f"**Pengguna Baru Terdaftar**:\n\n**ID Pengguna:** {user_id}\n**Username:** {user}"
        await bot.send_message(admin_id, admin_msg)