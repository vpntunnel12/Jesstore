import sqlite3
from cybervpn import *
from telethon import events, Button
import random
import sys
from datetime import datetime, timedelta
import asyncio
import time

# Membuat koneksi ke database dan memastikan tabel ada
def create_db():
    conn = sqlite3.connect('topup_users.db')  # Nama file database
    cursor = conn.cursor()
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        user_id TEXT PRIMARY KEY,
        username TEXT,
        payment_status TEXT DEFAULT 'pending'
    )''')
    conn.commit()
    conn.close()

# Menambahkan pengguna baru ke database
def add_user(user_id, username):
    conn = sqlite3.connect('topup_users.db')  # Koneksi ke database
    cursor = conn.cursor()
    cursor.execute('''
    INSERT OR IGNORE INTO users (user_id, username)
    VALUES (?, ?)
    ''', (user_id, username))
    conn.commit()
    conn.close()

# Memperbarui status pembayaran pengguna
def update_payment_status(user_id, status):
    conn = sqlite3.connect('topup_users.db')  # Koneksi ke database
    cursor = conn.cursor()
    cursor.execute('''
    UPDATE users
    SET payment_status = ?
    WHERE user_id = ?
    ''', (status, user_id))
    conn.commit()
    conn.close()

# Memeriksa status pembayaran pengguna
def check_payment_status(user_id):
    conn = sqlite3.connect('topup_users.db')  # Koneksi ke database
    cursor = conn.cursor()
    cursor.execute('''
    SELECT payment_status FROM users WHERE user_id = ?
    ''', (user_id,))
    result = cursor.fetchone()
    conn.close()
    if result:
        return result[0]  # Mengembalikan status pembayaran
    else:
        return 'pending'  # Jika pengguna tidak ditemukan, status default 'pending'

# Handler untuk callback 'topup'
@bot.on(events.CallbackQuery(data=b'topup'))
async def topup_user(event):
    async def topup_user_(event):
        random_numbers = [random.randint(0, 99) for _ in range(3)]
        
        async with bot.conversation(chat) as nominal_conv:
            await event.edit('Harap Topup minimal Rp.1000')
            nominal_msg = await nominal_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            nominal = int(nominal_msg.raw_text.strip()) if nominal_msg.raw_text.strip().isdigit() else 0

        if nominal < 1000:
            await event.respond("`Nominal tidak memenuhi syarat, minimal transaksi Rp. 1000`")
            sys.exit()  
        else:
            result = sum(random_numbers) + nominal

        await event.edit("Processing...")
        time.sleep(1)

        try:
            dana_gopay_list = tampilkan_dana_gopay()  # Fungsi untuk menampilkan metode pembayaran

            if dana_gopay_list:
                dana_gopay_str = "\n".join(dana_gopay_list)
                msg = f"""
**═════════════════════════**
**       🕊 Informasi Pembayaran 🕊**
**═════════════════════════**
{dana_gopay_str}
**═════════════════════════**
**Total pembayaran Rp.**`{result}`
**Pembayaran QRIS:**
https://i.imghippo.com/files/hpw8623eUo.jpg
**═════════════════════════**
**🗒️NOTES:**
**Jika topup belum masuk, segera**
**hubungi admin! Kirim bukti transfer**
**ke admin untuk mempercepat proses** 
**transaksi. Admin** @RiswanJabar
**═════════════════════════**
          **☞ó ‌つò☞ 𝓡𝓲𝓼𝓾𝓪𝓷𝓙𝓪𝓫𝓪𝓻 𝓢𝓽𝓸𝓻𝓮**
**═════════════════════════**
   """
                buttons = [[Button.inline("main menu", "menu")]]
                await event.respond(msg, buttons=buttons)

                # Cek status pembayaran
                payment_status = check_payment_status(user_id)

                if payment_status == 'completed':
                    # Kirim notifikasi ke admin jika pembayaran sudah selesai
                    admin_id = 7545471466  # Ganti dengan ID pengguna Telegram admin
                    admin_msg = f"User: {sender.username}" f" ID User: `{sender.id}`"  f" telah melakukan top-up. Jumlah: Rp. {result}"
                    await bot.send_message(admin_id, admin_msg)
                else:
                    # Informasikan pengguna untuk menyelesaikan pembayaran
                    await event.respond("`Pembayaran Anda belum selesai, silakan lakukan pembayaran dan kirim bukti transfer ke admin.`")

            else:
                await event.respond("Data pengguna tidak tersedia saat ini.")

        except Exception as e:
            print(f'Error: {e}')
            await event.respond(f"Terjadi kesalahan: {e}")

    chat = event.chat_id
    sender = await event.get_sender()
    user_id = str(event.sender_id)

    # Menambahkan pengguna ke database jika belum ada
    add_user(user_id, sender.username)

    try:
        level = get_level_from_db(user_id)

        if level == 'user':
            await topup_user_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)

    except Exception as e:
        print(f'Error: {e}')

# Memanggil fungsi untuk membuat database dan tabel saat bot dijalankan pertama kali
create_db()