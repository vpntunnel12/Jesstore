from cybervpn import *
from telethon import events, Button
import random
import sys
from datetime import datetime, timedelta
import asyncio

# Fungsi utama untuk menangani timer
async def main(event):
    durasi = 180  # 3 menit
    print("Timer dimulai untuk 3 menit.")
    await asyncio.sleep(durasi)  # Menggunakan async sleep agar tidak memblokir
    await event.respond("**⏳ Waktu habis! Silahkan melakukan top up ulang.**")

@bot.on(events.CallbackQuery(data=b'topup'))
async def topup_user(event):
    async def topup_user_(event):
        random_numbers = [random.randint(0, 99) for _ in range(3)]
        async with bot.conversation(event.chat_id) as nominal_conv:
            await event.edit('**Input nominal topup maksimal Rp.5000**')
            nominal_msg = await nominal_conv.wait_event(events.NewMessage(incoming=True, from_users=event.sender_id))
            nominal = int(nominal_msg.raw_text.strip()) if nominal_msg.raw_text.strip().isdigit() else 0

        if nominal < 5000:
            await event.respond("**Nominal tidak memenuhi syarat. Minimal transaksi Rp.5000.**")
            return  # Keluar dari fungsi jika nominal kurang dari yang ditentukan
        else:
            result = sum(random_numbers) + nominal
            waktu_awal = datetime.now()
            waktu_expired = waktu_awal + timedelta(minutes=1)

            # Kirim notifikasi ke admin
            admin_id = 7545471466  # Ganti dengan ID Telegram admin
            admin_msg = f"""
**═══════════════════**
   **💰PENGGUNA TOPUP💰**
**═══════════════════**
**⚡Username:** @{event.sender.username}
**═══════════════════**
**⚡ID pengguna:** `{event.sender.id}`
**⚡Telah melakukan topUp:**
**⚡Sejumlah Rp.** `{result}`
**═══════════════════**
    **by X 𝓡𝓲𝓼𝔀𝓪𝓷𝓙𝓪𝓫𝓪𝓻 𝓢𝓽𝓸𝓻𝓮**
**═══════════════════**
            """
            await bot.send_message(admin_id, admin_msg)  # Kirim pesan ke admin

            # Proses transaksi
            await event.edit("Processing...")
            await event.edit("Processing....")
            await asyncio.sleep(1)  # Gunakan async sleep agar tidak memblokir
            await event.edit("`Processing transaction`")
            await asyncio.sleep(1)
            await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
            await asyncio.sleep(1)
            await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
            await asyncio.sleep(1)
            await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
            await asyncio.sleep(1)
            await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
            await asyncio.sleep(1)
            await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒`")
            await asyncio.sleep(1)
            await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
            await asyncio.sleep(1)
            await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
            await asyncio.sleep(1)
            await event.edit("`Processing... 100%\n█████████████████████████ `")

            try:
                dana_gopay_list = tampilkan_dana_gopay()  # Fungsi ini harus didefinisikan di tempat lain

                if dana_gopay_list:
                    dana_gopay_str = "\n".join(dana_gopay_list)
                    msg = f"""
**───〔 DEPOSIT 〕───**
**────────────────**
{dana_gopay_str}
**────────────────**
**Total pembayaran:** Rp`{result}`
**Waktu transaksi :** {waktu_awal.strftime("%H:%M:%S")}
**Kode transaksi:** {sum(random_numbers)}`
**Expired transaksi:** {waktu_expired.strftime("%H:%M:%S")}
**────────────────**
**NOTE:**
**Jika sudah melakukan pembayaran, tapi saldo**
**belum masuk selama 5 menit hubungi** @RiswanJabar
**────────────────**                
                    """
                    buttons = [[Button.inline("‹Back ke menu›", "menu")]]
                    
                    # Link gambar untuk informasi pembayaran
                    image_url = "https://i.imghippo.com/files/Rfn7163R.jpg"
                    # Kirim gambar dengan detail pembayaran
                    await bot.send_photo(event.chat_id, image_url, caption=msg, buttons=buttons)
                    await main(event)
                else:
                    await event.respond("Data pengguna tidak tersedia saat ini.")

            except Exception as e:
                print(f'Error: {e}')
                await event.respond(f"Terjadi kesalahan: {e}")

    try:
        # Ambil level pengguna dari database (pastikan fungsi ini bekerja dengan benar)
        user_id = str(event.sender_id)
        level = get_level_from_db(user_id)
        print(f'Memanggil level dari database: {level}')

        if level == 'user':
            await topup_user_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')
        await event.respond(f"Terjadi kesalahan saat memeriksa level: {e}")