from cybervpn import *
from telethon import events, Button
import random
import sys
from datetime import datetime, timedelta
import asyncio
import time

async def topup_user_(event):
    # Langkah sebelumnya tetap sama
    # ... [Prompt nominal dan validasi jumlah]

    if nominal < 25000:
        await event.respond("**Nominal tidak memenuhi syarat, minimal transaksi RP. 25000**")
    else:
        result = sum(random_numbers) + nominal
        waktu_awal = datetime.now()
        waktu_expired = waktu_awal + timedelta(minutes=3)

        # Informasi pembayaran
        await event.edit("`Silakan lakukan pembayaran...`")
        dana_gopay_list = tampilkan_dana_gopay()  # Contoh list metode pembayaran
        if dana_gopay_list:
            dana_gopay_str = "\n".join(dana_gopay_list)
            await event.respond(f"Silakan transfer ke salah satu akun berikut:\n{dana_gopay_str}\n"
                                 f"Jumlah: Rp.{result}\n"
                                 "Waktu Kadaluarsa: 3 menit.")
        
        # Tunggu pembayaran (cek status berkala setiap 10 detik hingga expired)
        for _ in range(18):  # 3 menit / 10 detik = 18 kali cek
            if await cek_status_pembayaran("123456789", result):  # Contoh nomor rekening
                await event.respond("✅ Pembayaran berhasil! Terima kasih.")
                break
            await asyncio.sleep(10)
        else:
            await event.respond("❌ Pembayaran tidak terdeteksi. Transaksi dibatalkan.")

        # Logika setelah sukses/tidak sukses