from cybervpn import *
from telethon import events, Button
import random
import sys
from datetime import datetime, timedelta
import asyncio
import time

async def main(event):
    durasi = 180
    print("Timer dimulai untuk 3 menit.")
    await asyncio.sleep(durasi)
    await event.respond("Waktu transaksi sudah habis!")

@bot.on(events.CallbackQuery(data=b'topup'))
async def topup_user(event):
    async def topup_user_(event):
        random_numbers = [random.randint(0, 99) for _ in range(3)]
        async with bot.conversation(chat) as nominal_conv:
            await event.edit('Harap Topup minimal Rp. 40,000')
            nominal_msg = await nominal_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            nominal = int(nominal_msg.raw_text.strip()) if nominal_msg.raw_text.strip().isdigit() else 0

        if nominal < 40000:
            await event.respond("`Nominal tidak memenuhi syarat, minimal transaksi RP. 40,000`")
            sys.exit()  
        else:
            result = sum(random_numbers) + nominal
            waktu_awal = datetime.now()
            waktu_expired = waktu_awal + timedelta(minutes=1)

        await event.edit("Processing...")
        await event.edit("Processing....")
        time.sleep(1)
        await event.edit("`Processing transaction`")
        time.sleep(1)
        await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒`")
        time.sleep(1)
        await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 100%\n█████████████████████████ `")

        try:
            dana_gopay_list = tampilkan_dana_gopay()

            if dana_gopay_list:
                dana_gopay_str = "\n".join(dana_gopay_list)
                msg = f"""
**•────────────────────────•**
**       🕊 Informasi Pembayaran 🕊**
**•────────────────────────•**
{dana_gopay_str}
**•────────────────────────•**
**Harus di bayar total.**`{result}`
**Expired 3menit**
**•────────────────────────•**
**🗒️NOTES:**
**🏷️Setelah melakukan topup, harap**
**🏷️kirim bukti transfer ke admin** 
**🏷️untuk mempercepat proses transaksi!**
**👤Admin** @RiswanJabar
**•────────────────────────•**
                """
                buttons = [[Button.inline("main menu", "menu")]]
                await event.respond(msg, buttons=buttons)
                await main(event)
                
                # Otomatis memproses saldo setelah top-up berhasil
                await process_balance(sender.id, nominal, result)
            else:
                await event.respond("Data pengguna tidak tersedia saat ini.")

        except Exception as e:
            print(f'Error: {e}')
            await event.respond(f"Terjadi kesalahan: {e}")

    chat = event.chat_id
    sender = await event.get_sender()
    user_id = str(event.sender_id)

    try:
        level = get_level_from_db(user_id)
        print(f'Mengambil level dari database: {level}')

        if level == 'user':
            await topup_user_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')

# Fungsi untuk memproses saldo setelah top-up
async def process_balance(user_id, nominal, result):
    # Di sini Anda dapat menambahkan logika untuk memperbarui saldo pengguna di database
    try:
        current_balance = get_balance_from_db(user_id)  # Mengambil saldo pengguna dari DB
        new_balance = current_balance + result  # Menambahkan hasil top-up ke saldo pengguna

        # Memperbarui saldo pengguna di database
        update_balance_in_db(user_id, new_balance)
        print(f"Saldo diproses untuk pengguna {user_id}: Saldo baru adalah {new_balance}")

        # Mengirimkan pesan konfirmasi ke pengguna
        await bot.send_message(user_id, f"Topup berhasil! Saldo baru Anda adalah Rp. {new_balance}")
    except Exception as e:
        print(f"Terjadi kesalahan saat memproses saldo pengguna {user_id}: {e}")
        await bot.send_message(user_id, "Terjadi kesalahan saat memproses saldo Anda.")

# Fungsi untuk mendapatkan saldo saat ini dari pengguna (contoh)
def get_balance_from_db(user_id):
    # Ambil saldo pengguna dari database (ini hanya placeholder)
    return 100000  # Placeholder saldo saat ini

# Fungsi untuk memperbarui saldo pengguna di database (contoh)
def update_balance_in_db(user_id, new_balance):
    # Perbarui saldo pengguna di database (ini hanya placeholder)
    print(f"Saldo pengguna {user_id} telah diperbarui: {new_balance}")