from cybervpn import *
from telethon import events, Button
import random
import sys
from datetime import datetime, timedelta
import asyncio

# Fungsi dummy untuk mendapatkan saldo pengguna dari database.
async def get_user_balance(user_id):
    # Gantilah dengan pemanggilan database asli untuk mendapatkan saldo pengguna.
    return 5000  # Misalnya pengguna memulai dengan saldo 5000

# Fungsi dummy untuk memperbarui saldo pengguna di database.
async def update_user_balance(user_id, new_balance):
    # Gantilah dengan pemanggilan database asli untuk memperbarui saldo pengguna.
    print(f"Saldo pengguna {user_id} diperbarui menjadi {new_balance}")

async def main(event):
    durasi = 180
    print("Timer dimulai untuk 3 menit.")
    await asyncio.sleep(durasi)
    await event.respond("Waktu transaksi sudah habis!")

@bot.on(events.CallbackQuery(data=b'topup'))
async def topup_user(event):
    async def topup_user_(event):
        random_numbers = [random.randint(0, 99) for _ in range(3)]
        async with bot.conversation(chat) as nominal_conv:
            await event.edit('Harap Topup minimal Rp.8000')
            nominal_msg = await nominal_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            nominal = int(nominal_msg.raw_text.strip()) if nominal_msg.raw_text.strip().isdigit() else 0

        if nominal < 8000:
            await event.respond("`Nominal tidak memenuhi syarat, minimal transaksi RP. 8000`")
            return
        
        result = sum(random_numbers) + nominal
        waktu_awal = datetime.now()
        waktu_expired = waktu_awal + timedelta(minutes=1)

        await event.edit("Processing...")
        await asyncio.sleep(1)
        await event.edit("`Processing transaction`")
        await asyncio.sleep(1)

        progress_steps = [
            (0, "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"),
            (4, "█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"),
            (8, "██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"),
            (20, "█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"),
            (36, "█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"),
            (52, "█████████████▒▒▒▒▒▒▒▒▒▒▒▒"),
            (84, "█████████████████████▒▒▒▒"),
            (100, "█████████████████████████")
        ]

        for percent, progress in progress_steps:
            await event.edit(f"`Processing... {percent}%\n{progress}`")
            await asyncio.sleep(1)

        try:
            # Mengambil saldo pengguna saat ini dari database
            current_balance = await get_user_balance(user_id)
            print(f"Saldo sebelum top-up: {current_balance}")

            # Menambahkan saldo dengan jumlah top-up
            new_balance = current_balance + result

            # Memperbarui saldo pengguna di database
            await update_user_balance(user_id, new_balance)

            # Memberitahukan pengguna bahwa top-up berhasil dan saldo baru
            await event.edit(f"Top-up berhasil! Saldo Anda sekarang adalah: RP. {new_balance}")

            dana_gopay_list = tampilkan_dana_gopay()

            if dana_gopay_list:
                dana_gopay_str = "\n".join(dana_gopay_list)
                msg = f"""
**•────────────────────────•**
**       🕊 Informasi Pembayaran 🕊**
**•────────────────────────•**
{dana_gopay_str}
**•────────────────────────•**
**PEMBAYARAN TRX RP.**`{result}`
**EXPIRED TOPUP 3 MENIT**
**•────────────────────────•**
**🗒️NOTES:**
**🏷️Setelah melakukan topup, harap**
**🏷️kirim bukti transfer ke admin** 
**🏷️untuk mempercepat proses transaksi!**
**👤Admin** @R23_VPNSTORE
**👤Admin** wa.me/6285888801241
**•────────────────────────•**
                """
                buttons = [[Button.inline("↪️main menu↩️", "menu")]]
                await event.respond(msg, buttons=buttons)
                await main(event)
            else:
                await event.respond("Data pengguna tidak tersedia saat ini.")

        except Exception as e:
            print(f'Error: {e}')
            await event.respond(f"Terjadi kesalahan: {e}")

    chat = event.chat_id
    sender = await event.get_sender()
    user_id = str(event.sender_id)

    try:
        level = get_level_from_db(user_id)
        print(f'Mendapatkan level dari database: {level}')

        if level == 'user':
            await topup_user_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')