from cybervpn import *
from telethon import events, Button
import random
import sys
from datetime import datetime, timedelta
import asyncio
import time

ADMIN_ID = 7545471466  # Ganti dengan ID Admin yang sebenarnya

async def main(event):
    durasi = 180
    print("Timer dimulai untuk 3 menit.")
    await asyncio.sleep(durasi)
    await event.respond("Waktu transaksi sudah habis!")

@bot.on(events.CallbackQuery(data=b'topup'))
async def topup_user(event):
    async def topup_user_(event):
        random_numbers = [random.randint(0, 99) for _ in range(3)]
        async with bot.conversation(chat) as nominal_conv:
            await event.edit('**Input nominal topup:**')
            nominal_msg = await nominal_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            nominal = int(nominal_msg.raw_text.strip()) if nominal_msg.raw_text.strip().isdigit() else 0

        # Periksa jika nominal lebih kecil dari 1000
        if nominal < 1000:
            await event.respond("**Nominal tidak memenuhi syarat. Minimal transaksi adalah RP.1.000.**")
            sys.exit()  
        else:
            result = sum(random_numbers) + nominal
            waktu_awal = datetime.now()
            waktu_expired = waktu_awal + timedelta(minutes=1)

        await event.edit("Processing...")
        await event.edit("Processing....")
        time.sleep(1)
        await event.edit("`Processing transaction`")
        time.sleep(1)
        await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒`")
        time.sleep(1)
        await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 100%\n█████████████████████████ `")

        try:
            dana_gopay_list = tampilkan_dana_gopay()

            if dana_gopay_list:
                dana_gopay_str = "\n".join(dana_gopay_list)
                msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
**     🕊 Informasi Pembayaran 🕊**
**◇━━━━━━━━━━━━━━━━━◇**
{dana_gopay_str}
**◇━━━━━━━━━━━━━━━━━◇**
** Nominal yang harus di bayar:**
** TRX:** RP.`{result}`
** Kode transaksi:** `{sum(random_numbers)}`
** Waktu transaksi hanya 3 menit**
** Waktu transaksi: {waktu_awal.strftime("%H:%M:%S")}**
** Expired transaksi: {waktu_expired.strftime("%H:%M:%S")}**
**◇━━━━━━━━━━━━━━━━━◇**
**Notice:** 
**Setelah melakukan topup, 
**harap kirim bukti transfer 
**ke admin @RiswanJabar
**◇━━━━━━━━━━━━━━━━━◇**
                """
                buttons = [[Button.inline("‹   ›", "menu")]]
                await event.respond(msg, buttons=buttons)
                await main(event)

                # Cek status pembayaran setelah transaksi dimulai
                await check_payment_status(event, result, waktu_expired, random_numbers)

            else:
                await event.respond("Data pengguna tidak tersedia saat ini.")

        except Exception as e:
            print(f'Error: {e}')
            await event.respond(f"Terjadi kesalahan: {e}")

    chat = event.chat_id
    sender = await event.get_sender()
    user_id = str(event.sender_id)  # ID Pengguna yang melakukan transaksi

    try:
        level = get_level_from_db(user_id)
        print(f'Mengambil level dari database: {level}')

        if level == 'user':
            await topup_user_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')

async def check_payment_status(event, result, waktu_expired, random_numbers):
    """
    Fungsi ini untuk memeriksa apakah pembayaran telah diterima dan mengirimkan notifikasi.
    Fungsi ini dipanggil setelah proses top-up selesai untuk memonitor status pembayaran.
    """
    # Anda bisa mengimplementasikan verifikasi pembayaran yang sesuai dengan sistem Anda
    await asyncio.sleep(30)  # Simulasi delay untuk konfirmasi pembayaran pengguna
    
    # Asumsikan pembayaran telah dikonfirmasi setelah delay di atas
    payment_confirmed = True  # Ini sebaiknya diubah dengan logika verifikasi pembayaran yang sebenarnya
    
    if payment_confirmed:
        msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
**     🕊 Pembayaran Dikonfirmasi 🕊**
**◇━━━━━━━━━━━━━━━━━◇**
** Pembayaran telah diterima!**
** TRX yang dibayar: RP.`{result}`**
** Kode transaksi: `{sum(random_numbers)}`
** Waktu transaksi: {waktu_awal.strftime("%H:%M:%S")}**
** Waktu pembayaran diterima: {datetime.now().strftime("%H:%M:%S")}**
**◇━━━━━━━━━━━━━━━━━◇**
**Terima kasih atas transaksi Anda!**
**◇━━━━━━━━━━━━━━━━━◇**
        """
        await event.respond(msg)

        # Kirim notifikasi ke admin setelah pembayaran dikonfirmasi
        await send_notification_to_admin(result, random_numbers, event, user_id)

    else:
        await event.respond("**Pembayaran belum diterima. Harap periksa bukti transfer Anda dan kirimkan ke admin.**")

async def send_notification_to_admin(result, random_numbers, event, user_id):
    """
    Fungsi untuk mengirimkan notifikasi kepada admin setelah pembayaran dikonfirmasi.
    """
    admin_msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
**     🕊 Pembayaran Diterima 🕊**
**◇━━━━━━━━━━━━━━━━━◇**
** Pembayaran berhasil dengan rincian:**
** TRX yang dibayar: RP.`{result}`**
** Kode transaksi: `{sum(random_numbers)}`
** Waktu transaksi: {event.time.strftime("%H:%M:%S")}**
** Waktu pembayaran diterima: {datetime.now().strftime("%H:%M:%S")}**
** ID Pengguna: {user_id}** 
**◇━━━━━━━━━━━━━━━━━◇**
**Harap diproses segera.**
**◇━━━━━━━━━━━━━━━━━◇**
    """
    
    # Kirimkan pesan ke admin
    await bot.send_message(ADMIN_ID, admin_msg)