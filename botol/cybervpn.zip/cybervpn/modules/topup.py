from telethon import events, Button
from cybervpn import *
import random
import asyncio
from datetime import datetime, timedelta

# Fungsi timer untuk kedaluwarsa transaksi
async def main(event):
    durasi = 180  # Timer 3 menit untuk top-up kedaluwarsa
    print("Timer dimulai untuk 3 menit.")
    await asyncio.sleep(durasi)
    await event.respond("Maap Waktu transaksi sudah habis!")  # Pesan kedaluwarsa

# Fungsi untuk menangani top-up otomatis
async def topup_user(event):
    # Menghasilkan nominal otomatis (Rp. 8000 - Rp. 100000)
    nominal = random.randint(8000, 100000)  # Anda dapat menyesuaikan batas maksimum sesuai kebutuhan
    random_numbers = [random.randint(0, 99) for _ in range(3)]  # Angka acak untuk simulasi proses

    result = sum(random_numbers) + nominal  # Jumlah total untuk transaksi
    waktu_awal = datetime.now()
    waktu_expired = waktu_awal + timedelta(minutes=3)  # Kadaluarsa setelah 3 menit

    # Mensimulasikan proses dengan pembaruan progres
    await event.edit("Processing...")
    await asyncio.sleep(1)
    await event.edit("Processing....")
    await asyncio.sleep(1)
    await event.edit("`Processing transaction`")
    await asyncio.sleep(1)
    await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
    await asyncio.sleep(1)
    await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
    await asyncio.sleep(1)
    await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
    await asyncio.sleep(1)
    await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
    await asyncio.sleep(1)
    await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒`")
    await asyncio.sleep(1)
    await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
    await asyncio.sleep(1)
    await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
    await asyncio.sleep(1)
    await event.edit("`Processing... 100%\n█████████████████████████ `")

    try:
        # Mengambil metode pembayaran GoPay yang tersedia
        dana_gopay_list = tampilkan_dana_gopay()

        if dana_gopay_list:
            dana_gopay_str = "\n".join(dana_gopay_list)
            msg = f"""
    **•────────────────────────•**
    **       🕊 Informasi Pembayaran 🕊**
    **•────────────────────────•**
    {dana_gopay_str}
    **•────────────────────────•**
    **PEMBAYARAN TRX RP.**`{result}`
    **EXPIRED TOPUP 3 MENIT**
    **•────────────────────────•**
    **🗒️NOTES:**
    **🏷️Setelah melakukan topup, harap**
    **🏷️kirim bukti transfer ke admin** 
    **🏷️untuk mempercepat proses transaksi!**
    **👤Admin** @R23_VPNSTORE
    **👤Admin** wa.me/6285888801241
    **•────────────────────────•**
    """
            buttons = [[Button.inline("↪️main menu↩️", "menu")]]
            await event.respond(msg, buttons=buttons)
            await main(event)  # Mulai timer 3 menit
        else:
            await event.respond("Data pengguna tidak tersedia saat ini.")  # Jika daftar GoPay kosong

    except Exception as e:
        print(f'Error: {e}')
        await event.respond(f"Terjadi kesalahan: {e}")

# Event handler untuk klik tombol 'topup'
@bot.on(events.CallbackQuery(data=b'topup'))
async def handle_topup(event):
    chat = event.chat_id
    sender = await event.get_sender()
    user_id = str(event.sender_id)

    try:
        level = get_level_from_db(user_id)  # Mengambil level pengguna dari database
        print(f'Mengambil level dari database: {level}')

        if level == 'user':  # Memeriksa apakah pengguna diizinkan untuk top-up
            await topup_user(event)  # Otomatis mulai proses top-up
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')
        await event.answer(f'Terjadi kesalahan: {e}', alert=True)