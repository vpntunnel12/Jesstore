import random
import sys
from datetime import datetime, timedelta
import asyncio
from telethon import events, Button
import logging

logging.basicConfig(level=logging.INFO)

# Fungsi untuk menambah saldo (harus diubah sesuai dengan sistem saldo yang Anda gunakan)
def tambah_saldo_user(user_id, amount):
    # Di sini, Anda bisa mengganti dengan logika untuk memperbarui saldo di database atau sistem Anda
    logging.info(f"Saldo pengguna {user_id} ditambah sebesar Rp {amount}.")
    # Simulasi memperbarui saldo (misalnya memperbarui di database atau struktur data)
    return True

async def main(event):
    durasi = 180
    logging.info("Timer dimulai untuk 3 menit.")
    await asyncio.sleep(durasi)
    await event.respond("Waktu transaksi sudah habis!")

async def topup_user_(event):
    random_numbers = [random.randint(0, 99) for _ in range(3)]
    
    # Secara otomatis menghitung nominal (menyimulasikan top-up dengan jumlah acak)
    nominal = random.randint(8000, 50000)  # Tentukan rentang top-up otomatis
    
    # Menghitung hasil berdasarkan angka acak dan nominal
    result = sum(random_numbers) + nominal
    waktu_awal = datetime.now()
    waktu_expired = waktu_awal + timedelta(minutes=1)

    await event.edit("Processing...")

    # Simulasikan update progress bar
    await process_progress(event)

    try:
        # Secara otomatis memperbarui saldo pengguna tanpa meminta input
        if tambah_saldo_user(str(event.sender_id), result):
            msg = f"""
**•────────────────────────•**
**       🕊 Informasi Pembayaran 🕊**
**•────────────────────────•**
`{dana_gopay_str}`
**PEMBAYARAN TRX RP.**`{result}`
**EXPIRED TOPUP 3 MENIT**
**•────────────────────────•**
**🗒️NOTES:**
**🏷️Top-up otomatis berhasil!**
**🏷️Saldo Anda telah diperbarui.**
**👤Admin** @R23_VPNSTORE
**•────────────────────────•**
            """
            buttons = [[Button.inline("↪️MAIN MENU↩️", "menu")]]
            await event.respond(msg, buttons=buttons)
            await main(event)
        else:
            await event.respond("Terjadi kesalahan saat memperbarui saldo.")

    except Exception as e:
        logging.error(f"Error: {e}")
        await event.respond(f"Terjadi kesalahan: {e}")

async def process_progress(event):
    progress_steps = [
        (0, "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"),
        (4, "█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"),
        (8, "██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"),
        (20, "█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"),
        (36, "█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"),
        (52, "█████████████▒▒▒▒▒▒▒▒▒▒▒▒"),
        (84, "█████████████████████▒▒▒▒"),
        (100, "█████████████████████████")
    ]
    
    for percent, bar in progress_steps:
        await event.edit(f"`Processing... {percent}%\n{bar} `")
        await asyncio.sleep(1)

@bot.on(events.CallbackQuery(data=b'topup'))
async def topup_user(event):
    chat = event.chat_id
    sender = await event.get_sender()
    user_id = str(event.sender_id)

    try:
        level = get_level_from_db(user_id)
        logging.info(f'Mengambil level dari database: {level}')

        if level == 'user':
            await topup_user_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        logging.error(f"Error: {e}")
        await event.respond(f"Terjadi kesalahan: {e}")