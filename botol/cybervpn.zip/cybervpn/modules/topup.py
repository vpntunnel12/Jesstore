from cybervpn import *
from telethon import events, Button
import random
import sys
from datetime import datetime, timedelta
import asyncio
import time

# Handler for 'topup' callback
@bot.on(events.CallbackQuery(data=b'topup'))
async def topup_user(event):
    async def topup_user_(event):
        random_numbers = [random.randint(0, 99) for _ in range(3)]
        
        async with bot.conversation(chat) as nominal_conv:
            await event.edit('Harap Topup minimal Rp.1000')
            nominal_msg = await nominal_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            nominal = int(nominal_msg.raw_text.strip()) if nominal_msg.raw_text.strip().isdigit() else 0

        # Check if the nominal is valid
        if nominal < 1000:
            await event.respond("`Nominal tidak memenuhi syarat, minimal transaksi Rp. 1000`")
            sys.exit()  
        else:
            result = sum(random_numbers) + nominal

        # Process the transaction and show progress
        await event.edit("Processing...")
        time.sleep(1)
        await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒`")
        time.sleep(1)
        await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 100%\n█████████████████████████ `")

        try:
            dana_gopay_list = tampilkan_dana_gopay()  # Assuming this function retrieves payment methods

            if dana_gopay_list:
                dana_gopay_str = "\n".join(dana_gopay_list)
                msg = f"""
**═════════════════════════**
**       🕊 Informasi Pembayaran 🕊**
**═════════════════════════**
{dana_gopay_str}
**═════════════════════════**
**Total pembayaran Rp.**`{result}`
**Pembayaran QRIS:**
https://i.imghippo.com/files/hpw8623eUo.jpg
**═════════════════════════**
**🗒️NOTES:**
**Jika topup belum masuk, segera**
**hubungi admin! Kirim bukti transfer**
**ke admin untuk mempercepat proses** 
**transaksi. Admin** @RiswanJabar
**═════════════════════════**
          **☞ó ‌つò☞ 𝓡𝓲𝓼𝔀𝓪𝓷𝓙𝓪𝓫𝓪𝓻 𝓢𝓽𝓸𝓻𝓮**
**═════════════════════════**
   """
                buttons = [[Button.inline("main menu", "menu")]]
                await event.respond(msg, buttons=buttons)

                # Kirim notifikasi ke admin setelah transaksi top-up berhasil
                admin_id = 7545471466  # Ganti dengan ID pengguna Telegram admin
                admin_msg = f"User: {sender.username}" f"ID User: `{sender.id}`" f"telah melakukan top-up. Jumlah: Rp. {result}"
                await bot.send_message(admin_id, admin_msg)  # Kirim pesan ke admin

            else:
                await event.respond("Data pengguna tidak tersedia saat ini.")

        except Exception as e:
            print(f'Error: {e}')
            await event.respond(f"Terjadi kesalahan: {e}")

    chat = event.chat_id
    sender = await event.get_sender()
    user_id = str(event.sender_id)

    try:
        level = get_level_from_db(user_id)  # Retrieve user level from the database
        print(f'Memanggil level dari database: {level}')

        if level == 'user':
            await topup_user_(event)  # Proceed with the top-up process if the user is at the 'user' level
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)  # Deny access if the user is not at the 'user' level
    except Exception as e:
        print(f'Error: {e}')