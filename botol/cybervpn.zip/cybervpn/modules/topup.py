# Contoh penyimpanan saldo pengguna (gunakan database nyata di produksi)
user_balances = {}

async def main(event):
    durasi = 180  # Timer 3 menit
    print("Timer dimulai untuk 3 menit.")
    await asyncio.sleep(durasi)
    await event.respond("Waktu transaksi sudah habis!")

@bot.on(events.CallbackQuery(data=b'topup'))
async def topup_user(event):
    async def topup_user_(event):
        # Menghasilkan jumlah top-up secara acak antara 1000 dan 50000 (atau sesuaikan sesuai kebutuhan)
        topup_amount = random.randint(1000, 50000)

        # Anda juga bisa mengubah ini menjadi jumlah tetap jika diinginkan
        # topup_amount = 10000  # Jumlah tetap untuk top-up

        random_numbers = [random.randint(0, 99) for _ in range(3)]
        result = sum(random_numbers) + topup_amount  # Jumlah akhir setelah menambahkan angka acak

        # Menghitung waktu kedaluwarsa (meskipun tidak digunakan untuk proses ini, tetap dipertahankan jika ingin mengimplementasikannya)
        waktu_awal = datetime.now()
        waktu_expired = waktu_awal + timedelta(minutes=3)  # Misalnya, top-up kedaluwarsa dalam 3 menit

        # Memperbarui saldo pengguna secara otomatis
        user_id = str(event.sender_id)
        if user_id in user_balances:
            user_balances[user_id] += result
        else:
            user_balances[user_id] = result  # Inisialisasi saldo jika pengguna baru

        # Menampilkan saldo yang diperbarui kepada pengguna
        updated_balance = user_balances[user_id]

        try:
            # Mengasumsikan tampilkan_dana_gopay() adalah fungsi yang menampilkan metode pembayaran (tambahkan implementasi nyata Anda di sini)
            dana_gopay_list = tampilkan_dana_gopay()

            if dana_gopay_list:
                dana_gopay_str = "\n".join(dana_gopay_list)
                msg = f"""
**•────────────────────────•**
**       🕊 Informasi Pembayaran 🕊**
**•────────────────────────•**
{dana_gopay_str}
**•────────────────────────•**
**PEMBAYARAN TRX RP.**`{result}`
**Saldo anda saat ini: Rp. {updated_balance}`
**EXPIRED TOPUP 3 MENIT**
**•────────────────────────•**
**🗒️NOTES:**
**🏷️Setelah melakukan topup, harap kirim bukti transfer ke admin untuk mempercepat proses transaksi!**
**👤Admin** @R23_VPNSTORE
**👤Admin** wa.me/6285888801241
**•────────────────────────•**
                """
                buttons = [[Button.inline("↪️main menu↩️", "menu")]]
                await event.respond(msg, buttons=buttons)
                await main(event)
            else:
                await event.respond("Data pengguna tidak tersedia saat ini.")

        except Exception as e:
            print(f'Error: {e}')
            await event.respond(f"Terjadi kesalahan: {e}")

    chat = event.chat_id
    sender = await event.get_sender()
    user_id = str(event.sender_id)

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await topup_user_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')