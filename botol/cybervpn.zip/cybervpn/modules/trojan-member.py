from cybervpn import *
import requests
import subprocess
import datetime as DT
import subprocess
import re


@bot.on(events.CallbackQuery(data=b'create-trojan-member'))
async def create_trojan(event):
    async def create_trojan_(event):
        # Conversation with user for username
        async with bot.conversation(chat) as user_conv:
            await event.respond('**Username:**')
            user = (await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        # Buttons for expiry days (only 30 days now)
        async with bot.conversation(chat) as exp_conv:
            await event.respond('**Choose Expiry (in days):**', buttons=[
                [Button.inline(" 30 Days ", "30")]
            ])
            exp = (await exp_conv.wait_event(events.CallbackQuery)).data.decode("ascii")

        # Buttons for IP limit (only 2 IPs now)
        async with bot.conversation(chat) as login_ip_conv:
            await event.respond('**Choose Login IP (IP limit):**', buttons=[
                [Button.inline(" 2 IPs ", "2")]
            ])
            login_ip = (await login_ip_conv.wait_event(events.CallbackQuery)).data.decode("ascii")

        await event.edit("`Wait.. Setting up an Account`")
        cmd = f'printf "%s\n" "{user}" "{exp}" "100" "{login_ip}" | addtr-bot'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            print(f'Error: {e}')
            print(f'Subprocess output: {a}')
            await event.respond(f"Terjadi kesalahan: {e}\nSubproses output: {a}")
            return  # Stop execution if there's an error

        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))
        creation_date = today.strftime('%Y-%m-%d')  # Creation date as string

        b = [x.group() for x in re.finditer("trojan://(.*)", a)]
        print(b)
        domain = re.search("@(.*?):", b[0]).group(1)
        uuid = re.search("trojan://(.*?)@", b[0]).group(1)
        
        msg = f"""
**═════════════════════════**
**⚡BUAT AKUN TROJAN PREMIUM⚡**
**═════════════════════════**
**Remarks:** `{user}`
**Host Server:** `{DOMAIN}`
**Login IP:** `{login_ip}` **IP**
**═════════════════════════**
**Port TLS:** `443, 400-900`
**Port NTLS:** `80, 8080, 8081-9999`
**UUID:** `{uuid}`
**NetWork:** `(WS) or (gRPC)`
**Path:** `/trojan`
**ServiceName:** `trojan-grpc`
**═════════════════════════**
**TROJAN URL TLS:**
```{b[0]}```
**═════════════════════════**
**TROJAN URL HTTP:**
```{b[1].replace(" ","")}```
**═════════════════════════**
**TROJAN URL gRPC:** 
```{b[2].replace(" ","")}```
**═════════════════════════**
**🗓️Tanggal Pembuatan:** `{creation_date}`
**🗓️Aktip Sampai Tanggal:** `{later}`
**⚡order** `{exp}`  **days**
**═════════════════════════**
**☞ó ‌つò☞ 𝓡𝓲𝓼𝓮𝓿𝓮𝓭**
**═════════════════════════**
"""
        await event.respond(msg)

        # Send notification to a specific group
        group_chat_id = -1002029496202  # Replace with your actual group chat ID
        group_msg = f"""
**═══════════════════**
        **⚡Notif Reseller**⚡
**═══════════════════**
**⚡Tanggal:** `{creation_date}`
**═══════════════════**
**⚡ID** `{user_id}`
**⚡Trojan account created**
**⚡Username:** `{user}`
**⚡Login:** `{login_ip}` **IP**
**⚡order** `{exp}`  **days**
**⚡Expired on:** `{later}`
**═══════════════════**
**⚡harga Rp.5000**
**⚡Yuk join Reseller harga**
**⚡Semakin murah jika join**
**⚡saldo awal Rp30.000**
**═══════════════════**
**⚡Join now** @RiswanJabar
**═══════════════════**
"""
        await bot.send_message(group_chat_id, group_msg)  # Send the notification

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await create_trojan_(event)
        else:
            await event.answer(f'Akses Ditolak..!!', alert=True)
    except Exception as e:
        print(f'Error: {e}')

@bot.on(events.CallbackQuery(data=b'cek-tr-member'))
async def cek_trojan(event):
    async def cek_trojan_(event):
        cmd = 'cek-tr'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"""

**◇━━━━━━━━━━━━━━━━━━◇**
   ** ⟨🔸Cek Trojan Account🔸⟩**
**◇━━━━━━━━━━━━━━━━━━◇**
{z}

**Shows Logged In Users Trojan**
""", buttons=[[Button.inline("‹ 𝙼𝚊𝚒𝚗 𝙼𝚎𝚗𝚞 ›", "menu")]])

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await cek_trojan_(event)
        else:
            await event.answer(f'Akses Ditolak..!!', alert=True)
    except Exception as e:
        print(f'Error: {e}')



from datetime import datetime, timedelta
import subprocess
import re
from telethon import events

@bot.on(events.CallbackQuery(data=b'trial-trojan-member'))
async def trial_trojan_buttons(event):
    # Provide only the 60-minute trial option
    await event.respond(
        "Pilih durasi trial Trojan",
        buttons=[
            [Button.inline("Trial 60 Menit", b'trial-trojan-60min')]  # Only 60-minute option
        ]
    )


@bot.on(events.CallbackQuery(data=b'trial-trojan-60min'))
async def trial_trojan_60min(event):
    user_id = str(event.sender_id)

    # Checking user level from database before proceeding
    try:
        level = get_level_from_db(user_id)
        if level == 'user':
            # User has permission to get trial Trojan 60 minutes account
            await create_trial_trojan(expiration_minutes=60)  # Set expiration to 60 minutes
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')
        await event.respond("An error occurred while checking your user level.")


async def create_trial_trojan(expiration_minutes=60):  # Default expiration 60 minutes
    # Loading animation
    await event.edit("Processing.")
    await event.edit("Processing..")
    await event.edit("Processing...")
    await event.edit("Processing....")
    time.sleep(1)
    await event.edit("`Processing Create Premium Account`")
    time.sleep(1)
    await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
    time.sleep(1)
    await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
    time.sleep(1)
    await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
    time.sleep(1)
    await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
    time.sleep(1)
    await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
    time.sleep(1)
    await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
    time.sleep(1)
    await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
    time.sleep(0)
    await event.edit("`Processing... 100%\n█████████████████████████ `")
    time.sleep(1)
    await event.edit("`Wait.. Setting up an Account`")

    # Output command
    cmd = f'printf "%s\n" "trial`</dev/urandom tr -dc X-Z0-9 | head -c4`" "1" "2" "1" | bot-trialtr'

    try:
        a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except Exception as e:
        print(f'Error: {e}')
        await event.respond(f"An error occurred: {e}")
        return  # Stop execution if there's an error

    # Set expiration based on the provided argument
    today = datetime.now()
    later = today + timedelta(minutes=expiration_minutes)  # Set expiration based on input
    exp_time_str = later.strftime("%d-%m-%Y %H:%M:%S")  # Format as DD-MM-YYYY HH:MM:SS for custom expiration

    b = [x.group() for x in re.finditer("trojan://(.*)", a)]
    
    # Extract information from the Trojan URL
    remarks = re.search("#(.*)", b[0]).group(1)
    domain = re.search("@(.*?):", b[0]).group(1)
    uuid = re.search("trojan://(.*?)@", b[0]).group(1)

    # Message formatting for Trojan trial details
    msg = f"""
**═════════════════════════**
**⚡AKUN TRIAL TROJAN PREMIUM⚡**
**═════════════════════════**
**Port TLS:** `443`
**Port NTLS:** `80`
**UUID:** `{uuid}`
**NetWork:** `(WS) or (gRPC)`
**Path:** `/trojan`
**ServiceName:** `trojan-grpc`
**═════════════════════════**
**TROJAN URL TLS:**
```{b[0]}```
**═════════════════════════**
**TROJAN URL HTTP:**
```{b[1].replace(" ","")}```
**═════════════════════════**
**TROJAN URL gRPC:** 
```{b[2].replace(" ","")}```
**═════════════════════════**
**🗓️Masa Aktif:**  `{exp_time_str}`
**═════════════════════════**
**☞ó ‌つò☞ 𝓡𝓲𝓼𝓮𝓽 𝓳𝓪𝓫𝓮𝓻 𝓢𝓽𝓸𝓻𝓮**
**═════════════════════════**
"""
    await event.respond(msg)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        if level == 'user':
            await trial_trojan_(event)
        else:
            await event.answer(f'Akses Ditolak..!!', alert=True)
    except Exception as e:
        print(f'Error: {e}')
@bot.on(events.CallbackQuery(data=b'renew-trojan-member'))
async def ren_trojan(event):
    async def ren_trojan_(event):
        async with bot.conversation(chat) as user:
            await event.respond('**Perhatian! renew akun akan mengenakan biaya sesuai create account')
            await event.respond('**Username:**')
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        
        async with bot.conversation(chat) as exp:
            await event.respond("**Choose Expiry Day**", buttons=[
                [Button.inline(" 30 Day ", "30")]
            ])
            exp = exp.wait_event(events.CallbackQuery)
            exp = (await exp).data.decode("ascii")

        async with bot.conversation(chat) as ip:
            await event.respond("**Choose ip limit**", buttons=[
                [Button.inline(" 2 ip ", "2")]
            ])
            ip = ip.wait_event(events.CallbackQuery)
            ip = (await ip).data.decode("ascii")

        await process_user_balance_trojan(event, user_id)
        cmd = f'printf "%s\n" "{user}" "{exp}" "100" "{ip}" | renewtr'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**User Not Found**")
        else:
            msg = f"""**Successfully Renewed {user} {exp} days limit ip {ip} limit Quota 100GB**"""
            await event.respond(msg)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await ren_trojan_(event)
        else:
            await event.answer(f'Akses Ditolak...!!', alert=True)
    except Exception as e:
        print(f'Error: {e}')



# CEK member tr
@bot.on(events.CallbackQuery(data=b'cek-membertr-member'))
async def cek_tr(event):
    async def cek_tr_(event):
        cmd = 'bash cek-mts'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"""

{z}

**Shows Users from databases**
""", buttons=[[Button.inline("main menu", "menu")]])

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await cek_tr_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')


		
@bot.on(events.CallbackQuery(data=b'delete-trojan'))
async def delete_trojan(event):
	async def delete_trojan_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | bot-deltr'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Not Found**")
		else:
			msg = f"""**Successfully Deleted**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'trojan-member'))
async def trojan(event):
    async def trojan_(event):
        inline = [
[Button.inline("Trial Trojan", "trial-trojan-member"),
 Button.inline("Create Trojan", "create-trojan-member")],
[Button.inline("Check Login", "cek-tr-member"),
 Button.inline("Renew Trojan", "renew-trojan-member")],
[Button.inline("‹ Main Menu ›", "menu")]]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
  **◇⟨🔸TROJAN SERVICE🔸⟩◇**
**◇━━━━━━━━━━━━━━━━━◇**
**» Service:** `TROJAN`
**» Hostname/IP:** `{DOMAIN}`
**» ISP:** `{z["isp"]}`
**» Country:** `{z["country"]}`
**» ** 🤖@RiswanJabar
**◇━━━━━━━━━━━━━━━━━◇**
        """
        await event.edit(msg, buttons=inline)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await trojan_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')

