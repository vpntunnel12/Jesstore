from cybervpn import *
from telethon import events, Button
import subprocess
import datetime as DT
import random
import sqlite3
import random
import time
import re
import json
import base64

conn = sqlite3.connect('users.db')
cursor = conn.cursor()

# Buat tabel jika belum ada
cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        user_id TEXT PRIMARY KEY,
        has_trial INTEGER DEFAULT 0,
        last_trial_date TEXT
    )
''')
conn.commit()

# Fungsi untuk mengecek apakah user bisa trial lagi hari ini
def can_user_trial_again(user_id):
    cursor.execute('SELECT last_trial_date FROM users WHERE user_id = ?', (user_id,))
    result = cursor.fetchone()
    today = DT.date.today().isoformat()
    
    if result is None:
        # Jika user belum ada di database, tambahkan
        cursor.execute('INSERT INTO users (user_id, has_trial, last_trial_date) VALUES (?, ?, ?)', (user_id, 0, None))
        conn.commit()
        return True  # User belum pernah trial, izinkan trial
    
    last_trial_date = result[0]
    
    if last_trial_date is None or last_trial_date != today:
        # Jika user belum trial hari ini, izinkan trial
        return True
    
    # Jika user sudah trial hari ini
    return False

# Fungsi untuk mencatat tanggal trial terakhir
def mark_user_trial_today(user_id):
    today = DT.date.today().isoformat()
    cursor.execute('UPDATE users SET last_trial_date = ? WHERE user_id = ?', (today, user_id))
    conn.commit()

# Simulasi fungsi untuk mendapatkan level pengguna dari database
def get_level_from_db(user_id):
    # Kembalikan level 'user' atau 'admin' tergantung dari user_id
    return 'user'  # Misalnya

@bot.on(events.CallbackQuery(data=b'trial-ssh-member'))
async def trial_ssh(event):
    user_id = str(event.sender_id)
    
    async def trial_ssh_(event):
        user = "Trial-" + str(random.randint(100, 1000))
        pw = "1"
        exp = "1"
        
        # Perintah untuk menambahkan user baru
        cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
        
        try:
            subprocess.check_output(cmd, shell=True)
        except:
            await event.respond("**User Already Exist**")
        else:
            today = DT.date.today()
            msg = f"""
◇━━━━━━━━━━━━━━━━━◇
**◇⟨🔸Ssh & OpenVpn 🔸⟩◇**
◇━━━━━━━━━━━━━━━━━◇
**» Domain:** `{DOMAIN}`
**» Username:** `{user.strip()}`
**» Password:** `{pw.strip()}`
◇━━━━━━━━━━━━━━━━━◇
**» Port OpenSsh :** 443, 80, 22
**» Poer Dropbear :** 443, 109
**» Port Ssh Ws :** 80, 8080
**» Port Ssh Ws Ssl/Tls :** 443
**» Port Ssh UDP :** 1-65535 
**» Port Ovpn Ssl :** 443
**» Port Ovpn TCP :** 443, 1194
**» Port Ovpn UDP :** 2200
**» BadVPN UDP :** 7100, 7300, 7300
◇━━━━━━━━━━━━━━━━━◇
**⟨SSH UDP FOR HTTP CUSTOM⟩**
`{DOMAIN}:1-65535@{user.strip()}:{pw.strip()}`
◇━━━━━━━━━━━━━━━━━◇
**⟨OpenVpn⟩**
https://{DOMAIN}:81/
◇━━━━━━━━━━━━━━━━━◇
**⟨Payload Websocket⟩**
```GET /cdn-cgi/trace HTTP/1.1[crlf]Host: Bug_Kalian[crlf][crlf]GET-RAY / HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]```
◇━━━━━━━━━━━━━━━━━◇
**» Expired Until:** {today}
◇━━━━━━━━━━━━━━━━━◇
**» ** 🤖@Riswanvpnstore
"""
            inline = [
                [Button.url("telegram", "t.me/Riswanvpnstore"),
                 Button.url("whatsapp", "wa.me/6285888801241")]
            ]
            await event.respond(msg, buttons=inline)
    
    # Cek level pengguna dari database
    level = get_level_from_db(user_id)
    
    if level == 'user':
        # Jika pengguna adalah user biasa, cek apakah mereka sudah trial hari ini
        if can_user_trial_again(user_id):
            await trial_ssh_(event)
            # Tandai bahwa pengguna sudah trial hari ini
            mark_user_trial_today(user_id)
        else:
            await event.answer(f"Anda sudah melakukan trial hari ini. Silakan coba lagi besok.", alert=True)
    
    elif level == 'admin':
        # Jika admin, izinkan membuat trial kapan saja tanpa batasan
        await trial_ssh_(event)
    
    else:
        await event.answer(f"Akses Ditolak", alert=True)
