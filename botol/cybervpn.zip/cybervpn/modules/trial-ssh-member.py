from cybervpn import *
from telethon import events, Button
import subprocess
import datetime as DT
import random
import sqlite3
import random
import time
import re
import json
import base64

conn = sqlite3.connect('users.db')
cursor = conn.cursor()

# Buat tabel jika belum ada
cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        user_id TEXT PRIMARY KEY,
        has_trial INTEGER DEFAULT 0,
        last_trial_date TEXT
    )
''')
conn.commit()

# Simulasi fungsi untuk mendapatkan level pengguna dari database
def get_level_from_db(user_id):
    # Kembalikan level 'user' atau 'admin' tergantung dari user_id
    return 'user'  # Misalnya

@bot.on(events.CallbackQuery(data=b'trial-ssh-member'))
async def trial_ssh(event):
    user_id = str(event.sender_id)
    
    async def trial_ssh_(event):
        user = "Trial-" + str(random.randint(100, 1000))
        pw = "1"
        exp = "1"
        
        # Perintah untuk menambahkan user baru
        cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
        
        try:
            subprocess.check_output(cmd, shell=True)
        except:
            await event.respond("**User Already Exist**")
        else:
            today = DT.date.today()
            msg = f"""
**═════════════════════════**
              **❞TRIAL SSH WS❞**
**═════════════════════════**
**❞Host:** `{DOMAIN}`
**❞Username:** `{user.strip()}`
**❞Password:** `{pw.strip()}`
**═════════════════════════**
**❞UDP CUSTOM:**
`{DOMAIN}:1-65535@{user.strip()}:{pw.strip()}`
**═════════════════════════**
**❞SSH CUSTOM:**
`{DOMAIN}:80@{user.strip()}:{pw.strip()}`
**═════════════════════════**
**❞Payload WebSocket⟩**
```GET /cdn-cgi/trace HTTP/1.1[crlf]Host: Bug_Kalian[crlf][crlf]GET-RAY / HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]```
**═════════════════════════**
**❞Expiry Date:** `{today}`
**═════════════════════════**
**☞ó ‌つò☞ 𝓡𝓲𝓼𝔀𝓪𝓷𝓙𝓪𝓫𝓪𝓻 𝓢𝓽𝓸𝓻𝓮**
**═════════════════════════**
"""
            inline = [
                [Button.url("Telegram", "t.me/RiswanJabar"),
                 Button.url("WhatsApp", "wa.me/6285888801241")]
            ]
            
            await event.respond(msg, buttons=inline)
    
    # Cek level pengguna dari database
    level = get_level_from_db(user_id)
    
    if level == 'user':
        # Untuk user biasa, langsung izinkan trial
        await trial_ssh_(event)
    
    elif level == 'admin':
        # Untuk admin, izinkan membuat trial kapan saja tanpa batasan
        await trial_ssh_(event)
    
    else:
        await event.answer(f"Akses Ditolak", alert=True)