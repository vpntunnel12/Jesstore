@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
    user_id = str(event.sender_id)
    
    async def trial_ssh_(event):
        user = "Trial-" + str(random.randint(100, 1000))
        pw = "1"
        exp = "1"
        ip = "1"
        isp = "Your ISP Name Here"  # Specify the ISP name here or fetch it dynamically

        # Add user creation command
        cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
        try:
            subprocess.check_output(cmd, shell=True)
        except:
            await event.respond("**User Already Exist**")
        else:
            today = DT.date.today()
            later = today + DT.timedelta(days=int(exp))
            msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━**
              **❞TRIAL SSH WS❞ **
**━━━━━━━━━━━━━━━━━━━━━━**
**ISP:** `{isp.strip()}`  
**Host:**  `{DOMAIN}`
**Username:**  `{user.strip()}`
**Password:**  `{pw.strip()}`
**━━━━━━━━━━━━━━━━━━━━━━**
**UDP CUSTOM:**
`{DOMAIN}:1-65535@{user.strip()}:{pw.strip()}`
**━━━━━━━━━━━━━━━━━━━━━━**
**SSH CUSTOM:**
`{DOMAIN}:80@{user.strip()}:{pw.strip()}`
**━━━━━━━━━━━━━━━━━━━━━━**
**Payload WebSocket⟩**
```GET /cdn-cgi/trace HTTP/1.1[crlf]Host: Bug_Kalian[crlf][crlf]GET-RAY / HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]```
**━━━━━━━━━━━━━━━━━━━━━━**
**❞Expiration Date:** `{today}`
**━━━━━━━━━━━━━━━━━━━━━━**
**Owner🤖:** @RiswanJabar
"""
            inline = [
                [Button.url("telegram", "t.me/RiswanJabar"),
                 Button.url("whatsapp", "wa.me/6285888801241")]
            ]
            await event.respond(msg, buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await trial_ssh_(event)
        else:
            await event.answer(f'Akses Ditolak...!!', alert=True)
    except Exception as e:
        print(f'Error: {e}')