from cybervpn import *
from telethon import events, Button
import subprocess
import datetime as DT
import random
import sqlite3
import random
import time
import re
import json
import base64

import sqlite3
import datetime as DT
import subprocess
import random
from telethon import events, Button

# Membuka koneksi ke database SQLite
conn = sqlite3.connect('users.db')
cursor = conn.cursor()

# Buat tabel jika belum ada
cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        user_id TEXT PRIMARY KEY,
        has_trial INTEGER DEFAULT 0,
        last_trial_date TEXT
    )
''')
conn.commit()

# Fungsi untuk mengecek apakah user bisa trial lagi hari ini
def can_user_trial_again(user_id):
    cursor.execute('SELECT last_trial_date FROM users WHERE user_id = ?', (user_id,))
    result = cursor.fetchone()
    today = DT.date.today().isoformat()
    
    if result is None:
        # Jika user belum ada di database, tambahkan
        cursor.execute('INSERT INTO users (user_id, has_trial, last_trial_date) VALUES (?, ?, ?)', (user_id, 0, None))
        conn.commit()
        return True  # User belum pernah trial, izinkan trial
    
    last_trial_date = result[0]
    
    if last_trial_date is None or last_trial_date != today:
        # Jika user belum trial hari ini, izinkan trial
        return True
    
    # Jika user sudah trial hari ini
    return False

# Fungsi untuk mencatat tanggal trial terakhir
def mark_user_trial_today(user_id):
    today = DT.date.today().isoformat()
    cursor.execute('UPDATE users SET last_trial_date = ? WHERE user_id = ?', (today, user_id))
    conn.commit()

# Fungsi untuk mendapatkan level pengguna dari database
def get_level_from_db(user_id):
    # Kembalikan level 'user' atau 'admin' tergantung dari user_id
    return 'user'  # Misalnya

@bot.on(events.CallbackQuery(data=b'trial-ssh-member'))
async def trial_ssh(event):
    user_id = str(event.sender_id)
    
    async def trial_ssh_(event):
        if not can_user_trial_again(user_id):
            await event.respond("Anda sudah mendapatkan  SSH hari ini. Coba lagi besok.")
            return

        user = "SSH-RZ-" + str(random.randint(1000, 1000))
        pw = "1"
        exp = "2"
        
        # Perintah untuk menambahkan user baru
        cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
        
        try:
            subprocess.check_output(cmd, shell=True)
        except:
            await event.respond("**User Already Exist**")
        else:
            today = DT.date.today()
            # Tandai pengguna sudah trial hari ini
            mark_user_trial_today(user_id)
            
            msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━**
              **❞TRIAL SSH WS❞ **
**━━━━━━━━━━━━━━━━━━━━━━**
**❞Host:**  `{DOMAIN}`
**❞User:**  `{user.strip()}`
**❞Password:**  `{pw.strip()}`
**━━━━━━━━━━━━━━━━━━━━━━**
**❞UDP COSTUM:**
`{DOMAIN}:1-65535@{user.strip()}:{pw.strip()}`
**━━━━━━━━━━━━━━━━━━━━━━**
**SSH COSTUM:**
`{DOMAIN}:80@{user.strip()}:{pw.strip()}`
**━━━━━━━━━━━━━━━━━━━━━━**
**❞Payload Websocket⟩**
```GET /cdn-cgi/trace HTTP/1.1[crlf]Host: Bug_Kalian[crlf][crlf]GET-RAY / HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]```
**━━━━━━━━━━━━━━━━━━━━━━**
**❞Exp jatuh pada:** `{today}`
**━━━━━━━━━━━━━━━━━━━━━━**
**Owner🤖:** @R23_VPNSTORE
"""
            inline = [
                [Button.url("Telegram", "t.me/R23_VPNSTORE"),
                 Button.url("WhatsApp", "wa.me/6285888801241")]
            ]
            await event.respond(msg, buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await trial_ssh_(event)
        else:
            await event.answer(f'Akses Ditolak...!!', alert=True)
    except Exception as e:
        print(f'Error: {e}')