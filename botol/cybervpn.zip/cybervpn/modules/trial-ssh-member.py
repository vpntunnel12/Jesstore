from cybervpn import *
from telethon import events, Button
import subprocess
import datetime as DT
import random
import sqlite3
import random
import time
import re
import json
import base64

import sqlite3
import datetime as DT
import subprocess
import random
from telethon import events, Button

# Membuka koneksi ke database SQLite
conn = sqlite3.connect('users.db')
cursor = conn.cursor()

# Buat tabel jika belum ada
cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        user_id TEXT PRIMARY KEY,
        trial_expiry_date TEXT,
        login_count INTEGER DEFAULT 0
    )
''')
conn.commit()

# Fungsi untuk mengecek apakah user bisa trial lagi hari ini
def can_user_trial_again(user_id):
    cursor.execute('SELECT trial_expiry_date, login_count FROM users WHERE user_id = ?', (user_id,))
    result = cursor.fetchone()
    today = DT.date.today().isoformat()
    
    if result is None:
        # Jika user belum ada di database, tambahkan
        cursor.execute('INSERT INTO users (user_id, trial_expiry_date, login_count) VALUES (?, ?, ?)', (user_id, None, 0))
        conn.commit()
        return True  # User belum pernah trial, izinkan trial
    
    trial_expiry_date, login_count = result
    
    if trial_expiry_date is None or trial_expiry_date < today:
        # Jika trial sudah kedaluwarsa atau belum ada trial, izinkan trial baru
        return True
    
    if login_count >= 2000:
        # Jika sudah mencapai batas login 2000
        return False

    return True

# Fungsi untuk mencatat tanggal kedaluwarsa trial (2 hari setelah sekarang) dan menambah login count
def mark_user_trial_today(user_id):
    today = DT.date.today().isoformat()
    trial_expiry_date = (DT.date.today() + DT.timedelta(days=2)).isoformat()  # Trial 2 hari
    cursor.execute('UPDATE users SET trial_expiry_date = ?, login_count = 0 WHERE user_id = ?', (trial_expiry_date, user_id))
    conn.commit()

# Fungsi untuk mencatat login dan mengecek apakah masih dalam batas login
def increment_login_count(user_id):
    cursor.execute('SELECT login_count, trial_expiry_date FROM users WHERE user_id = ?', (user_id,))
    result = cursor.fetchone()
    
    if result is None:
        return False
    
    login_count, trial_expiry_date = result
    today = DT.date.today().isoformat()

    if trial_expiry_date < today:  # Jika trial sudah kedaluwarsa
        return False
    
    if login_count < 2000:
        # Increment login count jika belum mencapai batas
        cursor.execute('UPDATE users SET login_count = ? WHERE user_id = ?', (login_count + 1, user_id))
        conn.commit()
        return True
    
    return False

# Fungsi untuk mendapatkan level pengguna dari database
def get_level_from_db(user_id):
    # Kembalikan level 'user' atau 'admin' tergantung dari user_id
    return 'user'  # Misalnya

@bot.on(events.CallbackQuery(data=b'trial-ssh-member'))
async def trial_ssh(event):
    user_id = str(event.sender_id)
    
    async def trial_ssh_(event):
        if not can_user_trial_again(user_id):
            await event.respond("Anda sudah mencapai batas login atau masa trial telah habis.")
            return

        user = "SSH-RZ-" + str(random.randint(1000, 1000))
        pw = "1"
        exp = "2"
        
        # Perintah untuk menambahkan user baru
        cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
        
        try:
            subprocess.check_output(cmd, shell=True)
        except:
            await event.respond("**User Already Exist**")
        else:
            today = DT.date.today()
            # Tandai pengguna sudah trial hari ini
            mark_user_trial_today(user_id)
            
            msg = f"""
**•─────────────⚝─────────────•**
                       **BANSOS SSH WS**
**•─────────────⚝─────────────•**
**❞Host:**  `{DOMAIN}`
**❞User:**  `{user.strip()}`
**❞Password:**  `{pw.strip()}`
**━━━━━━━━━━━━━━━━━━━━━━━━**
**❞UDP COSTUM:**
`{DOMAIN}:1-65535@{user.strip()}:{pw.strip()}`
**━━━━━━━━━━━━━━━━━━━━━━━━**
**SSH COSTUM:**
`{DOMAIN}:2025@{user.strip()}:{pw.strip()}`
**━━━━━━━━━━━━━━━━━━━━━━━━**
**❞Payload Websocket⟩**
```GET /cdn-cgi/trace HTTP/1.1[crlf]Host: Bug_Kalian[crlf][crlf]GET-RAY / HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]```
**━━━━━━━━━━━━━━━━━━━━━━━━**
**❞Notes pelanggan**
**❞Simpan detail pembelian akun**
**❞Sebagai garansi. Kirimkan detail** 
**❞pembelian akun ke admin untuk** 
**❞pengecekan ketika terjadi masalah**
**❞pada config**
**❞Exp jatuh pada:** `{today}`
**━━━━━━━━━━━━━━━━━━━━━━━━**
**Owner🤖:** @R23_VPNSTORE
"""
            inline = [
                [Button.url("Telegram", "t.me/R23_VPNSTORE"),
                 Button.url("WhatsApp", "wa.me/6285888801241")]
            ]
            await event.respond(msg, buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await trial_ssh_(event)
        else:
            await event.answer(f'Akses Ditolak...!!', alert=True)
    except Exception as e:
        print(f'Error: {e}')