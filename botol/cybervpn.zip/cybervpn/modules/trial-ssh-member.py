from cybervpn import *
from telethon import events, Button
import subprocess
import datetime as DT
import random
import sqlite3
import random
import time
import re
import json
import base64



from telethon import events, Button
import subprocess
import random
import sqlite3
import datetime as DT
from datetime import datetime, timedelta

# Set up SQLite database untuk melacak jumlah trial
def init_db():
    conn = sqlite3.connect('trial_accounts.db')
    c = conn.cursor()
    # Membuat tabel jika belum ada
    c.execute('''CREATE TABLE IF NOT EXISTS trial_counts (
                 user_id TEXT,
                 date TEXT,
                 count INTEGER)''')
    conn.commit()
    conn.close()

def get_trial_count(user_id, date):
    conn = sqlite3.connect('trial_accounts.db')
    c = conn.cursor()
    c.execute('SELECT count FROM trial_counts WHERE user_id=? AND date=?', (user_id, date))
    result = c.fetchone()
    conn.close()
    return result[0] if result else 0

def update_trial_count(user_id, date, new_count):
    conn = sqlite3.connect('trial_accounts.db')
    c = conn.cursor()
    c.execute('REPLACE INTO trial_counts (user_id, date, count) VALUES (?, ?, ?)', (user_id, date, new_count))
    conn.commit()
    conn.close()

@bot.on(events.CallbackQuery(data=b'trial-ssh-member'))
async def trial_ssh(event):
    user_id = str(event.sender_id)
    today_date = datetime.now().strftime("%Y-%m-%d")  # Mendapatkan tanggal hari ini dalam format YYYY-MM-DD
    
    # Cek jumlah trial yang sudah dibuat oleh pengguna hari ini
    trial_count = get_trial_count(user_id, today_date)

    if trial_count >= 3:
        await event.respond("**Anda sudah membuat 3 akun percobaan hari ini. Coba lagi besok.**")
        return

    # Fungsi untuk membuat akun SSH percobaan
    async def trial_ssh_():
        user = "Trial-" + str(random.randint(100, 1000))
        pw = "1"
        
        # Set waktu kadaluarsa 1 hari dari sekarang
        exp_time = datetime.now() + timedelta(days=1)
        exp_time_str = exp_time.strftime("%d-%m-%Y")  # Format waktu kadaluarsa: DD-MM-YYYY

        # Perintah untuk menambahkan user dengan waktu kadaluarsa
        cmd = f'useradd -e "{exp_time_str}" -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
        
        try:
            subprocess.check_output(cmd, shell=True)
        except:
            await event.respond("**User Sudah Ada**")
        else:
            msg = f"""
**═════════════════════════**
**⚡AKUN SSH PREMIUM PERCUBAAN⚡**
**═════════════════════════**
**Host:** `{DOMAIN}`
**User:** `{user.strip()}`
**Password:** `{pw.strip()}`
**═════════════════════════**
**UDP CUSTOM:**
`{DOMAIN}:1-65535@{user.strip()}:{pw.strip()}`
**═════════════════════════**
**SSH CUSTOM:**
`{DOMAIN}:80@{user.strip()}:{pw.strip()}`
**═════════════════════════**
**Payload Websocket⟩**
```GET /cdn-cgi/trace HTTP/1.1[crlf]Host: Bug_Kalian[crlf][crlf]GET-RAY / HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]```
**═════════════════════════**
**🗓️Masa Aktif:**  `{exp_time_str}`  
**═════════════════════════**
            """
            inline = [
                [Button.url("Telegram", "t.me/RiswanJabar"),
                 Button.url("WhatsApp", "wa.me/6285888801241")]
            ]
            
            await event.respond(msg, buttons=inline)
    
    # Cek level pengguna dan lanjutkan
    level = get_level_from_db(user_id)
    
    if level == 'user' or level == 'admin':
        await trial_ssh_()
        
        # Update jumlah trial untuk pengguna setelah akun percobaan berhasil dibuat
        new_trial_count = trial_count + 1
        update_trial_count(user_id, today_date, new_trial_count)
    else:
        await event.answer(f"Akses Ditolak", alert=True)

# Inisialisasi database saat bot pertama kali dijalankan
init_db()