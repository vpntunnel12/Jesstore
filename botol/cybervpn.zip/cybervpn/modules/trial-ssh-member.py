from cybervpn import *
from telethon import events, Button
import subprocess
import datetime as DT
import random
import sqlite3
import time
from datetime import datetime, timedelta
from telethon.tl.custom import Button

import sqlite3
from datetime import datetime, timedelta
from telethon import events, Button
import subprocess
import random

# Fungsi untuk mendapatkan jumlah percobaan dan tanggal percobaan terakhir dari database
def get_trial_data(user_id):
    conn = sqlite3.connect('trial_data.db')  # Koneksi ke database (buat file trial_data.db jika belum ada)
    c = conn.cursor()
    c.execute("CREATE TABLE IF NOT EXISTS trial_data (user_id TEXT, trial_count INTEGER, last_trial_date TEXT)")
    
    # Mencari data percobaan pengguna
    c.execute("SELECT trial_count, last_trial_date FROM trial_data WHERE user_id=?", (user_id,))
    data = c.fetchone()
    
    if data:
        trial_count, last_trial_date = data
    else:
        # Jika belum ada data percobaan, mulai dari 0 dan set tanggal terakhir percobaan ke hari ini
        trial_count = 0
        last_trial_date = datetime.now().strftime('%Y-%m-%d')
    
    conn.close()
    return trial_count, last_trial_date

# Fungsi untuk menyimpan atau memperbarui jumlah percobaan dan tanggal percobaan terakhir
def update_trial_data(user_id, trial_count, last_trial_date):
    conn = sqlite3.connect('trial_data.db')
    c = conn.cursor()
    c.execute("""
        INSERT OR REPLACE INTO trial_data (user_id, trial_count, last_trial_date)
        VALUES (?, ?, ?)
    """, (user_id, trial_count, last_trial_date))
    conn.commit()
    conn.close()

# Fungsi untuk memeriksa apakah pengguna dapat mencoba trial
def can_try_trial(user_id):
    trial_count, last_trial_date = get_trial_data(user_id)
    today = datetime.now().strftime('%Y-%m-%d')
    
    if last_trial_date != today:
        # Reset jumlah percobaan jika tanggal percobaan terakhir bukan hari ini
        trial_count = 0
        last_trial_date = today
    
    if trial_count >= 1:
        return False, trial_count  # Tidak bisa mencoba karena sudah mencapai batas
    else:
        return True, trial_count  # Bisa mencoba, lanjutkan percobaan

@bot.on(events.CallbackQuery(data=b'trial-ssh-member'))
async def trial_ssh(event):
    user_id = str(event.sender_id)
    
    # Cek apakah pengguna dapat mencoba trial
    can_try, trial_count = can_try_trial(user_id)
    
    if can_try:
        # Tambah jumlah percobaan dan simpan data
        trial_count += 1
        update_trial_data(user_id, trial_count, datetime.now().strftime('%Y-%m-%d'))
        
        # Melakukan proses trial SSH
        user = "Trial-" + str(random.randint(100, 1000))
        pw = "1"
        
        # Set waktu kedaluwarsa 60 menit dari sekarang
        current_time = datetime.now()
        exp_time = current_time + timedelta(minutes=60)
        
        # Simpan waktu pembuatan akun
        update_user_creation_time(user, current_time)

        # Perintah untuk menambahkan akun dengan waktu kedaluwarsa
        cmd = f'useradd -e "{exp_time.strftime("%H:%M")}" -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
        
        try:
            subprocess.check_output(cmd, shell=True)
        except:
            await event.respond("**User Sudah Ada**")
        else:
            msg = f"""
**═════════════════════════**
**⚡TRIAL AKUN SSH PREMIUM⚡**
**═════════════════════════**
**Host:**  `{DOMAIN}`
**User:**  `{user.strip()}`
**Password:**  `{pw.strip()}`
**═════════════════════════**
**UDP COSTUM:**
`{DOMAIN}:1-65535@{user.strip()}:{pw.strip()}`
**═════════════════════════**
**SSH COSTUM:**
`{DOMAIN}:80@{user.strip()}:{pw.strip()}`
**═════════════════════════**
**Payload Websocket⟩**
```GET /cdn-cgi/trace HTTP/1.1[crlf]Host: Bug_Kalian[crlf][crlf]GET-RAY / HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]```
**═════════════════════════**
**🗓️Masa Aktif 60 Menit:**  `{exp_time.strftime("%H:%M")}`  
**═════════════════════════**
**☞ó ‌つò☞ 𝓡𝓲𝓼𝓮𝓽 𝓳𝓪𝓫𝓮𝓻 𝓢𝓽𝓸𝓻𝓮**
**═════════════════════════**
"""
            inline = [
                [Button.url("Telegram", "t.me/RiswanJabar"),
                 Button.url("WhatsApp", "wa.me/6285888801241")]
            ]
            
            await event.respond(msg, buttons=inline)
    
    else:
        await event.answer(f"Akses trial hanya tersedia 3 kali sehari. Anda sudah mencapai batas percobaan hari ini.", alert=True)