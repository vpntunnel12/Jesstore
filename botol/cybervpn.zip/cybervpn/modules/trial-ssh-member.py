from cybervpn import *
from telethon import events, Button
import subprocess
import datetime as DT
import random
import sqlite3
import time
import re
import json
import base64

# Database setup
def create_db_connection():
    return sqlite3.connect('users.db')

# Creating the table if it doesn't exist
def create_user_table():
    with create_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                user_id TEXT PRIMARY KEY,
                has_trial INTEGER DEFAULT 0,
                last_trial_date TEXT
            )
        ''')
        conn.commit()

# Get user level from DB
def get_level_from_db(user_id):
    with create_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute('SELECT has_trial FROM users WHERE user_id = ?', (user_id,))
        result = cursor.fetchone()
        if result:
            return 'admin' if result[0] == 1 else 'user'
        else:
            return 'user'  # Default to 'user' if no record found

# Command to create trial SSH user
def create_trial_user():
    user = "Trial-" + str(random.randint(100, 1000))
    pw = "1"
    exp = 1  # trial period in days

    # Ensure no shell injection risk by sanitizing user input
    cmd = f'useradd -e $(date -d "{exp} days" +"%Y-%m-%d") -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'

    try:
        subprocess.check_output(cmd, shell=True)
        return user, pw, exp
    except subprocess.CalledProcessError as e:
        return None, None, None  # Handle failure (e.g., user already exists)

@bot.on(events.CallbackQuery(data=b'trial-ssh-member'))
async def trial_ssh(event):
    user_id = str(event.sender_id)
    
    # Check the level of the user (whether they are admin or not)
    level = get_level_from_db(user_id)
    
    if level in ['user', 'admin']:
        user, pw, exp = create_trial_user()
        
        if user:
            today = DT.date.today()

            # Generate the message with the trial information
            msg = f"""
**═════════════════════════**
              **❞TRIAL SSH WS❞ **
**═════════════════════════**
**❞Host:**  `{DOMAIN}`
**❞User:**  `{user.strip()}`
**❞Password:**  `{pw.strip()}`
**═════════════════════════**
**❞UDP COSTUM:**
`{DOMAIN}:1-65535@{user.strip()}:{pw.strip()}`
**═════════════════════════**
**SSH COSTUM:**
`{DOMAIN}:80@{user.strip()}:{pw.strip()}`
**═════════════════════════**
**❞Payload Websocket⟩**
```GET /cdn-cgi/trace HTTP/1.1[crlf]Host: Bug_Kalian[crlf][crlf]GET-RAY / HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]```
**═════════════════════════**
**❞Exp jatuh pada:** `{today}`
═════════════════════════
☞ó ‌つò☞ 𝓡𝓲𝓼𝔀𝓪𝓷𝓙𝓪𝓫𝓪𝓻 𝓢𝓽𝓸𝓻𝓮
═════════════════════════
"""
            await event.respond(msg, buttons=inline)
        else:
            await event.respond("**User Already Exist**")
    else:
        await event.answer(f"Akses Ditolak", alert=True)

# Initialize the database on startup
create_user_table()