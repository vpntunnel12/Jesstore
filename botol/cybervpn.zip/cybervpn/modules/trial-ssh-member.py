from cybervpn import *
from telethon import events, Button
import subprocess
import datetime as DT
import random
import sqlite3
import random
import time
import re
import json
import base64

from datetime import datetime, timedelta
import random
import subprocess
from telethon import events
from telethon.tl.custom import Button

from telethon import Button
from datetime import datetime, timedelta
import random
import subprocess

# Tentukan ID Pengguna Admin atau ID Grup/Channel
GROUP_ID = -1002196928254  # Ganti dengan ID grup untuk mengirim pemberitahuan (bisa berupa ID grup atau channel)

@bot.on(events.CallbackQuery(data=b'trial-ssh-member'))
async def trial_ssh(event):
    user_id = str(event.sender_id)
    
    async def trial_ssh_(event):
        user = "Trial-" + str(random.randint(100, 1000))
        pw = "1"
        
        # Set waktu kedaluwarsa 1 hari dari sekarang
        exp_time = datetime.now() + timedelta(days=1)  # 1 hari dari waktu sekarang
        
        # Format waktu kedaluwarsa hanya tanggal (DD-MM-YYYY)
        exp_time_str = exp_time.strftime("%d-%m-%Y")  # Format: DD-MM-YYYY

        # Perintah untuk menambahkan user dengan waktu kedaluwarsa
        cmd = f'useradd -e "{exp_time_str}" -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
        
        try:
            subprocess.check_output(cmd, shell=True)
        except:
            await event.respond("**User Sudah Ada**")
        else:
            msg = f"""
**═════════════════════════**
**⚡TRIAL AKUN SSH PREMIUM⚡**
**═════════════════════════**
**Host:**  `{DOMAIN}`
**User:**  `{user.strip()}`
**Password:**  `{pw.strip()}`
**═════════════════════════**
**UDP COSTUM:**
`{DOMAIN}:1-65535@{user.strip()}:{pw.strip()}`
**═════════════════════════**
**SSH COSTUM:**
`{DOMAIN}:80@{user.strip()}:{pw.strip()}`
**═════════════════════════**
**Payload Websocket⟩**
```GET /cdn-cgi/trace HTTP/1.1[crlf]Host: Bug_Kalian[crlf][crlf]GET-RAY / HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]```
**═════════════════════════**
**🗓️Masa Aktif 1 Hari:**  `{exp_time_str}`  
**═════════════════════════**
**☞ó ‌つò☞ 𝓡𝓲𝓼𝓮𝓽 𝓳𝓪𝓫𝓮𝓻 𝓢𝓽𝓸𝓻𝓮**
**═════════════════════════**
"""
            inline = [
                [Button.url("Telegram", "t.me/RiswanJabar"),
                 Button.url("WhatsApp", "wa.me/6285888801241")]
            ]
            
            # Kirim pesan ke pengguna
            await event.respond(msg, buttons=inline)
            

            # Kirim pemberitahuan ke grup tentang akun trial baru
            group_msg = f"**Akun Trial SSH Baru Dibuat**\n\nUser: `{user.strip()}`\nPassword: `{pw.strip()}`\nTanggal Kedaluwarsa: {exp_time_str}"
            await event.client.send_message(GROUP_ID, group_msg)
    
    # Cek level pengguna dari database
    level = get_level_from_db(user_id)
    
    if level == 'user':
        # Untuk pengguna biasa, langsung izinkan trial
        await trial_ssh_(event)
    
    elif level == 'admin':
        # Untuk admin, izinkan membuat trial kapan saja tanpa batasan
        await trial_ssh_(event)
    
    else:
        await event.answer(f"Akses Ditolak", alert=True)