from cybervpn import *
import requests
import subprocess
import re
import datetime as DT

@bot.on(events.CallbackQuery(data=b'create-trojan'))
async def create_trojan(event):
    async def create_trojan_(event):
        user_id = str(event.sender_id)  # Ensure sender_id is defined early.
        chat = event.chat_id
        sender = await event.get_sender()  # Move sender definition here

        # Conversation with user for username
        async with bot.conversation(chat) as user_conv:
            await event.respond('**Username :**')
            user = (await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        # Conversation with user for expiration
        async with bot.conversation(chat) as exp_conv:
            await event.respond('**Expired:**')
            exp = (await exp_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        # Conversation with user for Login IP
        async with bot.conversation(chat) as login_ip_conv:
            await event.respond('**Login IP:**')
            login_ip = (await login_ip_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        await event.edit("`Wait.. Setting up an Account`")
        cmd = f'printf "%s\n" "{user}" "{exp}" "{Quota}" "{ip}" | addtr-bot'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except subprocess.CalledProcessError as e:
            await event.respond(f"Terjadi kesalahan: {e}\nSubproses output: {e.output.decode('utf-8')}")
            return  # Stop execution if there's an error

        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))
        b = [x.group() for x in re.finditer("trojan://(.*)", a)]
        domain = re.search("@(.*?):", b[0]).group(1)
        uuid = re.search("trojan://(.*?)@", b[0]).group(1)
        
        msg = f"""
**═════════════════════════**
               **XRAY/TROJAN ACCOUNT**
**═════════════════════════**
**Remarks:** `{user}`
**Host:** `{domain}`
**Limit IP:** `{login_ip}` **IP**
**Expired on:** `{later}`
**═════════════════════════**
**Port TLS:** `443`
**Port NTLS:** `80` `8080`
**Port DNS:** `443` `53`
**Port gRPC:** `443`
**Security:** `auto`
**Network:** `(WS) or (gRPC)`
**Path:** `/trojan`
**Servicename:** `trojan-grpc`
**UUID:** `{uuid}`
**═════════════════════════**
**TROJAN TLS:**
```{b[0]}```
**═════════════════════════**
**TROJAN NON-TLS:**
```{b[1].replace(" ","")}```
**═════════════════════════**
**TROJAN GRPC:**
```{b[2].replace(" ","")}```
**═════════════════════════**
☞️ 𝓡𝓲𝓼𝔀𝓪𝓷𝓙𝓪𝓫𝓪𝓻 𝓢𝓽𝓸𝓻𝓮
**═════════════════════════**
"""
        await event.respond(msg)

    try:
        level = get_level_from_db(user_id)
        if level == 'admin':
            await create_trojan_(event)
        else:
            await event.answer(f'Akses Ditolak..!!', alert=True)
    except Exception as e:
        print(f'Error: {e}')

# You should apply similar fixes for the other functions such as cek_trojan, trial_trojan, ren_trojan, etc.