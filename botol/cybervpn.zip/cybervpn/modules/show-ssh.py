from cybervpn import *
import subprocess




import subprocess
from datetime import datetime

@bot.on(events.CallbackQuery(data=b'show-ssh'))
async def show_ssh(event):
    user_id = str(event.sender_id)

    async def show_ssh_(event):
        cmd = "awk -F: '($3>=1000)&&($1!='user  |  exp'){print $1}' /etc/passwd"
        x = subprocess.check_output(cmd, shell=True).decode("ascii").split("\n")

        ssh_users = []
        
        for user in x:
            if user:  # Only process non-empty lines
                # Get the expiration date for the user
                exp_cmd = f"chage -l {user} | grep 'Account expires' | cut -d: -f2"
                try:
                    exp_date = subprocess.check_output(exp_cmd, shell=True).decode("ascii").strip()
                    
                    if exp_date == "never":
                        expiration = "Never"
                    else:
                        # Convert the expiration date into a readable format
                        try:
                            expiration = datetime.strptime(exp_date, '%b %d, %Y').strftime('%Y-%m-%d')
                        except ValueError:
                            expiration = "Invalid date"
                except subprocess.CalledProcessError:
                    expiration = "Error retrieving expiration date"
                
                # Format the username and expiration date
                ssh_users.append(f"`{user}` - Exp: {expiration}")

        zx = "\n".join(ssh_users)
        await event.respond(f"""
**Showing All SSH Users**

{zx}
`
**Total SSH Account:** `{str(len(ssh_users))}`
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])

    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await show_ssh_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)

    except Exception as e:
        print(f'Error: {e}')