from cybervpn import *
import subprocess
from telethon import Button

@bot.on(events.CallbackQuery(data=b'show-ssh'))
async def show_ssh(event):
    user_id = str(event.sender_id)

    async def show_ssh_(event):
        try:
            # Run the shell command to list users with UID >= 1000 and not 'nobody'
            cmd = "awk -F: '($3>=1000)&&($1!='nobody'){print $1}' /etc/passwd"
            x = subprocess.check_output(cmd, shell=True).decode("ascii").split("\n")
            users = [us for us in x if us]  # Remove empty lines

            user_info = []
            for user in users:
                # Get the expiration date for each user using `chage`
                chage_cmd = f"chage -l {user} 2>/dev/null"
                chage_output = subprocess.check_output(chage_cmd, shell=True).decode("ascii")
                expiration_line = next((line for line in chage_output.splitlines() if "Account expires" in line), None)
                expiration_date = expiration_line.split(":")[1].strip() if expiration_line else "No expiration"

                user_info.append(f"`{user}` - Expiration: {expiration_date}")

            # Format the output with all SSH users and their expiration dates
            zx = "\n".join(user_info)
            
            await event.respond(f"""
**Showing All SSH Users**

{zx}
`
**Total SSH Accounts:** `{str(len(user_info))}`
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])

        except subprocess.CalledProcessError as e:
            await event.respond("Error retrieving SSH user data. Please try again later.", alert=True)
            print(f"Command failed: {e}")
        except Exception as e:
            await event.respond("An unexpected error occurred.", alert=True)
            print(f"Unexpected error: {e}")

    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await show_ssh_(event)
        else:
            await event.answer(f'Access Denied. Your level: {level}', alert=True)

    except Exception as e:
        print(f'Error: {e}')
        await event.answer("Error fetching user level. Please try again.", alert=True)