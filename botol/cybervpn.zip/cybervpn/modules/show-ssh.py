from cybervpn import *
import subprocess
from telethon import Button
from datetime import datetime

@bot.on(events.CallbackQuery(data=b'show-ssh'))
async def show_ssh(event):
    user_id = str(event.sender_id)

    async def show_ssh_(event):
        try:
            # Run the shell command to list users with UID >= 1000 and not 'nobody'
            cmd = "awk -F: '($3>=1000)&&($1!=\"nobody\"){print $1}' /etc/passwd"
            x = subprocess.check_output(cmd, shell=True).decode("ascii").split("\n")
            users = [us for us in x if us]  # Remove empty lines

            user_info = []
            for user in users:
                # Get the expiration date for each user using `chage`
                chage_cmd = f"chage -l {user} 2>/dev/null"
                try:
                    chage_output = subprocess.check_output(chage_cmd, shell=True).decode("ascii")
                    expiration_line = next((line for line in chage_output.splitlines() if "Account expires" in line), None)
                    expiration_date = expiration_line.split(":")[1].strip() if expiration_line else "No expiration"
                except subprocess.CalledProcessError:
                    expiration_date = "Unable to fetch expiration"

                user_info.append(f"`{user}` - Expiration: {expiration_date}")

            # Format the output with all SSH users and their expiration dates
            zx = "\n".join(user_info)
            
            # Add inline buttons for each user to allow expiration date updates
            buttons = [
                [Button.inline(f"Update Expiration for {user}", f"update-expiration|{user}")]
                for user in users
            ]
            
            buttons.append([Button.inline("‹ Main Menu ›", "menu")])

            await event.respond(f"""
**Showing All SSH Users**

{zx}

**Total SSH Accounts:** `{str(len(user_info))}`
""", buttons=buttons)

        except subprocess.CalledProcessError as e:
            await event.respond("Error retrieving SSH user data. Please try again later.", alert=True)
            print(f"Command failed: {e}")
        except Exception as e:
            await event.respond("An unexpected error occurred.", alert=True)
            print(f"Unexpected error: {e}")

    # Handle updating the expiration date
    @bot.on(events.CallbackQuery(data=lambda data: data.startswith(b'update-expiration')))
    async def update_expiration(event):
        user_id = str(event.sender_id)
        try:
            level = get_level_from_db(user_id)
            if level == 'admin':
                # Extract user from the event data (user)
                user_to_update = event.data.split(b'|')[1].decode('utf-8')

                # Ask admin for the new expiration date (expects format YYYY-MM-DD)
                await event.respond(f"Please enter the new expiration date for `{user_to_update}` (format: YYYY-MM-DD):")
                
                # Wait for user input
                response = await bot.wait_for(events.NewMessage(from_users=user_id))
                new_expiration_date = response.text.strip()

                # Validate and update the expiration date
                try:
                    expiration_date_obj = datetime.strptime(new_expiration_date, "%Y-%m-%d")
                    expiration_str = expiration_date_obj.strftime("%Y-%m-%d")
                    
                    # Update the expiration date using `chage -E`
                    chage_cmd = f"chage -E {expiration_str} {user_to_update}"
                    subprocess.check_output(chage_cmd, shell=True)
                    await event.respond(f"Expiration date for `{user_to_update}` updated to {expiration_str}", alert=True)
                except ValueError:
                    await event.respond(f"Invalid date format. Please use YYYY-MM-DD.", alert=True)
            else:
                await event.answer(f'Access Denied. Your level: {level}', alert=True)

        except Exception as e:
            print(f"Error updating expiration date: {e}")
            await event.answer("An error occurred while updating the expiration date.", alert=True)

    # Main menu and admin verification
    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await show_ssh_(event)
        else:
            await event.answer(f'Access Denied. Your level: {level}', alert=True)

    except Exception as e:
        print(f'Error: {e}')
        await event.answer("Error fetching user level. Please try again.", alert=True)