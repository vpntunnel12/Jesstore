from kyt import *

@bot.on(events.NewMessage(pattern=r"(?:.ssh|/ssh)$"))
@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
	async def ssh_(event):
		inline = [
            [Button.inline("Trial Ssh", "trial-ssh"),
             Button.inline("Create Ssh", "create-ssh"),
             Button.inline("Hapus User", "delete-ssh")],
            [Button.inline("Cek Login", "login-ssh")],
            [Button.inline("Cek User", "show-ssh")],
[Button.inline("Renew User", "renew-ssh")],
            [Button.inline("Back Menu", "menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
**◇━━━━━━━━━━━━━━━━━━◇**
            **🔸SSH & OVPN🔸**
**◇━━━━━━━━━━━━━━━━━━◇**
**» Service:** `SSH OVPN`
**» Hostname/IP:** `{DOMAIN}`
**» ISP:** `{z["isp"]}`
**» Country:** `{z["country"]}`
🤖 @R23_VPNSTORE
**◇━━━━━━━━━━━━━━━━━━◇**
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await ssh_(event)
	else:
		await event.answer("Access Denied",alert=True)
