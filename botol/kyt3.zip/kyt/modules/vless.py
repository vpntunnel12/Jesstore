from kyt import *
import requests
import subprocess



import subprocess
import re
import datetime as DT
import json
from telethon import events

# Menyimpan data pembuatan akun (misalnya menggunakan file JSON)
def get_user_data():
    try:
        with open('user_data.json', 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

def save_user_data(data):
    with open('user_data.json', 'w') as f:
        json.dump(data, f)

@bot.on(events.CallbackQuery(data=b'trial-memek'))
async def trial_vless(event):
    async def trial_vless_(event):
        # Cek apakah pengguna sudah membuat akun hari ini
        user_data = get_user_data()
        sender = await event.get_sender()
        user_id = str(sender.id)
        today = DT.date.today().isoformat()

        # Jika pengguna sudah membuat akun hari ini, beri peringatan
        if user_id in user_data and user_data[user_id] == today:
            await event.respond("**Anda sudah membuat akun Vless hari ini. Cobalah lagi besok.**")
            return

        # Perintah untuk membuat akun Vless
        cmd = f'printf "%s\n" "RiswanJabar`</dev/urandom tr -dc X-Z0-9 | head -c4`" "3" "2000" "2000" | addvless-bot'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except subprocess.CalledProcessError:
            await event.respond("**Error: Could not generate Vless account**")
            return
        except Exception as e:
            await event.respond(f"**Error: {str(e)}**")
            return

        later = DT.date.today() + DT.timedelta(days=3)
        x = [x.group() for x in re.finditer("vless://(.*)", a)]

        if not x:
            await event.respond("**Error: Invalid Vless URL format**")
            return

        # Mengambil informasi dari URL
        uuid = re.search("vless://(.*?)@", x[0]).group(1)
        
        # Membuat pesan
        msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
      **⟨ Vless Account ⟩**
**◇━━━━━━━━━━━━━━━━━◇**
**» Host Server :** `{x[0]}`
**» Quaota** `2000 GB`
**» Login IP** `2000 HP`
**» Port TLS    :** `443, 400-900`
**» Port NTLS   :** `80, 8080, 8081-9999 `
**» UUID        :** `{uuid}`
**» NetWork     :** `(WS) or (gRPC)`
**» Path        :** `/vless`
**» ServiceName :** `vless-grpc`
**◇━━━━━━━━━━━━━━━━━◇**
**» URL TLS    :**
```{x[0]}```
**◇━━━━━━━━━━━━━━━━━◇**
**» URL HTTP    :**
```{x[1].replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» URL gRPC   :** 
```{x[2].replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» Expired:** `{later}`
**◇━━━━━━━━━━━━━━━━━◇**
**» ** 🤖@RiswanJabar
"""
        await event.respond(msg)

        # Update data: menyimpan tanggal pembuatan akun untuk pengguna ini
        user_data[user_id] = today
        save_user_data(user_data)

    # Memeriksa apakah pengguna valid
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await trial_vless_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'vless'))
async def vless(event):
    async def vless_(event):
        inline = [
            
             [Button.inline("⚡BANSOS 3 HARI⚡", "trial-memek")],
            
            [Button.inline("⚡CEK USER LOGIN⚡", "cek-vless")],
            [Button.inline("⚡LIST USER⚡", "cek-membervl")],
            [Button.inline("↪️MAIN MENU↩️", "menu")]
        ]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
     **◇⟨🔸VLESS SERVICE🔸⟩◇**
**◇━━━━━━━━━━━━━━━━━◇**
**  Service:** `VLESS`
**  Hostname/IP:** `{DOMAIN}`
**  ISP:** `{z["isp"]}`
**  Country:** `{z["country"]}`
**» ** 🤖@RiswanJabar
**◇━━━━━━━━━━━━━━━━━◇**
"""
        await event.edit(msg, buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await vless_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

