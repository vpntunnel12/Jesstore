from telethon import events
import subprocess
import datetime as DT
import re

# Dictionary untuk menyimpan data tanggal terakhir pengguna mendapatkan trial
user_last_trial = {}

@bot.on(events.CallbackQuery(data=b'trial-memek'))
async def trial_vless(event):
    async def trial_vless_():
        cmd = f'printf "%s\n" "RZVLESS`</dev/urandom tr -dc X-Z0-9 | head -c4`" "3" "2000" "2000" | addvless-bot'
        
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            # Jika ada error saat menjalankan perintah subprocess
            await event.respond(f"An error occurred: {str(e)}")
            return

        today = DT.date.today()
        later = today + DT.timedelta(days=3)  # Set expired date to 3 days later

        # Ekstraksi URL vless dan detail lainnya
        x = [x.group() for x in re.finditer("vless://(.*)", a)]
        if len(x) < 3:
            await event.respond("Failed to generate the required Vless URLs.")
            return

        try:
            # Mengambil UUID dan data lainnya dari URL vless
            remarks = re.search("#(.*)", x[0]).group(1)
            uuid = re.search("vless://(.*?)@", x[0]).group(1)

            # Menyiapkan pesan untuk dikirimkan ke pengguna
            msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
      **⟨ Vless Account⟩**
**◇━━━━━━━━━━━━━━━━━◇**
**» Host Server :** `{DOMAIN}`
**» Port TLS    :** `443, 400-900`
**» Port NTLS   :** `80, 8080, 8081-9999 `
**» UUID        :** `{uuid}`
**» NetWork     :** `(WS) or (gRPC)`
**» Path        :** `/vless`
**» ServiceName :** `vless-grpc`
**◇━━━━━━━━━━━━━━━━━◇**
**» URL TLS     :**
```{x[0].strip()}```
**◇━━━━━━━━━━━━━━━━━◇**
**» URL HTTP    :**
```{x[1].replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» URL gRPC    :** 
```{x[2].replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» Expired     :** `{later}`
**◇━━━━━━━━━━━━━━━━━◇**
**» ** 🤖@R23_VPNSTORE
"""
            await event.respond(msg)
        
        except Exception as e:
            await event.respond(f"Error parsing Vless URL: {str(e)}")
            return

    # Verifikasi ID pengguna
    chat = event.chat_id
    sender = await event.get_sender()
    user_id = str(sender.id)  # Gunakan ID pengguna untuk memverifikasi apakah mereka valid

    today = DT.date.today()

    # Cek apakah pengguna sudah mendapatkan trial hari ini
    if user_id in user_last_trial:
        last_trial_date = user_last_trial[user_id]
        if last_trial_date == today:
            await event.answer("Anda sudah menerima akun trial hari ini. Coba lagi besok!", alert=True)
            return  # Tidak memberikan akun jika sudah menerima hari ini

    # Validasi ID pengguna
    a = valid(user_id)  # Panggil fungsi valid untuk cek status pengguna

    if a == "true":
        await trial_vless_()  # Jika valid, buatkan akun trial dan kirimkan
        user_last_trial[user_id] = today  # Update tanggal terakhir kali pengguna menerima trial
    else:
        await event.answer("Akses Ditolak", alert=True)
@bot.on(events.CallbackQuery(data=b'vless'))
async def vless(event):
    async def vless_(event):
        inline = [
            
             [Button.inline("⚡BANSOS 3 HARI⚡", "trial-memek")],
            
            [Button.inline("⚡CEK USER LOGIN⚡", "cek-vless")],
            [Button.inline("⚡LIST USER⚡", "cek-membervl")],
            [Button.inline("↪️MAIN MENU↩️", "menu")]
        ]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
     **◇⟨🔸VLESS SERVICE🔸⟩◇**
**◇━━━━━━━━━━━━━━━━━◇**
**  Service:** `VLESS`
**  Hostname/IP:** `{DOMAIN}`
**  ISP:** `{z["isp"]}`
**  Country:** `{z["country"]}`
**» ** 🤖@R23_VPNSTORE
**◇━━━━━━━━━━━━━━━━━◇**
"""
        await event.edit(msg, buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await vless_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

