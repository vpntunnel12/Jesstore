from kyt import *
import requests
import subprocess


@bot.on(events.CallbackQuery(data=b'cek-vless'))
async def cek_vless(event):
    async def cek_vless_(event):
        cmd = 'cek-vless'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"""
**◇━━━━━━━━━━━━━━━━━━◇**
   ** ⟨🔸Cek Vless User Login🔸⟩**
**◇━━━━━━━━━━━━━━━━━━◇**
{z}

**Shows Logged In Users Vless**
""", buttons=[[Button.inline("‹ main menu ›", "menu")]])

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await cek_vless_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

		


# CEK member VLESS
@bot.on(events.CallbackQuery(data=b'cek-membervl'))
async def cek_vless(event):
    async def cek_vless_(event):
        cmd = 'bash cek-mvs'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"""

{z}

**Shows Users from databases**
""", buttons=[[Button.inline("‹ main menu ›", "menu")]])

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await cek_vless_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)




@bot.on(events.CallbackQuery(data=b'trial-vless'))
async def trial_vless(event):
    async def trial_vless_(event):
        cmd = f'printf "%s\n" "Rz3vpnstore`</dev/urandom tr -dc X-Z0-9 | head -c4`" "1" "2000" "2000" | addvless-bot'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**User Already Exist**")
        else:
            today = DT.date.today()
            later = today + DT.timedelta(days=int(1))
            x = [x.group() for x in re.finditer("vless://(.*)", a)]
            print(x)
            remarks = re.search("#(.*)", x[0]).group(1)
            # domain = re.search("@(.*?):", x[0]).group(1)
            uuid = re.search("vless://(.*?)@", x[0]).group(1)
            # path = re.search("path=(.*)&", x[0]).group(1)
            msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
   **⟨🔸Trial Vless Account🔸⟩**
**◇━━━━━━━━━━━━━━━━━◇**
**» Host Server :** `{DOMAIN}`
**» Port TLS    :** `443, 400-900`
**» Port NTLS   :** `80, 8080, 8081-9999 `
**» UUID    :** `{uuid}`
**» NetWork     :** `(WS) or (gRPC)`
**» Path        :** `/vless`
**» ServiceName :** `vless-grpc`
**◇━━━━━━━━━━━━━━━━━◇**
**» URL TLS    :**
```{x[0]}```
**◇━━━━━━━━━━━━━━━━━◇**
**» URL HTTP    :**
```{x[1].𝚛𝚎𝚙𝚕𝚊𝚌𝚎(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» URL gRPC   :** 
```{x[2].𝚛𝚎𝚙𝚕𝚊𝚌𝚎(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» Expired Until:** `{later}`
**◇━━━━━━━━━━━━━━━━━◇**
**» ** 🤖@R23_VPNSTORE
"""
            await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await trial_vless_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'trial-memek'))
async def trial_vless(event):
    async def trial_vless_(event):
        cmd = f'printf "%s\n" "RZVLESS`</dev/urandom tr -dc X-Z0-9 | head -c4`" "3" "2000" "2000" | addvless-bot'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**User Already Exist**")
        else:
            today = DT.date.today()
            later = today + DT.timedelta(days=int(3))
            x = [x.group() for x in re.finditer("vless://(.*)", a)]
            print(x)
            remarks = re.search("#(.*)", x[0]).group(1)
            # domain = re.search("@(.*?):", x[0]).group(1)
            uuid = re.search("vless://(.*?)@", x[0]).group(1)
            # path = re.search("path=(.*)&", x[0]).group(1)
            msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
      **⟨ Vless Account⟩**
**◇━━━━━━━━━━━━━━━━━◇**
**» Host Server :** `{DOMAIN}`
**» Port TLS    :** `443, 400-900`
**» Port NTLS   :** `80, 8080, 8081-9999 `
**» UUID    :** `{uuid}`
**» NetWork     :** `(WS) or (gRPC)`
**» Path        :** `/vless`
**» ServiceName :** `vless-grpc`
**◇━━━━━━━━━━━━━━━━━◇**
**» URL TLS    :**
```{x[0]}```
**◇━━━━━━━━━━━━━━━━━◇**
**» URL HTTP    :**
```{x[1].𝚛𝚎𝚙𝚕𝚊𝚌𝚎(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» URL gRPC   :** 
```{x[2].𝚛𝚎𝚙𝚕𝚊𝚌𝚎(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**»Expired:** `{later}`
**◇━━━━━━━━━━━━━━━━━◇**
**» ** 🤖@R23_VPNSTORE
"""
            await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await trial_vless_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)


@bot.on(events.CallbackQuery(data=b'vless'))
async def vless(event):
    async def vless_(event):
        inline = [
            
             [Button.inline("⚡BANSOS 3 HARI⚡", "trial-memek")],
            
            [Button.inline("CEK USER LOGIN", "cek-vless")],
            [Button.inline("LIST USER", "cek-membervl")],
            [Button.inline("↪️MAIN MENU↩️", "menu")]
        ]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
     **◇⟨🔸VLESS SERVICE🔸⟩◇**
**◇━━━━━━━━━━━━━━━━━◇**
**  Service:** `VLESS`
**  Hostname/IP:** `{DOMAIN}`
**  ISP:** `{z["isp"]}`
**  Country:** `{z["country"]}`
**» ** 🤖@R23_VPNSTORE
**◇━━━━━━━━━━━━━━━━━◇**
"""
        await event.edit(msg, buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await vless_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

