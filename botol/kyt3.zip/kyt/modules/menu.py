from kyt import *
import subprocess

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    
    
    inline = [
[Button.inline("⚡AKUN SSH WS⚡", "trial-es")],
[Button.inline("⚡AKUN VMESS⚡","trial-puki")],
[Button.inline("⚡AKUN VLESS⚡","trial-memek")],
[Button.inline("⚡AKUN TROJAN⚡","trial-bujang")],
[Button.url("⚡GRUP CONFIG⚡","https://t.me/grupvpnriswan")],
[Button.url("⚡FREE VLESS LITME⚡","https://t.me/VPN12_FREE")],
[Button.inline("🙏DONASI JIKA ADA🙏","start")]
    ]
    sender = await event.get_sender()
    val = valid(str(sender.id))
    if val == "false":
        try:
            await event.answer("", alert=True)
        except:
            await event.reply("")
    elif val == "true":
        # Get system information
        sh = f'cat /etc/passwd | grep "home" | grep "false" | wc -l'
        ssh = subprocess.check_output(sh, shell=True).decode("ascii")
        vm = f'cat /etc/vmess/.vmess.db | grep "###" | wc -l'
        vms = subprocess.check_output(vm, shell=True).decode("ascii")
        vl = f'cat /etc/vless/.vless.db | grep "###" | wc -l'
        vls = subprocess.check_output(vl, shell=True).decode("ascii")
        tr = f'cat /etc/trojan/.trojan.db | grep "###" | wc -l'
        trj = subprocess.check_output(tr, shell=True).decode("ascii")
        sdss = f"cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
        namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
        shadowsocks = subprocess.check_output('cat /etc/shadowsocks/.shadowsocks.db | grep "###" | wc -l', shell=True).decode("ascii")
        ipvps = f"curl -s ipv4.icanhazip.com"
        ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
        
        # Get VPS Location using ipinfo.io
        location = subprocess.check_output(f"curl -s http://ipinfo.io/{ipsaya.strip()}/json", shell=True).decode("ascii")
        location_info = json.loads(location)
        city = location_info.get('city', 'Unknown')
        region = location_info.get('region', 'Unknown')
        country = location_info.get('country', 'Unknown')

        # Get total RAM
        ram = subprocess.check_output("free -h | grep Mem | awk '{print $2}'", shell=True).decode("ascii").strip()

        # Get VPS current time
        vps_time = subprocess.check_output("date '+%Y-%m-%d %H:%M:%S'", shell=True).decode("ascii").strip()

        # Get VPS uptime
        uptime = subprocess.check_output("uptime -p", shell=True).decode("ascii").strip()

        msg = f"""
**Username bot** @Bansosvpnbot  
**Silahkan gunakan Bot Ini**
**Untuk Kebutuhan kalian**

**Total Account Dibuat**
**SSH :** `{ssh.strip()}` __account__
**VMESS :** `{vms.strip()}` __account__
**VLESS :** `{vls.strip()}` __account__
**TROJAN :** `{trj.strip()}` __account__

**NOTES**
**bot ini aktip tergantung Dana**
**Jika Dana Ada Bisa Perpanjang**
**Ownerku** @R23_VPNSTORE
        """
        x = await event.edit(msg, buttons=inline)
        if not x:
            await event.reply(msg, buttons=inline)