import random
from telethon import events, Button

# Fungsi untuk membuat soal matematika sederhana
def generate_math_problem():
    # Membuat soal matematika acak (penjumlahan atau pengurangan)
    num1 = random.randint(1, 20)
    num2 = random.randint(1, 20)
    operator = random.choice(["+", "-"])

    problem = f"{num1} {operator} {num2}"
    solution = eval(problem)  # Menghitung jawaban dari soal matematika

    return problem, solution

# Menyimpan jawaban pengguna untuk verifikasi
user_answers = {}

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    sender = await event.get_sender()
    user_id = str(sender.id)

    # Cek apakah pengguna sudah menjawab soal matematika
    if user_id not in user_answers or user_answers[user_id] is None:
        # Kirim soal matematika ke pengguna
        problem, solution = generate_math_problem()
        user_answers[user_id] = solution  # Simpan jawaban yang benar

        await event.respond(f"Untuk melanjutkan, jawab soal berikut:\n\n**{problem}**")
        return

    # Jika jawaban benar, tampilkan menu
    if user_answers[user_id] is True:
        save_user(user_id)  # Simpan ID pengguna
        # Kirim notifikasi ke admin
        admin_msg = f"**Pengguna** @{sender.username} **ID:** `{user_id}`"
        try:
            await bot.send_message(ADMIN_USER_ID, admin_msg)
        except Exception as e:
            print(f"Gagal mengirim notifikasi ke admin: {e}")

        total_users = len(load_users())
        inline = [
            [Button.inline("⚡AKUN SSH WS⚡", "trial-es")],
            [Button.inline("⚡AKUN VMESS⚡", "trial-puki")],
            [Button.inline("⚡AKUN VLESS⚡", "trial-memek")],
            [Button.inline("⚡AKUN TROJAN⚡", "trial-bujang")],
            [Button.url("⚡GRUP CONFIG⚡", "https://t.me/grupvpnriswan")],
            [Button.url("💰DAFTAR MEMNER💰", "https://t.me/R23_VPNSTORE")],
            [Button.url("🙏DONASI JIKA ADA🙏", "https://t.me/Donasivpn")],
            [Button.inline("↪️BACK KE MENU AWAL↩️", "start")]
        ]

        msg = f"""
**User bot** @Bansosvpnbot  
**Silahkan gunakan Bot Ini**
**Untuk Kebutuhan kalian**
**Total Account Dibuat**
**SSH :**         `{ssh.strip()}` `account`
**VMESS :** `{vms.strip()}` `account`
**VLESS :**    `{vls.strip()}` `account`
**TROJAN :** `{trj.strip()}` `account`

**Pengguna Bot:** `{total_users}` `Orang`
**NOTES**
**bot ini aktip tergantung Dana**
**Jika Dana Ada Bisa Perpanjang**
**Ownerku** @R23_VPNSTORE
        """
        await event.edit(msg, buttons=inline)

# Fungsi untuk menangani jawaban soal matematika
@bot.on(events.NewMessage())
async def handle_answer(event):
    sender = await event.get_sender()
    user_id = str(sender.id)

    # Pastikan pengguna belum memasukkan jawaban sebelumnya
    if user_id in user_answers and user_answers[user_id] is not None:
        try:
            user_answer = int(event.text)  # Ambil jawaban pengguna

            # Verifikasi jawaban pengguna
            if user_answer == user_answers[user_id]:
                # Jawaban benar, beri akses ke menu
                user_answers[user_id] = True
                await event.respond("Jawaban benar! Sekarang Anda dapat mengakses menu.", buttons=[Button.inline("Buka Menu", "menu")])
            else:
                await event.respond("Jawaban salah. Silakan coba lagi.")
        except ValueError:
            await event.respond("Harap masukkan angka yang valid sebagai jawaban.")