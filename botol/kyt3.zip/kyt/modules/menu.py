import json
import subprocess
from kyt import *

# Definisikan ID pengguna admin (ganti dengan ID pengguna admin yang sesungguhnya)
ADMIN_USER_ID = 5521096873  # Ganti dengan ID pengguna Telegram admin yang sebenarnya

# Definisikan PIN yang benar
PIN_CODE = "0858"  # Ganti dengan PIN yang sesuai

# Fungsi untuk memuat data pengguna (dalam hal ini, ID pengguna) dari file
def load_users():
    try:
        with open('users.json', 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return []
        
# Fungsi untuk menyimpan data pengguna (dalam hal ini, ID pengguna) ke file
def save_user(user_id):
    users = load_users()
    if user_id not in users:
        users.append(user_id)
        with open('users.json', 'w') as f:
            json.dump(users, f)

# Menyimpan PIN yang sudah dimasukkan oleh pengguna
user_pins = {}

# Fungsi untuk memeriksa apakah pengguna sudah memasukkan PIN yang benar
def is_pin_correct(user_id):
    return user_pins.get(user_id) == PIN_CODE

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    sender = await event.get_sender()
    user_id = str(sender.id)
    
    # Cek apakah pengguna sudah memasukkan PIN
    if user_id not in user_pins or not is_pin_correct(user_id):
        await event.respond("Masukkan PIN Anda terlebih dahulu.")
        return
    
           # Simpan ID pengguna untuk melacak total pengguna
    save_user(user_id)
    
    # Kirim notifikasi ke admin bahwa ada pengguna yang berinteraksi dengan bot
    admin_msg = f"**Pengguna** @{sender.username} **ID:** `{user_id}`"
    try:
        # Kirim notifikasi ke admin
        await bot.send_message(ADMIN_USER_ID, admin_msg)
    except Exception as e:
        print(f"Gagal mengirim notifikasi ke admin: {e}") 


    # Muat jumlah total pengguna yang ada
    total_users = len(load_users())
    
    # Definisikan tombol inline
    inline = [
    [Button.inline("⚡AKUN SSH WS⚡", "trial-es")],
    [Button.inline("⚡AKUN VMESS⚡", "trial-puki")],
    [Button.inline("⚡AKUN VLESS⚡", "trial-memek")],
    [Button.inline("⚡AKUN TROJAN⚡", "trial-bujang")],
    [Button.url("⚡GRUP CONFIG⚡", "https://t.me/grupvpnriswan")],
    [Button.url("⚡FREE VLESS LITME⚡", "https://t.me/VPN12_FREE")],
    [Button.url("🙏DONASI JIKA ADA🙏", "https://t.me/Donasivpn")],  # Tombol URL baru
    [Button.inline("↪️BACK KE MENU AWAL↩️", "start")]
]
    
    val = valid(user_id)
    if val == "false":
        try:
            await event.answer("", alert=True)
        except:
            await event.reply("")
    elif val == "true":
        # Ambil informasi sistem
        sh = f'cat /etc/passwd | grep "home" | grep "false" | wc -l'
        ssh = subprocess.check_output(sh, shell=True).decode("ascii")
        vm = f'cat /etc/vmess/.vmess.db | grep "###" | wc -l'
        vms = subprocess.check_output(vm, shell=True).decode("ascii")
        vl = f'cat /etc/vless/.vless.db | grep "###" | wc -l'
        vls = subprocess.check_output(vl, shell=True).decode("ascii")
        tr = f'cat /etc/trojan/.trojan.db | grep "###" | wc -l'
        trj = subprocess.check_output(tr, shell=True).decode("ascii")
        sdss = f"cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
        namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
        shadowsocks = subprocess.check_output('cat /etc/shadowsocks/.shadowsocks.db | grep "###" | wc -l', shell=True).decode("ascii")
        ipvps = f"curl -s ipv4.icanhazip.com"
        ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
        
        # Dapatkan Lokasi VPS menggunakan ipinfo.io
        location = subprocess.check_output(f"curl -s http://ipinfo.io/{ipsaya.strip()}/json", shell=True).decode("ascii")
        location_info = json.loads(location)
        city = location_info.get('city', 'Unknown')
        region = location_info.get('region', 'Unknown')
        country = location_info.get('country', 'Unknown')

        # Dapatkan RAM total
        ram = subprocess.check_output("free -h | grep Mem | awk '{print $2}'", shell=True).decode("ascii").strip()

        # Dapatkan waktu saat ini di VPS
        vps_time = subprocess.check_output("date '+%Y-%m-%d %H:%M:%S'", shell=True).decode("ascii").strip()
        

        # Dapatkan uptime VPS
        uptime = subprocess.check_output("uptime -p", shell=True).decode("ascii").strip()

        # Pesan yang diformat dengan jumlah total pengguna
        msg = f"""
**User bot** @Bansosvpnbot  
**Silahkan gunakan Bot Ini**
**Untuk Kebutuhan kalian**

**Total Account Dibuat**
**SSH :**       `{ssh.strip()}` __account__
**VMESS :** `{vms.strip()}` __account__
**VLESS :**    `{vls.strip()}` __account__
**TROJAN :** `{trj.strip()}` __account__

**Total Pengguna:** `{total_users}` __Orang__
**NOTES**
**bot ini aktip tergantung Dana**
**Jika Dana Ada Bisa Perpanjang**
**Ownerku** @R23_VPNSTORE
        """
        x = await event.edit(msg, buttons=inline)
        if not x:
            await event.reply(msg, buttons=inline)

# Fungsi untuk menangani input PIN
@bot.on(events.NewMessage(pattern=r"^\d{4}$"))  # Memastikan bahwa input adalah 4 digit angka
async def handle_pin(event):
    sender = await event.get_sender()
    user_id = str(sender.id)
    pin_input = event.text

    # Cek apakah PIN yang dimasukkan benar
    if pin_input == PIN_CODE:
        user_pins[user_id] = PIN_CODE  # Simpan PIN yang benar untuk pengguna
        await event.respond("PIN benar. Sekarang Anda dapat mengakses menu.", buttons=[Button.inline("Buka Menu", "menu")])
    else:
        await event.respond("PIN salah. Silakan coba lagi.")