from kyt import *
from telethon.tl.types import UserStatusOnline
from telethon.errors.rpcerrorlist import UserNotParticipant

# Ganti dengan chat_id grup Anda
GROUP_CHAT_ID = -1002029496202  # Ganti dengan chat ID grup Anda

# Fungsi untuk memeriksa apakah pengguna sudah menjadi anggota grup
async def is_user_in_group(user_id):
    try:
        participant = await bot.get_chat_member(GROUP_CHAT_ID, user_id)
        # Jika status peserta tidak di 'left', berarti pengguna adalah anggota
        if participant.status in [UserStatusOnline, 'member', 'administrator']:
            return True
    except UserNotParticipant:
        # Pengguna tidak ada dalam grup
        return False

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    sender = await event.get_sender()
    user_id = sender.id
    
    # Periksa apakah pengguna sudah menjadi anggota grup
    is_in_group = await is_user_in_group(user_id)
    
    if not is_in_group:
        # Kirim pesan agar pengguna bergabung dengan grup
        await event.reply("Untuk mengakses menu, Anda harus bergabung dengan grup terlebih dahulu. Klik [di sini untuk bergabung](https://t.me/vpnjabar)")
        return
    
    # Lanjutkan dengan menu jika pengguna sudah bergabung
    save_user(str(user_id))
    admin_msg = f"**Pengguna** @{sender.username} **ID:** `{user_id}`"
    try:
        await bot.send_message(ADMIN_USER_ID, admin_msg)
    except Exception as e:
        print(f"Gagal mengirim notifikasi ke admin: {e}") 

    total_users = len(load_users())

    inline = [
        [Button.inline("SSH WS", "trial-es"),
        Button.inline("VMESS", "trial-puki")],
        [Button.inline("VLESS", "trial-memek"),
        Button.inline("TROJAN", "trial-bujang")],
        [Button.url("GRUP", "https://t.me/vpnjabar"),
        Button.url("ADMIN", "https://t.me/RiswanJabar")],
        [Button.url("DONASI", "https://t.me/Donasivpn"),
        Button.inline("BACK", "start")]
    ]
    
    msg = f"""
**INFO SERVER** @RiswanJabar
**━━━━━━━━━━━━━━━━━━━━━━━**
**Total pengguna** `{total_users}` **User**
**Version bot :** `3.1`
**━━━━━━━━━━━━━━━━━━━━━━━**
    """
    await event.reply(msg, buttons=inline)