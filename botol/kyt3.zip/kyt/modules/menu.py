import json
import subprocess
from kyt import *

# Definisikan ID pengguna admin dan ID grup (ganti dengan ID grup yang sesuai)
ADMIN_USER_ID = 5521096873  # Ganti dengan ID pengguna Telegram admin yang sebenarnya
GROUP_ID = --1002029496202  # Ganti dengan ID grup yang sesuai (gunakan ID grup sebagai negatif)

# Fungsi untuk memuat data pengguna (dalam hal ini, ID pengguna) dari file
def load_users():
    try:
        with open('users.json', 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return []

# Fungsi untuk menyimpan data pengguna (dalam hal ini, ID pengguna) ke file
def save_user(user_id):
    users = load_users()
    if user_id not in users:
        users.append(user_id)
        with open('users.json', 'w') as f:
            json.dump(users, f)

# Fungsi untuk memeriksa apakah pengguna adalah anggota grup
async def is_member_of_group(user_id):
    try:
        participants = await bot.get_participants(GROUP_ID)
        for participant in participants:
            if participant.id == user_id:
                return True
    except Exception as e:
        print(f"Error checking group membership: {e}")
    return False

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    sender = await event.get_sender()
    user_id = str(sender.id)

    # Cek apakah pengguna adalah anggota grup
    if not await is_member_of_group(user_id):
        await event.respond("Anda harus menjadi anggota grup Telegram @grupvpnriswan terlebih dahulu untuk mengakses bot ini.")
        return
    
    # Simpan ID pengguna untuk melacak total pengguna
    save_user(user_id)
    
    # Kirim notifikasi ke admin bahwa ada pengguna yang berinteraksi dengan bot
    admin_msg = f"**Pengguna** @{sender.username} **ID:** `{user_id}`"
    try:
        # Kirim notifikasi ke admin
        await bot.send_message(ADMIN_USER_ID, admin_msg)
    except Exception as e:
        print(f"Gagal mengirim notifikasi ke admin: {e}") 

    # Muat jumlah total pengguna yang ada
    total_users = len(load_users())
    
    # Definisikan tombol inline
    inline = [
        [Button.inline("⚡AKUN SSH WS⚡", "trial-es")],
        [Button.inline("⚡AKUN VMESS⚡", "trial-puki")],
        [Button.inline("⚡AKUN VLESS⚡", "trial-memek")],
        [Button.inline("⚡AKUN TROJAN⚡", "trial-bujang")],
        [Button.url("⚡GRUP CONFIG⚡", "https://t.me/grupvpnriswan")],
        [Button.url("⚡FREE VLESS LITME⚡", "https://t.me/VPN12_FREE")],
        [Button.url("🙏DONASI JIKA ADA🙏", "https://t.me/Donasivpn")],
        [Button.inline("↪️BACK KE MENU AWAL↩️", "start")]
    ]
    
    val = valid(user_id)
    if val == "false":
        try:
            await event.answer("", alert=True)
        except:
            await event.reply("")
    elif val == "true":
        # Ambil informasi sistem dan kirimkan pesan
        # (proses yang sama seperti sebelumnya, tidak ada perubahan di sini)
        # ...
        msg = f"""
**User bot** @Bansosvpnbot  
**Silahkan gunakan Bot Ini**
**Untuk Kebutuhan kalian**

**Total Account Dibuat**
**SSH :**         `{ssh.strip()}` `account`
**VMESS :** `{vms.strip()}` `account`
**VLESS :**    `{vls.strip()}` `account`
**TROJAN :** `{trj.strip()}` `account`

**Pengguna Bot:** `{total_users}` `Orang`
**NOTES**
**bot ini aktip tergantung Dana**
**Jika Dana Ada Bisa Perpanjang**
**Ownerku** @R23_VPNSTORE
        """
        x = await event.edit(msg, buttons=inline)
        if not x:
            await event.reply(msg, buttons=inline)