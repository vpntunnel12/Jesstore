import json
import subprocess
from kyt import *
from telethon.tl.types import PeerChannel

# Definisikan ID grup yang diperlukan untuk akses
REQUIRED_GROUP_ID = -1002029496202  # Ganti dengan ID grup Telegram yang sesuai

# Fungsi untuk memuat data pengguna (dalam hal ini, ID pengguna) dari file
def load_users():
    try:
        with open('users.json', 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return []

# Fungsi untuk menyimpan data pengguna (dalam hal ini, ID pengguna) ke file
def save_user(user_id):
    users = load_users()
    if user_id not in users:
        users.append(user_id)
        with open('users.json', 'w') as f:
            json.dump(users, f)

# Menyimpan grup yang sudah dimasukkan oleh pengguna
user_groups = {}

# Fungsi untuk memeriksa apakah pengguna sudah menjadi anggota grup yang benar
async def is_user_in_group(user_id):
    try:
        user = await bot.get_entity(user_id)
        participant = await bot.get_participant(REQUIRED_GROUP_ID, user)
        return True
    except:
        return False

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    sender = await event.get_sender()
    user_id = str(sender.id)
    
    # Cek apakah pengguna sudah menjadi anggota grup yang diperlukan
    if not await is_user_in_group(user_id):
        await event.respond("Anda harus bergabung dengan grup @vpnjabar terlebih dahulu.")
        return
    
    # Simpan ID pengguna untuk melacak total pengguna
    save_user(user_id)
    
    # Kirim notifikasi ke admin bahwa ada pengguna yang berinteraksi dengan bot
    admin_msg = f"**Pengguna** @{sender.username} **ID:** `{user_id}`"
    try:
        # Kirim notifikasi ke admin
        await bot.send_message(ADMIN_USER_ID, admin_msg)
    except Exception as e:
        print(f"Gagal mengirim notifikasi ke admin: {e}") 

    # Muat jumlah total pengguna yang ada
    total_users = len(load_users())
    
    # Definisikan tombol inline
    inline = [
        [Button.inline("SSH WS", "trial-es"),
         Button.inline("VMESS", "trial-puki")],
        [Button.inline("VLESS", "trial-memek"),
         Button.inline("TROJAN", "trial-bujang")],
        [Button.url("GRUP", "https://t.me/vpnjabar"),
         Button.url("ADMIN", "https://t.me/RiswanJabar")],
        [Button.url("DONASI", "https://t.me/Donasivpn"),  # Tombol URL baru
         Button.inline("BACK", "start")]
    ]
    
    # Ambil informasi sistem
    # (kode untuk mengambil informasi sistem seperti sebelumnya)

    # Pesan yang diformat dengan jumlah total pengguna
    msg = f"""
    **INFO SERVER** @RiswanJabar
**━━━━━━━━━━━━━━━━━━━━━━━**
**LOKASI :** `{city} {country}`
**OS :** `{namaos.strip().replace('"','')}`
**DOMAIN :** `{DOMAIN}`
**IP VPS :** `{ipsaya.strip()}`
**VPS Time :** `{vps_time}`
**UPTIME :** `{uptime}` 
**TOTAL RAM :** `{ram}`
**━━━━━━━━━━━━━━━━━━━━━━━**
**AKUN YANG DIBUAT**
**SSH :** `{ssh.strip()}` 
**VLESS :** `{vls.strip()}` 
**VMESS :** `{vms.strip()}` 
**TROJAN :** `{trj.strip()}`
**━━━━━━━━━━━━━━━━━━━━━━━**
**Total pengguna** `{total_users}` **User**
**Version bot :** `3.1`
**━━━━━━━━━━━━━━━━━━━━━━━**
    """
    await event.edit(msg, buttons=inline)