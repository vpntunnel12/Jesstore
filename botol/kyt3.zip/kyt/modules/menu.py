import json
import subprocess
from kyt import *

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    sender = await event.get_sender()
    user_id = str(sender.id)

    # Ganti dengan ID grup yang ingin Anda periksa
    GROUP_ID = '1002029496202'  # Misal: 'vpnjabar'
    
    # Cek apakah pengguna sudah bergabung dengan grup
    try:
        chat_member = await bot.get_chat_member(GROUP_ID, user_id)
        
        # Jika pengguna belum bergabung dengan grup
        if chat_member.status not in ['member', 'administrator', 'creator']:
            await event.reply(
                "Anda harus bergabung dengan grup terlebih dahulu sebelum mengakses menu.\n"
                "Silakan bergabung di sini: https://t.me/vpnjabar"
            )
            return
        
    except Exception as e:
        # Jika ada error dalam mengambil data anggota, misalnya jika bot tidak bisa akses grup
        await event.reply(
            "Terjadi kesalahan saat memeriksa keanggotaan grup. Pastikan bot memiliki akses ke grup.\n"
            "Silakan coba lagi nanti."
        )
        return

    # Simpan ID pengguna untuk melacak total pengguna
    save_user(user_id)
    
    # Kirim notifikasi ke admin bahwa ada pengguna yang berinteraksi dengan bot
    admin_msg = f"**Pengguna** @{sender.username} **ID:** `{user_id}`"
    try:
        # Kirim notifikasi ke admin
        await bot.send_message(ADMIN_USER_ID, admin_msg)
    except Exception as e:
        print(f"Gagal mengirim notifikasi ke admin: {e}")

    # Muat jumlah total pengguna yang ada
    total_users = len(load_users())

    # Definisikan tombol inline
    inline = [
        [Button.inline("SSH WS", "trial-es"),
        Button.inline("VMESS", "trial-puki")],
        [Button.inline("VLESS", "trial-memek"),
        Button.inline("TROJAN", "trial-bujang")],
        [Button.url("GRUP", "https://t.me/vpnjabar"),
        Button.url("ADMIN", "https://t.me/RiswanJabar")],
        [Button.url("DONASI", "https://t.me/Donasivpn"),
        Button.inline("BACK", "start")]
    ]

    val = valid(user_id)
    if val == "false":
        try:
            await event.answer("", alert=True)
        except:
            await event.reply("")
    elif val == "true":
        # Ambil informasi sistem
        sh = f'cat /etc/passwd | grep "home" | grep "false" | wc -l'
        ssh = subprocess.check_output(sh, shell=True).decode("ascii")
        vm = f'cat /etc/vmess/.vmess.db | grep "###" | wc -l'
        vms = subprocess.check_output(vm, shell=True).decode("ascii")
        vl = f'cat /etc/vless/.vless.db | grep "###" | wc -l'
        vls = subprocess.check_output(vl, shell=True).decode("ascii")
        tr = f'cat /etc/trojan/.trojan.db | grep "###" | wc -l'
        trj = subprocess.check_output(tr, shell=True).decode("ascii")
        sdss = f"cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
        namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
        shadowsocks = subprocess.check_output('cat /etc/shadowsocks/.shadowsocks.db | grep "###" | wc -l', shell=True).decode("ascii")
        ipvps = f"curl -s ipv4.icanhazip.com"
        ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
        
        # Dapatkan Lokasi VPS menggunakan ipinfo.io
        location = subprocess.check_output(f"curl -s http://ipinfo.io/{ipsaya.strip()}/json", shell=True).decode("ascii")
        location_info = json.loads(location)
        city = location_info.get('city', 'Unknown')
        region = location_info.get('region', 'Unknown')
        country = location_info.get('country', 'Unknown')

        # Dapatkan RAM total
        ram = subprocess.check_output("free -h | grep Mem | awk '{print $2}'", shell=True).decode("ascii").strip()

        # Dapatkan waktu saat ini di VPS
        vps_time = subprocess.check_output("date '+%Y-%m-%d %H:%M:%S'", shell=True).decode("ascii").strip()
        
        # Dapatkan uptime VPS
        uptime = subprocess.check_output("uptime -p", shell=True).decode("ascii").strip()

        # Pesan yang diformat dengan jumlah total pengguna
        msg = f"""
**INFO SERVER** @RiswanJabar
**━━━━━━━━━━━━━━━━━━━━━━━**
**LOKASI :** `{city} {country}`
**OS :** `{namaos.strip().replace('"','')}`
**DOMAIN :** `{DOMAIN}`
**IP VPS :** `{ipsaya.strip()}`
**VPS Time :** `{vps_time}`
**UPTIME :** `{uptime}` 
**TOTAL RAM :** `{ram}`
**━━━━━━━━━━━━━━━━━━━━━━━**
**AKUN YANG DIBUAT**
**SSH :** `{ssh.strip()}` 
**VLESS :** `{vls.strip()}` 
**VMESS :** `{vms.strip()}` 
**TROJAN :** `{trj.strip()}`
**━━━━━━━━━━━━━━━━━━━━━━━**
**Total pengguna** `{total_users}` **User**
**Version bot :** `3.1`
**━━━━━━━━━━━━━━━━━━━━━━━**
        """
        x = await event.edit(msg, buttons=inline)
        if not x:
            await event.reply(msg, buttons=inline)