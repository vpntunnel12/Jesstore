import json
from telethon import events, Button
from kyt import *  # Pastikan bot Anda sudah terhubung dengan Telethon dan bot telah diinisialisasi

# ID Grup yang harus menjadi syarat untuk mengakses menu
AUTHORIZED_GROUP_ID = -1002029496202  # Ganti dengan ID grup yang sesuai

# Fungsi untuk memverifikasi apakah pengguna adalah anggota grup
async def is_user_in_group(user_id):
    try:
        # Mendapatkan status anggota grup
        member = await bot.get_chat_member(AUTHORIZED_GROUP_ID, user_id)
        
        # Mengecek apakah pengguna adalah member, administrator, atau creator
        return member.status in ['member', 'administrator', 'creator']
    
    except Exception as e:
        # Menangani kesalahan jika pengguna tidak ditemukan atau ada masalah
        print(f"Gagal memeriksa keanggotaan grup: {e}")
        return False

# Fungsi untuk menampilkan menu setelah verifikasi grup
@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    sender = await event.get_sender()
    user_id = sender.id
    
    # Cek apakah pengguna adalah anggota grup
    if not await is_user_in_group(user_id):
        await event.respond("Anda harus menjadi anggota grup @vpnjabar untuk mengakses menu ini.")
        return
    
    # Kirim pesan menu setelah verifikasi
    inline = [
        [Button.inline("SSH WS", "trial-es"),
         Button.inline("VMESS", "trial-puki")],
        [Button.inline("VLESS", "trial-memek"),
         Button.inline("TROJAN", "trial-bujang")],
        [Button.url("GRUP", "https://t.me/vpnjabar"),
         Button.url("ADMIN", "https://t.me/RiswanJabar")],
        [Button.url("DONASI", "https://t.me/Donasivpn"), 
         Button.inline("BACK", "start")]
    ]

    msg = """
    **Selamat datang di Menu Bot VPN**
    Pilih salah satu opsi di bawah untuk mendapatkan informasi lebih lanjut:
    """

    # Kirim pesan dengan tombol inline
    await event.respond(msg, buttons=inline)