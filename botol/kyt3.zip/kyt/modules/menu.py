import json
import subprocess
from kyt import *  # Pastikan modul kyt Anda sudah sesuai
from telethon import events, Button

# Definisikan ID pengguna admin (ganti dengan ID pengguna Telegram admin yang sesungguhnya)
ADMIN_USER_ID = 5521096873  # Ganti dengan ID pengguna Telegram admin yang sebenarnya

# Definisikan ID Grup yang diizinkan (gunakan ID grup yang sebenarnya)
ALLOWED_GROUP_ID = -1002422975452  # Ganti dengan ID grup yang sesuai

# Fungsi untuk memuat data pengguna (dalam hal ini, ID pengguna) dari file
def load_users():
    try:
        with open('users.json', 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return []

# Fungsi untuk menyimpan data pengguna (dalam hal ini, ID pengguna) ke file
def save_user(user_id):
    users = load_users()
    if user_id not in users:
        users.append(user_id)
        with open('users.json', 'w') as f:
            json.dump(users, f)

# Menyimpan ID pengguna yang sudah terverifikasi keanggotaannya di grup
verified_users = {}

# Fungsi untuk memeriksa apakah pengguna sudah terverifikasi dalam grup
async def is_user_in_group(user_id):
    """
    Memeriksa apakah user dengan user_id sudah ada dalam grup ALLOWED_GROUP_ID.
    Pastikan untuk mengambil seluruh peserta dengan limit=0 agar tidak terbatasi.
    """
    # Konversi user_id ke integer untuk konsistensi
    user_id = int(user_id)
    # Jika sudah diverifikasi sebelumnya, langsung return True
    if str(user_id) in verified_users:
        return True
    try:
        # Ambil seluruh peserta dari grup (limit=0 agar tidak terbatasi)
        participants = await bot.get_participants(ALLOWED_GROUP_ID, limit=0)
        print(f"Jumlah peserta yang diambil: {len(participants)}")  # Debug: cek jumlah peserta
        for user in participants:
            # Bandingkan ID sebagai integer
            if user.id == user_id:
                verified_users[str(user_id)] = True  # Simpan status verifikasi sebagai string
                return True
    except Exception as e:
        print(f"Gagal memeriksa keanggotaan grup: {e}")
    return False

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    sender = await event.get_sender()
    user_id = sender.id  # simpan sebagai integer

    # Cek apakah pengguna sudah terverifikasi dalam grup
    if not await is_user_in_group(user_id):
        await event.respond("**Anda harus menjadi anggota grup @vpntunnell terlebih dahulu untuk mengakses menu.**")
        return

    # Simpan ID pengguna untuk melacak total pengguna
    save_user(str(user_id))
    
    # Kirim notifikasi ke admin bahwa ada pengguna yang berinteraksi dengan bot
    admin_msg = f"**Pengguna** @{sender.username} **ID:** `{user_id}`"
    try:
        await bot.send_message(ADMIN_USER_ID, admin_msg)
    except Exception as e:
        print(f"Gagal mengirim notifikasi ke admin: {e}") 

    # Muat jumlah total pengguna yang ada
    total_users = len(load_users())
    
    # Definisikan tombol inline
    inline = [
        [Button.inline("SSH WS", b"trial-es"),
         Button.inline("VMESS", b"trial-puki")],
        [Button.inline("VLESS", b"trial-memek"),
         Button.inline("TROJAN", b"trial-bujang")],
        [Button.url("GRUP", "https://t.me/vpnjabar"),
         Button.url("ADMIN", "https://t.me/RiswanJabar")],
        [Button.url("DONASI", "https://t.me/Donasivpn"),
         Button.inline("BACK", b"start")]
    ]
    
    # Validasi pengguna (pastikan fungsi valid() sudah didefinisikan)
    val = valid(str(user_id))
    if val == "false":
        try:
            await event.answer("", alert=True)
        except Exception:
            await event.reply("")
    elif val == "true":
        # Ambil informasi sistem melalui perintah shell
        ssh = subprocess.check_output('cat /etc/passwd | grep "home" | grep "false" | wc -l', shell=True).decode("ascii")
        vm = subprocess.check_output('cat /etc/vmess/.vmess.db | grep "###" | wc -l', shell=True).decode("ascii")
        vl = subprocess.check_output('cat /etc/vless/.vless.db | grep "###" | wc -l', shell=True).decode("ascii")
        trj = subprocess.check_output('cat /etc/trojan/.trojan.db | grep "###" | wc -l', shell=True).decode("ascii")
        namaos = subprocess.check_output(
            "cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'",
            shell=True).decode("ascii")
        shadowsocks = subprocess.check_output(
            'cat /etc/shadowsocks/.shadowsocks.db | grep "###" | wc -l',
            shell=True).decode("ascii")
        ipsaya = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True).decode("ascii")
        
        # Dapatkan lokasi VPS menggunakan ipinfo.io
        location = subprocess.check_output(f"curl -s http://ipinfo.io/{ipsaya.strip()}/json", shell=True).decode("ascii")
        location_info = json.loads(location)
        city = location_info.get('city', 'Unknown')
        country = location_info.get('country', 'Unknown')
        
        # Dapatkan RAM total, waktu VPS, dan uptime
        ram = subprocess.check_output("free -h | grep Mem | awk '{print $2}'", shell=True).decode("ascii").strip()
        vps_time = subprocess.check_output("date '+%Y-%m-%d %H:%M:%S'", shell=True).decode("ascii").strip()
        uptime = subprocess.check_output("uptime -p", shell=True).decode("ascii").strip()

        # Pesan dengan informasi sistem dan jumlah pengguna
        msg = f"""
**INFO SERVER** @RiswanJabar
**━━━━━━━━━━━━━━━━━━━━━━━**
**LOKASI :** `{city} {country}`
**OS :** `{namaos.strip().replace('"','')}`
**DOMAIN :** `{DOMAIN}`
**IP VPS :** `{ipsaya.strip()}`
**VPS Time :** `{vps_time}`
**UPTIME :** `{uptime}` 
**TOTAL RAM :** `{ram}`
**━━━━━━━━━━━━━━━━━━━━━━━**
**AKUN YANG DIBUAT**
**SSH :** `{ssh.strip()}` 
**VLESS :** `{vl.strip()}` 
**VMESS :** `{vm.strip()}` 
**TROJAN :** `{trj.strip()}`
**━━━━━━━━━━━━━━━━━━━━━━━**
**Total pengguna** `{total_users}` **User**
**Version bot :** `3.1`
**━━━━━━━━━━━━━━━━━━━━━━━**
        """
        try:
            x = await event.edit(msg, buttons=inline)
            if not x:
                await event.reply(msg, buttons=inline)
        except Exception as e:
            print(f"Error mengedit/reply pesan: {e}")
