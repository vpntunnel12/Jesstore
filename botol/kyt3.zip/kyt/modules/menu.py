from telethon.tl.types import User
from telethon.errors import UserNotParticipantError

# ID grup yang ingin Anda verifikasi (ganti dengan ID grup yang sesuai)
GROUP_ID = -1002029496202  # Ganti dengan ID grup Anda

# Fungsi untuk memeriksa apakah pengguna adalah anggota grup
async def check_group_membership(user_id):
    try:
        # Mengambil daftar peserta grup
        participants = await bot.get_participants(GROUP_ID)

        # Mengecek apakah user_id ada dalam daftar peserta grup
        for participant in participants:
            if participant.id == int(user_id):
                return True
        return False
    except Exception as e:
        print(f"Terjadi kesalahan saat memeriksa anggota grup: {e}")
        return False

# Menggunakan fungsi ini dalam event handler
@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    sender = await event.get_sender()
    user_id = str(sender.id)

    # Mengecek apakah pengguna sudah bergabung dengan grup
    is_member = await check_group_membership(user_id)

    if not is_member:
        # Kirim pesan jika pengguna belum bergabung
        msg = "Anda harus bergabung dengan grup terlebih dahulu untuk menggunakan bot ini. Silakan klik tombol di bawah untuk bergabung."
        join_button = Button.url("Bergabung dengan Grup", "https://t.me/vpnjabar")  # Ganti dengan link grup Anda
        await event.reply(msg, buttons=[join_button])
        return

    # Lanjutkan dengan menampilkan menu jika pengguna sudah bergabung
    inline = [
        [Button.inline("SSH WS", "trial-es"),
         Button.inline("VMESS", "trial-puki")],
        [Button.inline("VLESS", "trial-memek"),
         Button.inline("TROJAN", "trial-bujang")],
        [Button.url("GRUP", "https://t.me/vpnjabar"),
         Button.url("ADMIN", "https://t.me/RiswanJabar")],
        [Button.url("DONASI", "https://t.me/Donasivpn"),
         Button.inline("BACK", "start")]
    ]
    
    # Kirim menu jika pengguna sudah diverifikasi
    val = valid(user_id)
    if val == "false":
        try:
            await event.answer("", alert=True)
        except:
            await event.reply("")
    elif val == "true":
        # Ambil informasi server dan tampilkan menu
        # (lakukan proses server info seperti pada kode asli Anda)
        msg = f"Informasi Server dan Menu"
        await event.reply(msg, buttons=inline)