import random
import json
from telethon import events, Button

# File untuk menyimpan status verifikasi
VERIFIED_USERS_FILE = 'verified_users.json'

# Fungsi untuk memuat status verifikasi pengguna
def load_verified_users():
    try:
        with open(VERIFIED_USERS_FILE, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return []

# Fungsi untuk menyimpan status verifikasi pengguna
def save_verified_user(user_id):
    verified_users = load_verified_users()
    if user_id not in verified_users:
        verified_users.append(user_id)
        with open(VERIFIED_USERS_FILE, 'w') as f:
            json.dump(verified_users, f)

# Mengirimkan kode verifikasi
async def send_verification_code(event):
    sender = await event.get_sender()
    user_id = str(sender.id)
    
    # Membuat kode verifikasi acak
    verification_code = str(random.randint(1000, 9999))
    
    # Menyimpan kode verifikasi untuk pengguna
    with open(f"verification_{user_id}.txt", 'w') as f:
        f.write(verification_code)
    
    # Mengirimkan kode verifikasi ke pengguna
    await event.reply(f"Untuk melanjutkan, masukkan kode verifikasi berikut: `{verification_code}`")

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
async def menu(event):
    sender = await event.get_sender()
    user_id = str(sender.id)

    # Cek apakah pengguna sudah diverifikasi
    if user_id not in load_verified_users():
        # Jika belum diverifikasi, kirimkan kode verifikasi
        await send_verification_code(event)
        return
    
    # Jika sudah diverifikasi, tampilkan menu
    inline = [
        [Button.inline("⚡AKUN SSH WS⚡", "trial-es")],
        [Button.inline("⚡AKUN VMESS⚡", "trial-puki")],
        [Button.inline("⚡AKUN VLESS⚡", "trial-memek")],
        [Button.inline("⚡AKUN TROJAN⚡", "trial-bujang")],
        [Button.url("⚡GRUP CONFIG⚡", "https://t.me/grupvpnriswan")],
        [Button.url("⚡FREE VLESS LITME⚡", "https://t.me/VPN12_FREE")],
        [Button.inline("🙏DONASI JIKA ADA🙏", "start")]
    ]
    
    # Menampilkan menu
    msg = "Selamat datang di menu utama. Pilih salah satu opsi di bawah:"
    await event.reply(msg, buttons=inline)

@bot.on(events.NewMessage(pattern=r"^\d{4}$"))
async def verify_code(event):
    sender = await event.get_sender()
    user_id = str(sender.id)
    entered_code = event.text.strip()
    
    # Cek apakah kode yang dimasukkan sesuai dengan yang disimpan
    try:
        with open(f"verification_{user_id}.txt", 'r') as f:
            correct_code = f.read().strip()
        
        if entered_code == correct_code:
            # Menyimpan status verifikasi pengguna
            save_verified_user(user_id)
            await event.reply("Verifikasi berhasil! Anda sekarang dapat mengakses menu.")
        else:
            await event.reply("Kode verifikasi salah! Silakan coba lagi.")
    except FileNotFoundError:
        await event.reply("Kode verifikasi tidak ditemukan. Silakan kirim ulang permintaan verifikasi.")