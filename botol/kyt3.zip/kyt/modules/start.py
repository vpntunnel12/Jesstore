from kyt import *

@bot.on(events.NewMessage(pattern=r"(?:.start|/start)$"))
@bot.on(events.CallbackQuery(data=b'start'))
async def start(event):
    inline = [
        [Button.inline("↪️MENU AKUN↩️", "menu")]
    ]
    sender = await event.get_sender()
    val = valid(str(sender.id))
    if val == "false":
        try:
            await event.answer("Akses Ditolak", alert=True)
        except:
            await event.reply("Akses Ditolak")
    elif val == "true":
        sh = f'cat /etc/ssh/.ssh.db | grep "###" | wc -l'
        ssh = subprocess.check_output(sh, shell=True).decode("ascii")
        vm = f'cat /etc/vmess/.vmess.db | grep "###" | wc -l'
        vms = subprocess.check_output(vm, shell=True).decode("ascii")
        vl = f'cat /etc/vless/.vless.db | grep "###" | wc -l'
        vls = subprocess.check_output(vl, shell=True).decode("ascii")
        tr = f'cat /etc/trojan/.trojan.db | grep "###" | wc -l'
        trj = subprocess.check_output(tr, shell=True).decode("ascii")
        sdss = f"cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
        namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
        ipvps = f"curl -s ipv4.icanhazip.com"
        ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")

        # Personalize the welcome message by including the user's name or username
        welcome_message = f"Selamat datang, {sender.first_name}!" if sender.first_name else "Selamat datang pengguna!"

        msg = f"""
**{welcome_message}**
Anda harus bergabung dengan grup terlebih dahulu untuk mengakses menu. Silakan gabung di grup berikut:\n@vpnjabar
"""
        x = await event.edit(msg, buttons=inline)
        if not x:
            await event.reply(msg, buttons=inline)