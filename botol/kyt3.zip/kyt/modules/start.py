from kyt import *
import asyncio

# Tentukan kode verifikasi atau gunakan metode dinamis
KODE_VERIFIKASI = "12345"  # Kode statis contoh, ganti dengan kode yang lebih aman

@bot.on(events.NewMessage(pattern=r"(?:.start|/start)$"))
@bot.on(events.CallbackQuery(data=b'start'))
async def start(event):
    inline = [
        [Button.inline("↪️MENU AKUN↩️", "menu")]
    ]
    sender = await event.get_sender()
    val = valid(str(sender.id))  # Periksa apakah pengguna valid

    if val == "false":
        try:
            await event.answer("Akses Ditolak", alert=True)
        except:
            await event.reply("Akses Ditolak")
    elif val == "true":
        # Minta verifikasi sebelum melanjutkan
        await event.reply("Masukkan kode verifikasi untuk melanjutkan:")

        # Tunggu balasan pengguna
        respon_verifikasi = await bot.wait_for(events.NewMessage(from_user=sender.id))

        # Periksa apakah kode yang dimasukkan sesuai dengan kode verifikasi
        if respon_verifikasi.text.strip() == KODE_VERIFIKASI:
            # Verifikasi berhasil, lanjutkan pengambilan informasi sistem
            sh = f'cat /etc/ssh/.ssh.db | grep "###" | wc -l'
            ssh = subprocess.check_output(sh, shell=True).decode("ascii")
            vm = f'cat /etc/vmess/.vmess.db | grep "###" | wc -l'
            vms = subprocess.check_output(vm, shell=True).decode("ascii")
            vl = f'cat /etc/vless/.vless.db | grep "###" | wc -l'
            vls = subprocess.check_output(vl, shell=True).decode("ascii")
            tr = f'cat /etc/trojan/.trojan.db | grep "###" | wc -l'
            trj = subprocess.check_output(tr, shell=True).decode("ascii")
            sdss = f"cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
            namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
            ipvps = f"curl -s ipv4.icanhazip.com"
            ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")

            msg = f"""
https://iili.io/2JTaJ0Q.jpg
**◇━━━━━━━━━━━━━━━━━━━━━━◇**
**Yang Mau ikut patungan Vps**
**Silahkan Tf ke sini ya**

**Jika Dana sudah Terkumpul**
**biar Bisa melanjutkan bot🙏**
**Tetep Onlene**
**◇━━━━━━━━━━━━━━━━━━━━━━◇**
"""
            x = await event.edit(msg, buttons=inline)
            if not x:
                await event.reply(msg, buttons=inline)
        else:
            # Verifikasi gagal, beri tahu pengguna
            await event.reply("Kode verifikasi salah. Silakan coba lagi.")