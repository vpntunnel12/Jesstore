from kyt import *


@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
	async def ssh_(event):
		inline = [
            [Button.inline("1 𝙷𝚊𝚛𝚒", "trial-ssh"),
             Button.inline("2 𝙷𝚊𝚛𝚒", "trial-es")],
            [Button.inline("𝙲𝚎𝚔 𝚄𝚜𝚎𝚛 𝙻𝚘𝚐𝚒𝚗", "login-ssh")],
            [Button.inline("𝙻𝚒𝚜𝚝 𝚄𝚜𝚎𝚛", "show-ssh")],
            [Button.inline("‹ 𝙼𝚊𝚒𝚗 𝙼𝚎𝚗𝚞 ›", "menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
**◇━━━━━━━━━━━━━━━━━━◇**
**◇⟨🔸SSH & OPENVPN SERVICE🔸⟩◇**
**◇━━━━━━━━━━━━━━━━━━◇**
**» Service:** `SSH OVPN`
**» Hostname/IP:** `{DOMAIN}`
**» ISP:** `{z["isp"]}`
**» Country:** `{z["country"]}`
🤖 **» @LITE_VERMILION**
**◇━━━━━━━━━━━━━━━━━━◇**
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await ssh_(event)
	else:
		await event.answer("Access Denied",alert=True)
