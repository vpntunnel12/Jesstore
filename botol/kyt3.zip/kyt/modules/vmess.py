from kyt import *
import requests
import subprocess


from telethon import events
import subprocess
import base64
import json
import datetime as DT
import re

# Dictionary untuk menyimpan data tanggal terakhir pengguna mendapatkan trial
user_last_trial = {}

@bot.on(events.CallbackQuery(data=b'trial-puki'))
async def trial_vmess(event):
    async def generate_vmess_account():
        # Command untuk generate VMess account
        cmd = f'printf "%s\n" "RZVMESS`</dev/urandom tr -dc X-Z0-9 | head -c4`" "3" "2000" "2000" | addws-bot'

        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            # Menangani error saat menjalankan subprocess
            await event.respond(f"An error occurred while generating the VMess account: {str(e)}")
            return

        # Menghitung tanggal expired (3 hari dari hari ini)
        today = DT.date.today()
        later = today + DT.timedelta(days=3)

        # Mengambil URL VMess
        b = [x.group() for x in re.finditer("vmess://(.*)", a)]

        if len(b) < 3:
            await event.respond("Failed to generate required VMess URLs.")
            return

        # Decode URL VMess
        try:
            z = base64.b64decode(b[0].replace("vmess://", "")).decode("ascii")
            z = json.loads(z)
            z1 = base64.b64decode(b[1].replace("vmess://", "")).decode("ascii")
            z1 = json.loads(z1)
        except Exception as e:
            await event.respond(f"Error decoding VMess data: {str(e)}")
            return

        # Membuat pesan yang akan dikirimkan ke pengguna
        msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
    **⟨🔸 Vmess Account🔸⟩**
**◇━━━━━━━━━━━━━━━━━◇**
**» Host Server :** `{DOMAIN}`
**» Port TLS    :** `443, 400-900`
**» Port NTLS   :** `80, 8080, 8081-9999`
**» UUID        :** `{z["id"]}`
**» NetWork     :** `(WS) or (gRPC)`
**» Path        :** `/vmess`
**» ServiceName :** `vmess-grpc`
**◇━━━━━━━━━━━━━━━━━◇**
**» URL TLS     :**
```{b[0].strip("'").replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» URL HTTP    :**
```{b[1].strip("'").replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» URL gRPC    :** 
```{b[2].strip("'")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» Expired     :** `{later}`
**◇━━━━━━━━━━━━━━━━━◇**
**» ** 🤖@R23_VPNSTORE
        """
        await event.respond(msg)

    # Cek apakah pengguna sudah mendapatkan akun trial hari ini
    chat = event.chat_id
    sender = await event.get_sender()
    user_id = str(sender.id)  # ID pengguna yang akan dipakai sebagai kunci

    today = DT.date.today()

    # Jika pengguna sudah pernah mendapatkan akun hari ini, beri pesan akses ditolak
    if user_id in user_last_trial:
        last_trial_date = user_last_trial[user_id]
        if last_trial_date == today:
            await event.answer("Anda sudah menerima akun hari ini. Coba lagi besok!", alert=True)
            return

    # Jika pengguna valid, kirimkan akun trial dan update tanggal terakhir
    a = valid(user_id)  # Cek apakah pengguna valid

    if a == "true":
        await generate_vmess_account()
        # Update tanggal terakhir kali pengguna menerima akun trial
        user_last_trial[user_id] = today
    else:
        await event.answer("Akses Ditolak", alert=True)
        
        

#CEK VMESS
@bot.on(events.CallbackQuery(data=b'cek-vmess'))
async def cek_vmess(event):
    async def cek_vmess_(event):
        cmd = 'cek-ws'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"""
**◇━━━━━━━━━━━━━━━━━━◇**
 ** ⟨🔸Cek Vmess User Login🔸⟩**
**◇━━━━━━━━━━━━━━━━━━◇**
{z}

**Shows Logged In Users Vmess**
""", buttons=[[Button.inline("‹ Main menu ›", "vmess")]])

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await cek_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)



## CEK member VMESS
@bot.on(events.CallbackQuery(data=b'cek-member'))
async def cek_vmess(event):
    async def cek_vmess_(event):
        cmd = 'bash cek-mws'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"""

{z}

**Shows Users from databases**
""", buttons=[[Button.inline("‹ main menu ›", "vmess")]])

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await cek_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

		
@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess(event):
    async def vmess_(event):
        inline = [
            
             [Button.inline("⚡BANSOS 3 HARI⚡", "trial-puki")],
            
            [Button.inline("⚡CEK USER LOGIN⚡", "cek-vmess")],
            [Button.inline("⚡LIST USER⚡", "cek-member")],

            [Button.inline("↪️MAIN MENU↩️", "menu")]
        ]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
    **◇⟨🔸VMESS SERVICE🔸⟩◇**
**◇━━━━━━━━━━━━━━━━━◇**
**» Service:** `VMESS`
**» Hostname/IP:** `{DOMAIN}`
**» ISP:** `{z["isp"]}`
**» Country:** `{z["country"]}`
**» ** 🤖@R23_VPNSTORE
**◇━━━━━━━━━━━━━━━━━◇**
"""
        await event.edit(msg, buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)



