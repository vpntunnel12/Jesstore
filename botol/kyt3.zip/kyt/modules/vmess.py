from kyt import *
import requests
import subprocess


import subprocess
import base64
import json
import re
import datetime as DT
import os

# Path untuk menyimpan file tanggal permintaan terakhir
LAST_REQUEST_FILE = 'last_request_data.json'

# Fungsi untuk membaca data permintaan terakhir dari file
def read_last_request_data():
    if os.path.exists(LAST_REQUEST_FILE):
        with open(LAST_REQUEST_FILE, 'r') as f:
            return json.load(f)
    return {}

# Fungsi untuk menulis data permintaan terakhir ke file
def write_last_request_data(data):
    with open(LAST_REQUEST_FILE, 'w') as f:
        json.dump(data, f)

# Fungsi validasi pengguna (misalnya memeriksa apakah pengguna terotorisasi)
def valid(user_id):
    # Logika validasi: sesuaikan dengan validasi pengguna yang sesuai
    return "true" if user_id == "your_valid_user_id" else "false"

async def trial_vmess_(event):
    # Mendapatkan informasi pengguna
    sender = await event.get_sender()
    user_id = str(sender.id)
    
    # Membaca data permintaan terakhir
    last_request_data = read_last_request_data()
    
    # Cek apakah pengguna sudah meminta hari ini
    today = DT.date.today().isoformat()
    if user_id in last_request_data and last_request_data[user_id] == today:
        await event.respond("Anda hanya bisa meminta Vmess sekali per hari.")
        return

    # Jika belum meminta hari ini, lanjutkan untuk membuat akun VMess
    cmd = f'printf "%s\n" "RZVMESS`</dev/urandom tr -dc X-Z0-9 | head -c4`" "3" "2000" "2000" | addws-bot'

    try:
        a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except Exception as e:
        print(f'Error: {e}')
        await event.respond(f"Terjadi kesalahan: {e}")
        return  # Menghentikan eksekusi jika ada kesalahan

    today = DT.date.today()
    later = today + DT.timedelta(days=3)  # Menyesuaikan tanggal kadaluarsa

    # Memparsing URL vmess dari output
    b = [x.group() for x in re.finditer("vmess://(.*)", a)]
    
    if len(b) < 2:
        await event.respond("Error: Tidak ada cukup URL VMess ditemukan.")
        return

    # Meng-decode data URL vmess dengan base64
    try:
        z = base64.b64decode(b[0].replace("vmess://", "")).decode("ascii")
        z = json.loads(z)
        z1 = base64.b64decode(b[1].replace("vmess://", "")).decode("ascii")
        z1 = json.loads(z1)
    except Exception as e:
        await event.respond(f"Error decoding vmess data: {e}")
        return

    msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
    **⟨🔸 Akun Vmess🔸⟩**
**◇━━━━━━━━━━━━━━━━━◇**
**» Host Server :** `{DOMAIN}`
**» Port TLS    :** `443, 400-900`
**» Port NTLS   :** `80, 8080, 8081-9999 `
**» UUID        :** `{z["id"]}`
**» NetWork     :** `(WS) atau (gRPC)`
**» Path        :** `/vmess`
**» ServiceName :** `vmess-grpc`
**◇━━━━━━━━━━━━━━━━━◇**
**» URL TLS    :**
```{b[0].strip("'").replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» URL HTTP    :**
```{b[1].strip("'").replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» URL gRPC   :** 
```{b[2].strip("'")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» Kadaluarsa:** `{later}`
**◇━━━━━━━━━━━━━━━━━◇**
**» ** 🤖@R23_VPNSTORE
    """
    
    await event.respond(msg)

    # Setelah memberikan trial, update tanggal permintaan terakhir
    last_request_data[user_id] = today
    write_last_request_data(last_request_data)

@bot.on(events.CallbackQuery(data=b'trial-puki'))
async def handle_trial_vmess(event):
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await trial_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)
        

#CEK VMESS
@bot.on(events.CallbackQuery(data=b'cek-vmess'))
async def cek_vmess(event):
    async def cek_vmess_(event):
        cmd = 'cek-ws'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"""
**◇━━━━━━━━━━━━━━━━━━◇**
 ** ⟨🔸Cek Vmess User Login🔸⟩**
**◇━━━━━━━━━━━━━━━━━━◇**
{z}

**Shows Logged In Users Vmess**
""", buttons=[[Button.inline("‹ Main menu ›", "vmess")]])

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await cek_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)



## CEK member VMESS
@bot.on(events.CallbackQuery(data=b'cek-member'))
async def cek_vmess(event):
    async def cek_vmess_(event):
        cmd = 'bash cek-mws'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"""

{z}

**Shows Users from databases**
""", buttons=[[Button.inline("‹ main menu ›", "vmess")]])

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await cek_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

		
@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess(event):
    async def vmess_(event):
        inline = [
            
             [Button.inline("⚡BANSOS 3 HARI⚡", "trial-puki")],
            
            [Button.inline("⚡CEK USER LOGIN⚡", "cek-vmess")],
            [Button.inline("⚡LIST USER⚡", "cek-member")],

            [Button.inline("↪️MAIN MENU↩️", "menu")]
        ]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
    **◇⟨🔸VMESS SERVICE🔸⟩◇**
**◇━━━━━━━━━━━━━━━━━◇**
**» Service:** `VMESS`
**» Hostname/IP:** `{DOMAIN}`
**» ISP:** `{z["isp"]}`
**» Country:** `{z["country"]}`
**» ** 🤖@R23_VPNSTORE
**◇━━━━━━━━━━━━━━━━━◇**
"""
        await event.edit(msg, buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)



