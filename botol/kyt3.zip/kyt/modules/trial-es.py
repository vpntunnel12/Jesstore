import sqlite3
import datetime as DT
import random
from telethon.sync import TelegramClient
from telethon import events, Button
import subprocess

# Koneksi ke database SQLite atau buat jika belum ada
conn = sqlite3.connect('trial_requests.db')
cursor = conn.cursor()

# Membuat tabel untuk menyimpan data permintaan trial jika belum ada
cursor.execute('''CREATE TABLE IF NOT EXISTS trial_requests (
                    user_id TEXT PRIMARY KEY,
                    last_request_date TEXT)''')
conn.commit()

# Fungsi untuk memeriksa apakah pengguna sudah pernah meminta trial hari ini
def has_requested_today(user_id):
    today = DT.date.today().strftime('%Y-%m-%d')
    cursor.execute("SELECT last_request_date FROM trial_requests WHERE user_id = ?", (user_id,))
    result = cursor.fetchone()
    if result:
        # Jika pengguna sudah pernah meminta, cek tanggalnya
        return result[0] == today
    return False

# Fungsi untuk memperbarui atau memasukkan tanggal permintaan pengguna
def update_request_date(user_id):
    today = DT.date.today().strftime('%Y-%m-%d')
    cursor.execute("INSERT OR REPLACE INTO trial_requests (user_id, last_request_date) VALUES (?, ?)", (user_id, today))
    conn.commit()

@bot.on(events.CallbackQuery(data=b'trial-es'))
async def trial_ssh(event):
    user_id = str(event.sender_id)

    # Cek apakah pengguna sudah meminta trial hari ini
    if has_requested_today(user_id):
        await event.answer("Anda hanya dapat meminta trial sekali per hari.", alert=True)
        return

    async def trial_ssh_(event):
        user = "RZSSH-" + str(random.randint(400, 1000))
        pw = "2"  # Anda bisa mengganti ini dengan generator password acak
        exp = "3"  # Masa berlaku trial dalam hari
        ip = "2000"  # Alamat IP atau detail lain yang diperlukan
        
        # Perintah untuk membuat akun pengguna
        cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
        try:
            subprocess.check_output(cmd, shell=True)
        except subprocess.CalledProcessError as e:
            await event.respond("**Gagal Membuat Akun**\nError: " + str(e))
        else:
            today = DT.date.today()
            later = today + DT.timedelta(days=int(exp))
            msg = f"""
◇━━━━━━━━━━━━━━━━━◇
**◇⟨🔸Ssh & OpenVpn 🔸⟩◇**
◇━━━━━━━━━━━━━━━━━◇
**» Domain:** `{DOMAIN}`
**» Username:** `{user.strip()}`
**» Password:** `{pw.strip()}`
◇━━━━━━━━━━━━━━━━━◇
**» Port OpenSsh :** 443, 80, 22
**» Port Dropbear :** 443, 109
**» Port Ssh Ws :** 80, 8080
**» Port Ssh Ws Ssl/Tls :** 443
**» Port Ssh UDP :** 1-65535 
**» Port Ovpn Ssl :** 443
**» Port Ovpn TCP :** 443, 1194
**» Port Ovpn UDP :** 2200
**» BadVPN UDP :** 7100, 7300, 7300
◇━━━━━━━━━━━━━━━━━◇
**⟨SSH CUSTOM⟩**
`{DOMAIN}:80@{user.strip()}:{pw.strip()}`
**SSH UDP CUSTOM**
`{DOMAIN}:1-65535@{user.strip()}:{pw.strip()}`
◇━━━━━━━━━━━━━━━━━◇
**⟨OpenVpn⟩**
https://{DOMAIN}:81/
◇━━━━━━━━━━━━━━━━━◇
**⟨Payload Websocket⟩**
```GET /cdn-cgi/trace HTTP/1.1[crlf]Host: Bug_Kalian[crlf][crlf]GET-RAY / HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]```
◇━━━━━━━━━━━━━━━━━◇
**» Expired:** {later}
◇━━━━━━━━━━━━━━━━━◇
**» ** 🤖@R23_VPNSTORE
"""
            inline = [
                [Button.url("Telegram", "t.me/R23_VPNSTORE"),
                 Button.url("WhatsApp", "wa.me/6285888801241")]
            ]
            await event.respond(msg, buttons=inline)

    # Validasi akses pengguna dan lanjutkan jika diizinkan
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Mengasumsikan `valid()` adalah fungsi untuk memeriksa akses pengguna

    if a == "true":
        await trial_ssh_(event)
        update_request_date(user_id)  # Memperbarui tanggal permintaan menjadi hari ini
    else:
        await event.answer("Akses Ditolak", alert=True)