from kyt import *
import subprocess
import datetime as DT
import sys
from telethon.sync import TelegramClient
import sqlite3
import random

import random
import subprocess
import datetime as DT
import json
from telethon import events, Button

# Path untuk menyimpan data user
USER_DATA_FILE = 'user_data.json'

# Dictionary untuk menyimpan data tanggal terakhir pengguna mendapatkan trial
user_last_trial = {}

# Fungsi untuk menyimpan data pengguna ke dalam file JSON
def save_user_data():
    with open(USER_DATA_FILE, 'w') as f:
        json.dump(user_last_trial, f)

# Fungsi untuk memuat data pengguna dari file JSON
def load_user_data():
    global user_last_trial
    try:
        with open(USER_DATA_FILE, 'r') as f:
            user_last_trial = json.load(f)
    except FileNotFoundError:
        user_last_trial = {}

@bot.on(events.CallbackQuery(data=b'trial-es'))
async def trial_ssh(event):
    user_id = str(event.sender_id)
    
    # Memuat data pengguna dari file JSON
    load_user_data()

    # Cek apakah pengguna sudah menerima trial pada hari ini
    today = DT.date.today()
    if user_id in user_last_trial:
        last_trial_date = user_last_trial[user_id]
        if last_trial_date == today:
            await event.answer("Anda sudah menerima akun trial hari ini. Coba lagi besok!", alert=True)
            return  # Jika sudah mendapatkan trial hari ini, batalkan

    async def trial_ssh_():
        user = "RZSSH-" + str(random.randint(400, 1000))
        pw = "2"
        exp = "3"
        
        # Perintah untuk membuat akun SSH
        cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
        
        try:
            subprocess.check_output(cmd, shell=True)
        except:
            await event.respond("**Gagal membuat akun SSH**")
            return
        
        later = today + DT.timedelta(days=int(exp))  # Set expired date to 3 days later

        msg = f"""
◇━━━━━━━━━━━━━━━━━◇
**◇⟨🔸Ssh & OpenVpn 🔸⟩◇**
◇━━━━━━━━━━━━━━━━━◇
**» Domain:** `{DOMAIN}`
**» Username:** `{user.strip()}`
**» Password:** `{pw.strip()}`
◇━━━━━━━━━━━━━━━━━◇
**» Port OpenSsh :** 443, 80, 22
**» Port Dropbear :** 443, 109
**» Port Ssh Ws :** 80, 8080
**» Port Ssh Ws Ssl/Tls :** 443
**» Port Ssh UDP :** 1-65535 
**» Port Ovpn Ssl :** 443
**» Port Ovpn TCP :** 443, 1194
**» Port Ovpn UDP :** 2200
**» BadVPN UDP :** 7100, 7300, 7300
◇━━━━━━━━━━━━━━━━━◇
**⟨SSH CUSTOM⟩**
`{DOMAIN}:80@{user.strip()}:{pw.strip()}`
**SSH UDP COSTOM**
`{DOMAIN}:1-65535@{user.strip()}:{pw.strip()}`
◇━━━━━━━━━━━━━━━━━◇
**⟨OpenVpn⟩**
https://{DOMAIN}:81/
◇━━━━━━━━━━━━━━━━━◇
**⟨Payload Websocket⟩**
```GET /cdn-cgi/trace HTTP/1.1[crlf]Host: Bug_Kalian[crlf][crlf]GET-RAY / HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]```
◇━━━━━━━━━━━━━━━━━◇
**»Expired:** {later}
◇━━━━━━━━━━━━━━━━━◇
**» ** 🤖@R23_VPNSTORE
"""
        inline = [
            [Button.url("Telegram", "t.me/R23_VPNSTORE"),
             Button.url("Whatsapp", "wa.me/6285888801241")]
        ]
        await event.respond(msg, buttons=inline)

        # Update tanggal terakhir kali pengguna menerima trial
        user_last_trial[user_id] = today
        save_user_data()  # Simpan data terbaru ke file JSON

    a = valid(user_id)  # Memanggil fungsi valid untuk memeriksa apakah pengguna valid

    if a == "true":
        await trial_ssh_()  # Jika valid, buatkan akun trial dan kirimkan
    else:
        await event.answer("Akses Ditolak", alert=True)

# Panggil load_user_data() saat bot dijalankan
load_user_data()