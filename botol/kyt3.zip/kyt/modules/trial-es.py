from kyt import *
import subprocess
import datetime as DT
import sys
from telethon.sync import TelegramClient
import sqlite3
import random

import subprocess
import random
import datetime as DT
import json
from telethon import events, Button

# Menyimpan data pembuatan akun (misalnya menggunakan file JSON)
def get_user_data():
    try:
        with open('user_data.json', 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

def save_user_data(data):
    with open('user_data.json', 'w') as f:
        json.dump(data, f)

@bot.on(events.CallbackQuery(data=b'trial-es'))
async def trial_ssh(event):
    user_id = str(event.sender_id)
    
    async def trial_ssh_(event):
        # Cek apakah pengguna sudah membuat akun hari ini
        user_data = get_user_data()
        today = DT.date.today().isoformat()

        # Jika pengguna sudah membuat akun hari ini
        if user_id in user_data and user_data[user_id] == today:
            await event.respond("**Anda sudah membuat akun SSH hari ini. Cobalah lagi besok.**")
            return

        # Membuat username, password, dan perintah untuk membuat akun
        user = "RZSSH-" + str(random.randint(400, 1000))
        pw = "2"
        exp = "3"
        ip = "2000"
        
        cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
        
        try:
            subprocess.check_output(cmd, shell=True)
        except subprocess.CalledProcessError:
            await event.respond("**Error: Could not create SSH account**")
            return
        except Exception as e:
            await event.respond(f"**Error: {str(e)}**")
            return

        # Menghitung tanggal expired akun
        later = DT.date.today() + DT.timedelta(days=int(exp))
        
        # Membuat pesan untuk pengguna
        msg = f"""
◇━━━━━━━━━━━━━━━━━◇
**◇⟨🔸Ssh & OpenVpn 🔸⟩◇**
◇━━━━━━━━━━━━━━━━━◇
**» Domain:** `{DOMAIN}`
**» Username:** `{user.strip()}`
**» Password:** `{pw.strip()}`
◇━━━━━━━━━━━━━━━━━◇
**» Port OpenSsh :** 443, 80, 22
**» Port Dropbear :** 443, 109
**» Port Ssh Ws :** 80, 8080
**» Port Ssh Ws Ssl/Tls :** 443
**» Port Ssh UDP :** 1-65535 
**» Port Ovpn Ssl :** 443
**» Port Ovpn TCP :** 443, 1194
**» Port Ovpn UDP :** 2200
**» BadVPN UDP :** 7100, 7300, 7300
◇━━━━━━━━━━━━━━━━━◇
**⟨SSH CUSTOM⟩**
`{DOMAIN}:80@{user.strip()}:{pw.strip()}`
**SSH UDP CUSTOM**
`{DOMAIN}:1-65535@{user.strip()}:{pw.strip()}`
◇━━━━━━━━━━━━━━━━━◇
**⟨OpenVpn⟩**
https://{DOMAIN}:81/
◇━━━━━━━━━━━━━━━━━◇
**⟨Payload Websocket⟩**
```GET /cdn-cgi/trace HTTP/1.1[crlf]Host: Bug_Kalian[crlf][crlf]GET-RAY / HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]```
◇━━━━━━━━━━━━━━━━━◇
**»Expired:** {later}
◇━━━━━━━━━━━━━━━━━◇
**» ** 🤖@RiswanJabar
"""
        # Menambahkan tombol untuk tautan Telegram dan WhatsApp
        inline = [
            [Button.url("Telegram", "t.me/RiswanJabar"),
             Button.url("Whatsapp", "wa.me/6285888801241")]
        ]
        
        await event.respond(msg, buttons=inline)

        # Update data: menyimpan tanggal pembuatan akun untuk pengguna ini
        user_data[user_id] = today
        save_user_data(user_data)

    # Memeriksa apakah pengguna valid
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await trial_ssh_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)