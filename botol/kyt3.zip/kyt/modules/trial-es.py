from datetime import datetime, timedelta
import random
import subprocess
from telethon import Button

# Dictionary untuk menyimpan tanggal terakhir pengguna membuat akun trial
user_last_request_ssh = {}

@bot.on(events.CallbackQuery(data=b'trial-es'))
async def trial_ssh(event):
    user_id = str(event.sender_id)  # Mendapatkan ID pengguna

    # Mendapatkan tanggal hari ini
    today = datetime.today().date()

    # Memeriksa jika pengguna sudah meminta akun trial hari ini
    if user_id in user_last_request_ssh:
        last_request_date = user_last_request_ssh[user_id]
        if last_request_date == today:
            await event.respond("Anda sudah meminta akun SSH trial hari ini. Silakan coba lagi besok.")
            return  # Menolak permintaan jika sudah meminta hari ini

    async def trial_ssh_(event):
        user = "RZSSH-" + str(random.randint(400, 1000))  # Membuat username acak
        pw = "2"  # Password
        exp = "3"  # Masa berlaku akun (3 hari)
        
        # Perintah untuk membuat akun SSH
        cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
        try:
            subprocess.check_output(cmd, shell=True)  # Menjalankan perintah shell
        except subprocess.CalledProcessError:
            await event.respond("Terjadi kesalahan saat membuat akun SSH.")
            return
        else:
            later = today + timedelta(days=int(exp))  # Tanggal kedaluwarsa akun (3 hari)
            msg = f"""
◇━━━━━━━━━━━━━━━━━◇
**◇⟨🔸SSH & OpenVPN 🔸⟩◇**
◇━━━━━━━━━━━━━━━━━◇
**» Domain:** `{DOMAIN}`
**» Username:** `{user.strip()}`
**» Password:** `{pw.strip()}`
◇━━━━━━━━━━━━━━━━━◇
**» Port OpenSsh :** 443, 80, 22
**» Port Dropbear :** 443, 109
**» Port SSH WS :** 80, 8080
**» Port SSH WS SSL/TLS :** 443
**» Port SSH UDP :** 1-65535 
**» Port OpenVPN SSL :** 443
**» Port OpenVPN TCP :** 443, 1194
**» Port OpenVPN UDP :** 2200
**» BadVPN UDP :** 7100, 7300, 7300
◇━━━━━━━━━━━━━━━━━◇
**⟨SSH CUSTOM⟩**
`{DOMAIN}:80@{user.strip()}:{pw.strip()}`
**SSH UDP CUSTOM**
`{DOMAIN}:1-65535@{user.strip()}:{pw.strip()}`
◇━━━━━━━━━━━━━━━━━◇
**⟨OpenVPN⟩**
https://{DOMAIN}:81/
◇━━━━━━━━━━━━━━━━━◇
**⟨Payload Websocket⟩**
```GET /cdn-cgi/trace HTTP/1.1[crlf]Host: Bug_Kalian[crlf][crlf]GET-RAY / HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]```
◇━━━━━━━━━━━━━━━━━◇
**» Expired:** {later}
◇━━━━━━━━━━━━━━━━━◇
**» ** 🤖@R23_VPNSTORE
"""
            # Menambahkan tombol untuk link Telegram dan WhatsApp
            inline = [
                [Button.url("Telegram", "t.me/R23_VPNSTORE"),
                 Button.url("WhatsApp", "wa.me/6285888801241")]
            ]
            await event.respond(msg, buttons=inline)

            # Menyimpan tanggal permintaan pengguna agar tidak bisa meminta lagi hari ini
            user_last_request_ssh[user_id] = today

    # Memeriksa apakah pengguna valid (menggunakan fungsi valid() yang Anda sebutkan sebelumnya)
    a = valid(str(event.sender_id))
    if a == "true":
        await trial_ssh_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)