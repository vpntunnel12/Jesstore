from kyt import *


@bot.on(events.CallbackQuery(data=b'create-trojan'))
async def create_trojan(event):
    async def create_trojan_(event):
        # Collect user inputs
        async with bot.conversation(chat) as conv:
            await event.respond('**Username:**')
            user_message = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = user_message.raw_text
            
            await event.respond('**masa aktip akun :**')
            exp_message = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = exp_message.raw_text
            
            await event.respond('**Limit Ip:**')
            ip_message = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            ip = ip_message.raw_text
            
            await event.respond('**Limit Quota:**')
            quota_message = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            quota = quota_message.raw_text

            # Ask for additional info
            await event.respond('**Server  :**')
            location_message = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            location = location_message.raw_text
            
            await event.respond('**Config Apa :**')
            config_message = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            config_type = config_message.raw_text
            
            await event.respond('**harga akun :**')
            price_message = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            price = price_message.raw_text

        await event.edit("`Wait.. Setting up an Account`")
        
        # Execute command to generate Trojan URL
        cmd = f'printf "%s\n" "{user}" "{exp}" "{quota}" "{ip}" | addtr-bot'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            await event.respond(f"Error occurred: {e}")
            return
        
        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))
        
        # Extract URLs and UUID from the output
        b = [x.group() for x in re.finditer("trojan://(.*)", a)]
        if len(b) < 3:
            await event.respond("Error: Expected multiple Trojan URLs, but got fewer.")
            return
        
        domain = re.search("@(.*?):", b[0]).group(1)
        uuid = re.search("trojan://(.*?)@", b[0]).group(1)

        # Format the final message with all the details
        msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━**
              **❞CREATE TROJAN❞**
**━━━━━━━━━━━━━━━━━━━━━━**
**❞Remarks :** `{user}`
**❞Host Server :** `{domain}`
**❞Port TLS    :** `443`
**❞Port NTLS   :** `80`
**❞UUID    :** `{uuid}`
**❞NetWork     :** `(WS) or (gRPC)`
**❞Path        :** `/trojan`
**❞ServiceName :** `trojan-grpc`
**━━━━━━━━━━━━━━━━━━━━━━**
**❞TROJAN URL TLS:**  
```{b[0]}```  
**━━━━━━━━━━━━━━━━━━━━━━**
**❞TROJAN URL HTTP:**  
```{b[1].replace(" ", "")}```  
**━━━━━━━━━━━━━━━━━━━━━━**
**❞TROJAN URL gRPC:**  
```{b[2].replace(" ", "")}```  
**━━━━━━━━━━━━━━━━━━━━━━**
**❞Expired:** `{later}`
**━━━━━━━━━━━━━━━━━━━━━━**
`💰{user}:{config_type}:{later}💰`
**━━━━━━━━━━━━━━━━━━━━━━**
**❞Testimonial:**  
```◇━━━━━━━━━━━━━━━━━◇  
💰PEMBELIAN BERHASIL💰
◇━━━━━━━━━━━━━━━━━◇  
-» PRODUK : TROJAN  
-» SERVER : {location}  
-» CONFIG : {config_type}  
-» USER   : {user}  
-» LOGIN  : 2 IP  
-» HARGA  : {price}  
-» EXP    : {later}  
◇━━━━━━━━━━━━━━━━━◇```  
by @R23_VPNSTORE  
**━━━━━━━━━━━━━━━━━━━━━━**
"""
        
        await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await create_trojan_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'cek-tr'))
async def cek_trojan(event):
    try:
        # Menjalankan perintah cek-tr
        cmd = 'cek-tr'.strip()  # Pastikan 'cek-tr' ada di PATH atau gunakan path lengkap
        result = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)

        # Menampilkan hasil ke pengguna
        await event.edit(f"""
**◇━━━━━━━━━━━━━━━━━━◇**
 ** ⟨🔸Cek Trojan User Login🔸⟩**
**◇━━━━━━━━━━━━━━━━━━◇**

{result}

**Shows Logged In Users Trojan**
        """, buttons=[[Button.inline("main menu", b"menu")]])

    except subprocess.CalledProcessError as e:
        # Menangani error saat eksekusi perintah cek-tr
        await event.edit(f"Error: {str(e)}", buttons=[[Button.inline("‹ main menu ›", b"menu")]])

    except Exception as e:
        # Menangani error umum lainnya
        await event.edit(f"Unexpected Error: {str(e)}", buttons=[[Button.inline("‹ main menu ›", b"menu")]])


@bot.on(events.CallbackQuery(data=b'trial-trojan'))
async def trial_trojan(event):
    async def trial_trojan_(event):
        cmd = f'printf "%s\n" "trial`</dev/urandom tr -dc X-Z0-9 | head -c4`" "1" "2000" "2000" | bot-trialtr'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**User Already Exist**")
        else:
            today = DT.date.today()
            later = today + DT.timedelta(days=int(1))
            b = [x.group() for x in re.finditer("trojan://(.*)", a)]
            print(b)
            remarks = re.search("#(.*)", b[0]).group(1)
            domain = re.search("@(.*?):", b[0]).group(1)
            uuid = re.search("trojan://(.*?)@", b[0]).group(1)
            msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━**
                **❞TRIAL TROJAN❞**
**━━━━━━━━━━━━━━━━━━━━━━**
**❞Host Server :** `{DOMAIN}`
**❞Port TLS    :** `443`
**❞Port NTLS   :** `80`
**❞UUID    :** `{uuid}`
**❞NetWork     :** `(WS) or (gRPC)`
**❞Path        :** `/trojan`
**❞ServiceName :** `trojan-grpc`
**━━━━━━━━━━━━━━━━━━━━━━**
**❞TROJAN URL TLS❞:**
```{𝚋[0]}```
**━━━━━━━━━━━━━━━━━━━━━━**
**❞TROJAN URL HTTP❞:**
```{𝚋[1].𝚛𝚎𝚙𝚕𝚊𝚌𝚎(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━━**
**❞TROJAN URL gRPC❞:** 
```{𝚋[2].𝚛𝚎𝚙𝚕𝚊𝚌𝚎(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━━**
**❞Notes pelangan**
**❞simpan detail pembelian akun**
**❞sebagai garansi. kirimkan detail** 
**❞pembelian akun ke admin untuk** 
**❞pengecekan ketika terjadi masalah**
**❞pada config**
**❞Exp jatuh pada:** `{today}`
**◇━━━━━━━━━━━━━━━━━◇**
**» ** 🤖@R23_VPNSTORE
**━━━━━━━━━━━━━━━━━━━━━━**
"""
            await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await trial_trojan_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'renew-trojan'))
async def ren_trojan(event):
    async def ren_trojan_(event):
        async with bot.conversation(chat) as user:
            await event.respond('**Username:**')
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        
        async with bot.conversation(chat) as exp:
            await event.respond('**Expired:**')
            exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = (await exp).raw_text

        async with bot.conversation(chat) as ip:
            await event.respond('**Limit IP:**')
            ip = ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            ip = (await ip).raw_text

        async with bot.conversation(chat) as Quota:
            await event.respond('**Limit Quota:**')
            Quota = Quota.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            Quota = (await Quota).raw_text


        
        cmd = f'printf "%s\n" "{user}" "{exp}" "{Quota}" "{ip}" | bot-renew-tro'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**Successfully Renew User**")
        else:
            msg = f"""
**{user} {exp} days limit ip {ip} limit Quota {Quota}GB**
"""
            await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await ren_trojan_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)



# CEK member tr
@bot.on(events.CallbackQuery(data=b'cek-membertr'))
async def cek_tr(event):
    try:
        # Menjalankan perintah bash
        cmd = 'bash cek-mts'.strip()
        result = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)

        # Mengirim hasil ke pengguna
        await event.edit(f"""
{result}

**Shows Users from databases**
        """, buttons=[[Button.inline("‹ main menu ›", b"menu")]])

    except subprocess.CalledProcessError as e:
        # Jika terjadi error saat eksekusi perintah bash
        await event.edit(f"Error: {str(e)}", buttons=[[Button.inline("‹ main menu ›", b"menu")]])

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await cek_tr_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)


		
@bot.on(events.CallbackQuery(data=b'delete-trojan'))
async def delete_trojan(event):
    async def delete_trojan_(event):
        async with bot.conversation(chat) as user:
            await event.respond('**Username:**')
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        cmd = f'printf "%s\n" "{user}" | bot-del-tro'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**Successfully Delete User**")
        else:
            msg = f"""**Successfully Deleted**"""
            await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await delete_trojan_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)



@bot.on(events.CallbackQuery(data=b'trojan'))
async def trojan(event):
    async def trojan_(event):
        inline = [
            [Button.inline("Trial trojan", "trial-trojan"),
             Button.inline("Create trojan", "create-trojan")],
            [Button.inline("Cek login trojan", "cek-tr"),
             Button.inline("Delete trojan", "delete-trojan")],
            [Button.inline("Renew trojan", "renew-trojan")],
            [Button.inline("Cek user trojan", "cek-membertr"),
             Button.inline("‹ main menu ›", "menu")]
        ]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
   **◇⟨🔸TROJAN SERVICE🔸⟩◇**
              **Admin Manager**
**◇━━━━━━━━━━━━━━━━━◇**
**» Service:** `TROJAN`
**» Hostname/IP:** `{DOMAIN}`
**» ISP:** `{z["isp"]}`
**» Country:** `{z["country"]}`
**» ** 🤖@R23_VPNSTORE
**◇━━━━━━━━━━━━━━━━━◇**
        """
        await event.edit(msg, buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await trojan_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)