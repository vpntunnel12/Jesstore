from kyt import *

@bot.on(events.CallbackQuery(data=b'create-akun'))
async def create_ssh(event):
    chat = event.chat_id
    sender = await event.get_sender()

    a = valid(str(sender.id))
    if a != "true":
        await event.answer("ᴀᴋsᴇs ᴅɪᴛᴏʟᴀᴋ", alert=True)
        return

    async with bot.conversation(chat) as conv:
        await event.respond('**Username:**')
        user = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        await event.respond("**Password:**")
        pw = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        await event.respond("**Quota:**")
        quota = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        await event.respond("**Limit-ip:**")
        limit_ip = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        await event.respond("**masa aktip akun :**")
        exp = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        # Ask for the server location
        await event.respond("**Server :**")
        server_location = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        # Ask for the config (optional)
        await event.respond("**Config Apa :**")
        config = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        # Ask for the price (optional)
        await event.respond("**harga akun :**")
        price = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        await event.edit("`Wait.. Setting up an Account`")
        
        # Perintah untuk membuat user SSH         
        cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
        try:
            subprocess.check_output(cmd, shell=True)
        except subprocess.CalledProcessError:
            await event.respond("**Failed to create account. Please try again.**")
            return

        # Hitung tanggal kadaluarsa
        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))

        # Pesan hasil
        msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━**
              **❞CREATE SSH WS❞**
**━━━━━━━━━━━━━━━━━━━━━━**
**❞Hostem:** `{DOMAIN}`
**❞Usernem:** `{user.strip()}`
**❞Passwd:** `{pw.strip()}`
**❞Limit Quota** `{Quota}` **GB**
**❞Limit login** `{ip}` **Login**
**━━━━━━━━━━━━━━━━━━━━━━**
**❞Server Location:** `{server_location.strip()}`  
**━━━━━━━━━━━━━━━━━━━━━━**
**❞Config:** `{config.strip()}`  
**━━━━━━━━━━━━━━━━━━━━━━**
**❞Price:** `{price.strip()}`  
**━━━━━━━━━━━━━━━━━━━━━━**
**❞FORMAT HTTP COSTUM❞:**
`{DOMAIN}:80@{user.strip()}:{pw.strip()}`
**━━━━━━━━━━━━━━━━━━━━━━**
**❞FORMAT UDP COSTUM❞:**
`{DOMAIN}:1-65535@{user.strip()}:{pw.strip()}`
**━━━━━━━━━━━━━━━━━━━━━━**
**❞Payload❞:**
```GET /cdn-cgi/trace HTTP/1.1[crlf]Host: Bug_Kalian[crlf][crlf]GET-RAY / HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]```
**━━━━━━━━━━━━━━━━━━━━━━**
**❞Notes pelangan**
**❞simpan detail pembelian akun**
**❞sebagai garansi. kirimkan detail** 
**❞pembelian akun ke admin untuk** 
**❞pengecekan ketika terjadi masalah**
**❞pada config**
**❞Expired:** 
`💰{user}-{config.strip()}-{later}💰`
**━━━━━━━━━━━━━━━━━━━━━━**
**❞Silahkan salin buat Testimoni**
```◇━━━━━━━━━━━━━━━━━◇
💰PEMBELIAN BERHASIL💰
◇━━━━━━━━━━━━━━━━━◇
-» PRODUK : SSH OVPN
-» QUOTA  : {Quota} GB
-» LOGIN  : {ip} IP
-» SERVER : {server_location.strip()}
-» CONFIG : {config.strip()}
-» USER   : {user}
-» HARGA  : {price.strip()}
-» EXP    : {later}
◇━━━━━━━━━━━━━━━━━◇```
by @R23_VPNSTORE
**━━━━━━━━━━━━━━━━━━━━━━**
"""

        await event.respond(msg)
        
