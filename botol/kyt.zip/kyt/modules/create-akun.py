from kyt import *

@bot.on(events.CallbackQuery(data=b'create-akun'))
async def create_ssh(event):
    chat = event.chat_id
    sender = await event.get_sender()

    a = valid(str(sender.id))
    if a != "true":
        await event.answer("ᴀᴋsᴇs ᴅɪᴛᴛᴏʟᴀᴋ", alert=True)
        return

    async with bot.conversation(chat) as conv:
        await event.respond('**Username:**')
        user = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        await event.respond("**Password:**")
        pw = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        await event.respond("**Login ip:**")
        limit_ip = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        await event.respond("**Expired Day :**")
        exp = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        await event.edit("`Wait.. Setting up an Account`")
        
        # Fetch ISP and Location information
        isp_data = requests.get(f"http://ip-api.com/json/?fields=isp,country,city").json()
        isp = isp_data.get("isp", "Unknown ISP")
        country = isp_data.get("country", "Unknown Country")
        city = isp_data.get("city", "Unknown City")

        # Command to create the SSH user         
        cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
        try:
            subprocess.check_output(cmd, shell=True)
        except subprocess.CalledProcessError:
            await event.respond("**Failed to create account. Please try again.**")
            return

        # Calculate expiration date
        today = DT.date.today()  # Account creation date
        later = today + DT.timedelta(days=int(exp))  # Expiration date

        # Response message
        msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━**
**Pembelian Ssh ws berhasil**
**━━━━━━━━━━━━━━━━━━━━━━**
**ISP :** `{isp}` 
**Server :** `{city}, {country}`
**Domain:** `{DOMAIN}`
**Username:** `{user.strip()}`
**Password:** `{pw.strip()}`
**━━━━━━━━━━━━━━━━━━━━━━**
**Limit IP:** `{limit_ip.strip()}`
**━━━━━━━━━━━━━━━━━━━━━━**
**FORMAT HTTP COSTUM:**
`{DOMAIN}:80@{user.strip()}:{pw.strip()}`
**━━━━━━━━━━━━━━━━━━━━━━**
**FORMAT UDP COSTUM:**
`{DOMAIN}:1-65535@{user.strip()}:{pw.strip()}`
**━━━━━━━━━━━━━━━━━━━━━━**
**Dibuat Tgl:** `{today}`
**Expired On :** `{later}`
**━━━━━━━━━━━━━━━━━━━━━━**
**by** 🤖@RiswanJabar
"""
        
        # Send both the account details and the dates in separate messages
        await event.respond(msg)
    