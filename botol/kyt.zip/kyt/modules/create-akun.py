from kyt import *

@bot.on(events.CallbackQuery(data=b'create-akun'))
async def create_ssh(event):
    chat = event.chat_id
    sender = await event.get_sender()

    a = valid(str(sender.id))
    if a != "true":
        await event.answer("ᴀᴋsᴇs ᴅɪᴛᴏʟᴀᴋ", alert=True)
        return

    async with bot.conversation(chat) as conv:
        await event.respond('**Username:**')
        user = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        await event.respond("**Password:**")
        pw = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        await event.respond("**Login ip:**")
        limit_ip = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        await event.respond("**Expired Day :**")
        exp = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        await event.edit("`Wait.. Setting up an Account`")
        
        # Perintah untuk membuat user SSH         
        cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
        try:
            subprocess.check_output(cmd, shell=True)
        except subprocess.CalledProcessError:
            await event.respond("**Failed to create account. Please try again.**")
            return

        # Hitung tanggal kadaluarsa
        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))

        # Pesan hasil
        msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━**
              **❞CREATE SSH WS❞**
**━━━━━━━━━━━━━━━━━━━━━━**
**❞Hostem:** `{DOMAIN}`
**❞Usernem:** `{user.strip()}`
**❞Passwd:** `{pw.strip()}`
**━━━━━━━━━━━━━━━━━━━━━━**
**❞Limit IP:** `{limit_ip.strip()}`
**━━━━━━━━━━━━━━━━━━━━━━**
**❞Expired:** 
`💰{user}-{later}💰`
**━━━━━━━━━━━━━━━━━━━━━━**
**❞FORMAT HTTP COSTUM❞:**
`{DOMAIN}:80@{user.strip()}:{pw.strip()}`
**━━━━━━━━━━━━━━━━━━━━━━**
**❞FORMAT UDP COSTUM❞:**
`{DOMAIN}:1-65535@{user.strip()}:{pw.strip()}`
**━━━━━━━━━━━━━━━━━━━━━━**
**❞Payload❞:**
```GET /cdn-cgi/trace HTTP/1.1[crlf]Host: Bug_Kalian[crlf][crlf]GET-RAY / HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]```
**━━━━━━━━━━━━━━━━━━━━━━**
`💰{user}-{later}💰`
**━━━━━━━━━━━━━━━━━━━━━━**
**❞Silahkan salin buat Testimoni**
```◇━━━━━━━━━━━━━━━━━◇
💰PEMBELIAN BERHASIL💰
◇━━━━━━━━━━━━━━━━━◇
-» PRODUK : SSH OVPN
-» USER   : {user}
-» LOGIN  : 2 IP
-» EXP    : {later}
◇━━━━━━━━━━━━━━━━━◇```
by 🤖@RiswanJabar
**━━━━━━━━━━━━━━━━━━━━━━**
"""

        await event.respond(msg)
        
