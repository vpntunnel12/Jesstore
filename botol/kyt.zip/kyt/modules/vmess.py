from kyt import *


@bot.on(events.CallbackQuery(data=b'create-vmess'))
async def create_vmess(event):
    async def create_vmess_(event):
        async with bot.conversation(chat) as user_conv:
            await event.respond('**Username :**')
            user = (await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

            await event.respond('**Expired day :**')
            exp = (await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

            await event.respond('**Login IP :**')
            ip = (await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

            await event.respond('**Limit Quota:**')
            Quota = (await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        cmd = f'printf "%s\n" "{user}" "{exp}" "{Quota}" "{ip}" | addws-bot'

        a = ''
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            await event.respond(f"An error occurred: {e}\nSubprocess output: {a}")
            return

        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))

        b = [x.group() for x in re.finditer("vmess://(.*)", a)]
        if len(b) < 3:
            await event.respond("Insufficient VMESS URLs generated.")
            return

        z = base64.b64decode(b[0].replace("vmess://", "")).decode("ascii")
        z = json.loads(z)

        z1 = base64.b64decode(b[1].replace("vmess://", "")).decode("ascii")
        z1 = json.loads(z1)

        msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━**
              **❞CREATE VMESS❞**
**━━━━━━━━━━━━━━━━━━━━━━**
**❞Remarks :** `{user}`
**❞Limit login** `{ip}` **Login**
**❞Limit Quota** `{Quota}` **GB**
**❞Port TLS :** `443`
**❞Port NTLS :** `80`
**❞UUID :** `{z["id"]}`
**❞NetWork :** `(WS) or (gRPC)`
**❞Path :** `/vmess`
**❞ServiceName :** `vmess-grpc`
**━━━━━━━━━━━━━━━━━━━━━━**
**❞VMESS URL TLS:**
```{b[0].strip("'").replace(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━━**
**❞VMESS URL HTTP:**
```{b[1].strip("'").replace(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━━**
**❞VMESS URL gRPC:** 
```{b[2].strip("'")}```
**━━━━━━━━━━━━━━━━━━━━━━**
`💰{user}-{later}💰`
**━━━━━━━━━━━━━━━━━━━━━━**
**❞Silahkan salin buat Testimoni**
```◇━━━━━━━━━━━━━━━━━◇
💰PEMBELIAN BERHASIL💰
◇━━━━━━━━━━━━━━━━━◇
-» PRODUK : VMESS
-» QUOTA  : {Quota} GB
-» LOGIN  : {ip} IP
-» USER   : {user}
-» EXP    : {later}
◇━━━━━━━━━━━━━━━━━◇```
**by :** @R23_VPNSTORE
**━━━━━━━━━━━━━━━━━━━━━━**
        """
        await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await create_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)





# TRIAL VMESS
@bot.on(events.CallbackQuery(data=b'trial-vmess'))
async def trial_vmess(event):
    async def trial_vmess_(event):
        # loading animasi
        await event.edit("Processing.")
        await event.edit("Processing..")
        await event.edit("Processing...")
        await event.edit("Processing....")
        time.sleep(1)
        await event.edit("`Processing Crate Premium Account`")
        time.sleep(1)
        await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
        time.sleep(0)
        await event.edit("`Processing... 100%\n█████████████████████████ `")
        time.sleep(1)
        await event.edit("`Wait.. Setting up an Account`")

        # output cmd
        cmd = f'printf "%s\n" "Trial`</dev/urandom tr -dc X-Z0-9 | head -c4`" "1" "2000" "2000" | bot-trialws'

        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            print(f'Error: {e}')
            print(f'Subprocess output: {a}')
            await event.respond(f"An error occurred: {e}\nSubprocess output: {a}")
            return  # Stop execution if there's an error

        today = DT.date.today()
        later = today + DT.timedelta(days=1)  # You may need to adjust this, as "exp" is not defined in the scope
        b = [x.group() for x in re.finditer("vmess://(.*)", a)]

        z = base64.b64decode(b[0].replace("vmess://", "")).decode("ascii")
        z = json.loads(z)

        z1 = base64.b64decode(b[1].replace("vmess://", "")).decode("ascii")
        z1 = json.loads(z1)

        msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━**
               **❞TRIAL VMESS❞**
**━━━━━━━━━━━━━━━━━━━━━━**
**❞Host Server :** `{DOMAIN}`
**❞Port TLS    :** `443`
**❞Port NTLS   :** `80`
**❞UUID    :** `{z["id"]}`
**❞NetWork     :** `(WS) or (gRPC)`
**❞Path        :** `/vmess`
**❞ServiceName :** `vmess-grpc`
**━━━━━━━━━━━━━━━━━━━━━━**
**❞VMESS URL TLS❞:**
```{b[0].strip("'").replace(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━━**
**❞VMESS URL HTTP❞:**
```{b[1].strip("'").replace(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━━**
**❞VMESS URL gRPC❞:** 
```{b[2].strip("'")}```
**━━━━━━━━━━━━━━━━━━━━━━**
**❞Notes pelangan**
**❞simpan detail pembelian akun**
**❞sebagai garansi. kirimkan detail** 
**❞pembelian akun ke admin untuk** 
**❞pengecekan ketika terjadi masalah**
**❞pada config**
**❞exp jatuh pada:** `{today}`
**━━━━━━━━━━━━━━━━━━━━━━**
**» ** 🤖@R23_VPNSTORE
        """
        await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await trial_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

import subprocess
from telethon import events

@bot.on(events.CallbackQuery(data=b'cek-vmess'))
async def cek_vmess(event):
    cmd = 'cek-ws'.strip()  # Menjalankan perintah cek-ws
    try:
        # Menjalankan perintah dan menangkap outputnya
        result = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)

        # Mencari baris yang mengandung informasi tanggal expired
        tanggal_expired = "Tidak Ditemukan"  # Default jika tanggal expired tidak ditemukan
        for line in result.splitlines():
            if "Expired" in line:  # Misalnya, mencari baris yang mengandung kata 'Expired'
                tanggal_expired = line.split(":")[1].strip()  # Mengambil tanggal setelah kata "Expired:"

        # Mengirimkan balasan ke pengguna dengan tanggal expired
        await event.respond(f"""
**◇━━━━━━━━━━━━━━━━━━◇**
** ⟨🔸Cek Vmess User Login🔸⟩**
**◇━━━━━━━━━━━━━━━━━━◇**
**Tanggal Expired:** {tanggal_expired}

**Menampilkan Pengguna Vmess yang Terlogin**
""")
    except subprocess.CalledProcessError as e:
        # Jika perintah gagal, kirimkan pesan kesalahan
        await event.respond(f"Terjadi kesalahan saat menjalankan perintah: {e.output}")


## CEK member VMESS
@bot.on(events.CallbackQuery(data=b'cek-member'))
async def cek_vmess(event):
    cmd = 'bash cek-mws'.strip()
    
    try:
        # Eksekusi perintah bash dan ambil outputnya
        result = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        
        # Daftar untuk menyimpan pengguna yang melebihi ambang batas dan sedang online
        users_above_threshold_and_online = []

        # Memproses output (misalnya format "IP: <ip>, Logins: <jumlah>, Status: <online/offline>")
        for line in result.splitlines():
            if 'IP:' in line and 'Logins:' in line and 'Status:' in line:
                # Contoh baris: "IP: 192.168.1.1, Logins: 6, Status: online"
                parts = line.split(', ')
                ip = parts[0].split(': ')[1]
                logins = int(parts[1].split(': ')[1])
                status = parts[2].split(': ')[1].strip().lower()  # Status bisa "online" atau "offline"
                
                # Memeriksa apakah login melebihi ambang batas dan statusnya online
                if logins > AMBANG_LOGIN_IP and status == 'online':
                    users_above_threshold_and_online.append(f"IP: {ip}, Logins: {logins}, Status: {status}")
        
        # Menampilkan hasilnya kepada pengguna
        if users_above_threshold_and_online:
            await event.respond(f"""
**Pengguna yang login melebihi ambang batas {AMBANG_LOGIN_IP} dan sedang online:**

{chr(10).join(users_above_threshold_and_online)}
            """)
        else:
            await event.respond(f"Tidak ada pengguna yang login melebihi ambang batas {AMBANG_LOGIN_IP} dan sedang online.")
    
    except subprocess.CalledProcessError as e:
        # Menangani error jika perintah gagal dieksekusi
        await event.respond(f"Terjadi kesalahan saat mengeksekusi perintah: {e.output}")



@bot.on(events.CallbackQuery(data=b'delete-vmess'))
async def delete_vmess(event):
    async def delete_vmess_(event):
        async with bot.conversation(chat) as user:
            await event.respond('**Username:**')
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        cmd = f'printf "%s\n" "{user}" | bot-del-vme'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**Successfully Delete User**")
        else:
            msg = f"""**Successfully Deleted {user} **"""
            await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await delete_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)
        

@bot.on(events.CallbackQuery(data=b'renew-vmess'))
async def ren_vmess(event):
    async def ren_vmess_(event):
        async with bot.conversation(chat) as user_conv:
            await event.respond('**Username:**')
            user = await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = user.raw_text

        async with bot.conversation(chat) as exp_conv:
            await event.respond('**Expired:**')
            exp = await exp_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = exp.raw_text
            
        async with bot.conversation(chat) as ip_conv:
            await event.respond('**Limit IP:**')
            ip = await ip_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            ip = ip.raw_text
            
        async with bot.conversation(chat) as Quota_conv:
            await event.respond('**Limit Quota:**')
            Quota = await Quota_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            Quota = Quota.raw_text  

        cmd = f'printf "%s\n" "{user}" "{exp}" "{Quota}" "{ip}" | bot-renew-vme'

        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**Successfully Perpanjang akun✅**")
        
            msg = f"""
━━━━━━━━━━━━━━━━━━━
💰PERPANJANG AKUN VIP💰
━━━━━━━━━━━━━━━━━━━
✅USER:  `{user}`
✅AKTIP:  `{exp}` hari
✅LOGIN:  `{ip}`Device
✅DATA VPN:  `{Quota}`GB
━━━━━━━━━━━━━━━━━━━
"""
            await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await ren_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)








		
@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess(event):
    async def vmess_(event):
        inline = [
            [Button.inline("𝗧𝗿𝗶𝗮𝗹 𝗩𝗺𝗲𝘀𝘀", "trial-vmess"),
             Button.inline("𝗖𝗿𝗮𝘁𝗲 𝗩𝗺𝗲𝘀𝘀", "create-vmess")],
            [Button.inline("𝗖𝗲𝗸 𝗟𝗼𝗴𝗶𝗻", "cek-vmess"),
             Button.inline("𝗛𝗮𝗽𝘂𝘀 𝗨𝘀𝗲𝗿", "delete-vmess")],
            [Button.inline("𝗥𝗲𝗻𝗲𝘄 𝗨𝘀𝗲𝗿", "renew-vmess")],
            [Button.inline("𝗖𝗲𝗸 𝗨𝘀𝗲𝗿", "cek-member"),
             Button.inline("𝗕𝗮𝗰𝗸 𝗠𝗲𝗻𝘂", "menu")]
        ]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
   **◇⟨🔸VMESS SERVICE🔸⟩◇**
              **Admin Manager**
**◇━━━━━━━━━━━━━━━━━◇**
**» Service:** `VMESS`
**» Hostname/IP:** `{DOMAIN}`
**» ISP:** `{z["isp"]}`
**» Country:** `{z["country"]}`
**» ** 🤖@R23_VPNSTORE
**◇━━━━━━━━━━━━━━━━━◇**
"""
        await event.edit(msg, buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)



