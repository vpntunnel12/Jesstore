
@bot.on(events.CallbackQuery(data=b'create-vmess'))
async def create_vmess(event):
    async def create_vmess_(event):
        async with bot.conversation(chat) as user_conv:
            await event.respond('**Username :**')
            user = (await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

            await event.respond('**Expired day :**')
            exp = (await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

            await event.respond('**Login IP :**')
            ip = (await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

            await event.respond('**Limit Quota:**')
            Quota = (await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        # Fetch ISP and Location information
        isp_data = requests.get(f"http://ip-api.com/json/?fields=isp,country,city").json()
        isp = isp_data.get("isp", "Unknown ISP")
        country = isp_data.get("country", "Unknown Country")
        city = isp_data.get("city", "Unknown City")

        cmd = f'printf "%s\n" "{user}" "{exp}" "{Quota}" "{ip}" | addws-bot'

        a = ''
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            await event.respond(f"An error occurred: {e}\nSubprocess output: {a}")
            return

        today = DT.date.today()  # Account creation date
        later = today + DT.timedelta(days=int(exp))  # Expiration date

        b = [x.group() for x in re.finditer("vmess://(.*)", a)]
        if len(b) < 3:
            await event.respond("Insufficient VMESS URLs generated.")
            return

        z = base64.b64decode(b[0].replace("vmess://", "")).decode("ascii")
        z = json.loads(z)

        z1 = base64.b64decode(b[1].replace("vmess://", "")).decode("ascii")
        z1 = json.loads(z1)

        msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━**
**Pembelian Akun Vmess berhasil**
**━━━━━━━━━━━━━━━━━━━━━━**
**ISP :** `{isp}` 
**Server :** `{city}, {country}`
**Domain :** `{DOMAIN}`
**Remarks :** `{user}`
**Limit login** `{ip}` **Login**
**Limit Quota** `{Quota}` **GB**
**Port TLS :** `443`
**Port NTLS :** `80`
**UUID :** `{z["id"]}`
**NetWork :** `(WS) or (gRPC)`
**Path :** `/vmess`
**ServiceName :** `vmess-grpc`
**━━━━━━━━━━━━━━━━━━━━━━**
**VMESS URL TLS:**
```{b[0].strip("'").replace(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━━**
**VMESS URL HTTP:**
```{b[1].strip("'").replace(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━━**
**VMESS URL gRPC:** 
```{b[2].strip("'")}```
**━━━━━━━━━━━━━━━━━━━━━━**
**Dibuat Tgl:** `{today}`
**Expired On :** `{later}`
**━━━━━━━━━━━━━━━━━━━━━━**
**by :** @RiswanJabar
        """
        
        # Kirim notifikasi ke grup Telegram
        group_chat_id = "<ID Grup Telegram Kamu>"
        notification_msg = f"""
        Akun VMESS baru telah dibuat!

        **Username**: {user}
        **Expired Day**: {exp}
        **Login IP**: {ip}
        **Quota**: {Quota} GB

        ISP: {isp}
        Lokasi: {city}, {country}

        Tanggal Dibuat: {today}
        Tanggal Expired: {later}
        """
        await bot.send_message(group_chat_id, notification_msg)  # Mengirim notifikasi ke grup

        await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await create_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)


@bot.on(events.CallbackQuery(data=b'trial-vmess'))
async def trial_vmess(event):
    async def trial_vmess_(event):
        # loading animasi
        await event.edit("Processing.")
        await event.edit("Processing..")
        await event.edit("Processing...")
        await event.edit("Processing....")
        time.sleep(1)
        await event.edit("`Processing Crate Premium Account`")
        time.sleep(1)
        await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
        time.sleep(0)
        await event.edit("`Processing... 100%\n█████████████████████████ `")
        time.sleep(1)
        await event.edit("`Wait.. Setting up an Account`")

        # Fetch ISP and Location information
        isp_data = requests.get(f"http://ip-api.com/json/?fields=isp,country,city").json()
        isp = isp_data.get("isp", "Unknown ISP")
        country = isp_data.get("country", "Unknown Country")
        city = isp_data.get("city", "Unknown City")

        # output cmd
        cmd = f'printf "%s\n" "Trial`</dev/urandom tr -dc X-Z0-9 | head -c4`" "1" "2000" "2000" | bot-trialws'

        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            print(f'Error: {e}')
            print(f'Subprocess output: {a}')
            await event.respond(f"An error occurred: {e}\nSubprocess output: {a}")
            return  # Stop execution if there's an error

        # Set expiration to 30 minutes
        today = DT.datetime.now()  # Current date and time
        later = today + DT.timedelta(minutes=30)  # 30 minutes expiration time
        b = [x.group() for x in re.finditer("vmess://(.*)", a)]

        z = base64.b64decode(b[0].replace("vmess://", "")).decode("ascii")
        z = json.loads(z)

        z1 = base64.b64decode(b[1].replace("vmess://", "")).decode("ascii")
        z1 = json.loads(z1)

        msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━**
               **TRIAL VMESS**
**━━━━━━━━━━━━━━━━━━━━━━**
**ISP :** `{isp}` 
**Server :** `{city}, {country}`
**Host Server :** `{DOMAIN}`
**Port TLS    :** `443`
**Port NTLS   :** `80`
**UUID    :** `{z["id"]}`
**NetWork     :** `(WS) or (gRPC)`
**Path        :** `/vmess`
**ServiceName :** `vmess-grpc`
**━━━━━━━━━━━━━━━━━━━━━━**
**VMESS URL TLS:**
```{b[0].strip("'").replace(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━━**
**VMESS URL HTTP:**
```{b[1].strip("'").replace(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━━**
**VMESS URL gRPC:** 
```{b[2].strip("'")}```
**━━━━━━━━━━━━━━━━━━━━━━**
**❞Expired in:** `{later.strftime('%Y-%m-%d %H:%M:%S')}`
**━━━━━━━━━━━━━━━━━━━━━━**
**by** 🤖@RiswanJabar
        """

        # Kirim notifikasi ke grup Telegram
        group_chat_id = "-1002357575458"
        notification_msg = f"""
        Akun Trial VMESS baru telah dibuat!

        **Username**: Trial{random_string}
        **Expired Day**: 30 menit
        **Login IP**: {ip}
        **Quota**: 2000 MB

        ISP: {isp}
        Lokasi: {city}, {country}

        Tanggal Dibuat: {today}
        Tanggal Expired: {later}
        """
        await bot.send_message(group_chat_id, notification_msg)  # Mengirim notifikasi ke grup

        await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await trial_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)


# Tambahkan kode lainnya sesuai dengan event-event lainnya yang ada...