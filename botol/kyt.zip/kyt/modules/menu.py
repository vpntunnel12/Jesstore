from datetime import datetime, timedelta
import subprocess
import locale

# Mengatur locale untuk mendapatkan nama hari dalam bahasa Indonesia
locale.setlocale(locale.LC_TIME, "id_ID.UTF-8")  # Pastikan ini tersedia di server

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    inline = [
        [Button.inline("SSH OVPN", "ssh")],
        [Button.inline("VMESS", "vmess"), Button.inline("VLESS", "vless")],
        [Button.inline("TROJAN", "trojan"), Button.inline("REGIS-IP", "shadowsocks")],
        [Button.inline("INFO VPS", "info"), Button.inline("SETTING", "setting")],
        [Button.inline("NOOBZVPNS", "noobzvpns"), Button.inline("BACK MENU", "start")]
    ]
    
    sender = await event.get_sender()
    val = valid(str(sender.id))
    
    if val == "false":
        try:
            await event.answer("", alert=True)
        except:
            await event.reply("")
    elif val == "true":
        try:
            # Gathering system information via subprocess commands
            ssh = subprocess.check_output(f'cat /etc/passwd | grep "home" | grep "false" | wc -l', shell=True).decode("ascii")
            vms = subprocess.check_output(f'cat /etc/vmess/.vmess.db | grep "###" | wc -l', shell=True).decode("ascii")
            vls = subprocess.check_output(f'cat /etc/vless/.vless.db | grep "###" | wc -l', shell=True).decode("ascii")
            trj = subprocess.check_output(f'cat /etc/trojan/.trojan.db | grep "###" | wc -l', shell=True).decode("ascii")
            namaos = subprocess.check_output(f"cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'", shell=True).decode("ascii")
            shadowsocks = subprocess.check_output(f'cat /etc/shadowsocks/.shadowsocks.db | grep "###" | wc -l', shell=True).decode("ascii")
            ipsaya = subprocess.check_output('curl -s ipv4.icanhazip.com', shell=True).decode("ascii")
            uptime = subprocess.check_output('uptime -p', shell=True).decode("ascii").strip()

            # Expiration date calculation
            vps_creation_date_str = "2024-11-01"
            vps_creation_date = datetime.strptime(vps_creation_date_str, "%Y-%m-%d")
            expiration_date = vps_creation_date + timedelta(days=30)
            expiration_date_str = expiration_date.strftime("%A, %d %B %Y")  # Format hari, tanggal bulan tahun

            msg = f"""
            **☉━━━━━━━━━━━━━━━━━━━━━━━☉**
                       **🤖 BOT MENU 🤖**
            **☉━━━━━━━━━━━━━━━━━━━━━━━☉**
            **💻Server Information**
            **🌐OS :** `{namaos.strip().replace('"','')}`
            **🌐HOST :** `{DOMAIN}`
            **🌐IP VPS :** `{ipsaya.strip()}`
            **🌐Uptime :** `{uptime}` 
            **🌐VPS Expiration :** `{expiration_date_str}`
            **☉━━━━━━━━━━━━━━━━━━━━━━━☉**
            **💻 Actions Available**
            **🔑 SSH :** `{ssh.strip()}` __account__
            **🌐 VMESS :** `{vms.strip()}` __account__
            **🔒 VLESS :** `{vls.strip()}` __account__
            **🛡️ TROJAN :** `{trj.strip()}` __account__
            **💻 SCRIPTS VPS :** `{shadowsocks.strip()}` __vps__
            **☉━━━━━━━━━━━━━━━━━━━━━━━☉**
            **🔄 Version bot** `5.1`
            **🤖 Bot by:** @R23_VPNSTORE
            **☉━━━━━━━━━━━━━━━━━━━━━━━☉**
            """
            x = await event.edit(msg, buttons=inline)
            if not x:
                await event.reply(msg, buttons=inline)
        except Exception as e:
            await event.reply(f"Error gathering system data: {str(e)}")