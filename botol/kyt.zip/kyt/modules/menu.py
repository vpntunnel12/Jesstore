from kyt import *
import subprocess

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    inline = [
        [Button.inline("SSH OVPN", "ssh")],
        [Button.inline("VMESS", "vmess"),
         Button.inline("VLESS", "vless")],
        [Button.inline("TROJAN", "trojan"),
         Button.inline("REGIS-IP", "shadowsocks")],
        [Button.inline("INFO VPS", "info"),
         Button.inline("SETTING", "setting")],
        [Button.inline("NOOBZVPNS", "noobzvpns"),
         Button.inline("BACK MENU", "start")]
    ]

    sender = await event.get_sender()
    val = valid(str(sender.id))
    if val == "false":
        try:
            await event.answer("", alert=True)
        except:
            await event.reply("")
    elif val == "true":
        try:
            # Get system information
            sh = 'cat /etc/passwd | grep "home" | grep "false" | wc -l'
            ssh = subprocess.check_output(sh, shell=True).decode("ascii")
            vm = 'cat /etc/vmess/.vmess.db | grep "###" | wc -l'
            vms = subprocess.check_output(vm, shell=True).decode("ascii")
            vl = 'cat /etc/vless/.vless.db | grep "###" | wc -l'
            vls = subprocess.check_output(vl, shell=True).decode("ascii")
            tr = 'cat /etc/trojan/.trojan.db | grep "###" | wc -l'
            trj = subprocess.check_output(tr, shell=True).decode("ascii")
            sdss = "cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
            namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
            shadowsocks = subprocess.check_output('cat /etc/shadowsocks/.shadowsocks.db | grep "###" | wc -l', shell=True).decode("ascii")
            ipvps = "curl -s ipv4.icanhazip.com"
            ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
            
            # Get total RAM
            ram = subprocess.check_output("free -h | grep Mem | awk '{print $2}'", shell=True).decode("ascii").strip()

            # Get VPS current time
            vps_time = subprocess.check_output("date '+%Y-%m-%d %H:%M:%S'", shell=True).decode("ascii").strip()

            # Get VPS uptime
            uptime = subprocess.check_output("uptime -p", shell=True).decode("ascii").strip()

            # Get VPS creation date from installer log (for Ubuntu/Debian)
            try:
                # Try to read from the installer log for creation date
                creation_date = subprocess.check_output("head -n 1 /var/log/installer/syslog | awk '{print $1, $2, $3}'", shell=True).decode("ascii").strip()
            except subprocess.CalledProcessError:
                creation_date = "Unknown"  # Fallback if installer log doesn't exist

            msg = f"""
    **☉━━━━━━━━━━━━━━━━━━━━━━━☉**
                        **🤖 BOT MENU 🤖**
    **☉━━━━━━━━━━━━━━━━━━━━━━━☉**
    **💻Server Information**
    **🌐Os :** `{namaos.strip().replace('"','')}`
    **🌐Host:** `{DOMAIN}`
    **🌐IP VPS :** `{ipsaya.strip()}`
    **🕒VPS Time :** `{vps_time}`
    **⏳ Uptime :** `{uptime}`  
    **💾 Total RAM :** `{ram}` 
    **📅 VPS Created On :** `{today_date}`
    **☉━━━━━━━━━━━━━━━━━━━━━━━☉**
    **💻 Actions Available**
    **🔑 SSH :** `{ssh.strip()}` __account__
    **🌐 VMESS :** `{vms.strip()}` __account__
    **🔒 VLESS :** `{vls.strip()}` __account__
    **🛡️ TROJAN :** `{trj.strip()}` __account__
    **💻 SCRIPTS VPS :** `{shadowsocks.strip()}` __vps__
    **☉━━━━━━━━━━━━━━━━━━━━━━━☉**
    **🔄 Version bot** `5.1`
    **🤖 Bot by:** @R23_VPNSTORE
    **☉━━━━━━━━━━━━━━━━━━━━━━━☉**
            """
            x = await event.edit(msg, buttons=inline)
            if not x:
                await event.reply(msg, buttons=inline)
        except subprocess.CalledProcessError as e:
            await event.reply("There was an error retrieving server data. Please try again later.")