import subprocess
from datetime import datetime

def get_server_info():
    try:
        # Example for gathering SSH account count
        ssh = subprocess.check_output('cat /etc/passwd | grep "home" | grep "false" | wc -l', shell=True).decode("ascii")
        # Repeat for other services (VMESS, VLESS, TROJAN, etc.)
        # For simplicity, we assume other commands are similarly wrapped
        return ssh, vm, vls, trj, shadowsocks, namaos, ipsaya
    except subprocess.CalledProcessError as e:
        print(f"Error executing command: {e}")
        return None

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    inline = [
        [Button.inline("SSH OVPN", "ssh")],
        [Button.inline("VMESS", "vmess"), Button.inline("VLESS", "vless")],
        [Button.inline("TROJAN", "trojan"), Button.inline("REGIS-IP", "shadowsocks")],
        [Button.inline("INFO VPS", "info"), Button.inline("SETTING", "setting")],
        [Button.inline("NOOBZVPNS", "noobzvpns"), Button.inline("BACK MENU", "start")]
    ]
    sender = await event.get_sender()
    val = valid(str(sender.id))
    
    if val == "false":
        await event.answer("", alert=True)
    elif val == "true":
        # Fetch server info and handle errors
        server_info = get_server_info()
        if server_info is None:
            await event.reply("There was an error retrieving server information.")
            return
        
        ssh, vm, vls, trj, shadowsocks, namaos, ipsaya = server_info
        
        # Get the current date and time
        now = datetime.now()
        current_time = now.strftime("%Y-%m-%d %H:%M:%S")

        msg = f"""
        **☉━━━━━━━━━━━━━━━━━━━━━━━☉**
                       **🤖 BOT MENU 🤖**
        **☉━━━━━━━━━━━━━━━━━━━━━━━☉**
        **💻Server Information**
        **🌐OS :** `{namaos.strip().replace('"', '')}`
        **🌐HOST :** `{DOMAIN}`
        **🌐IP VPS :** `{ipsaya.strip()}`
        **🌐Date/Time:** `{current_time}`
        **☉━━━━━━━━━━━━━━━━━━━━━━━☉**
        **💻 Actions Available**
        **🔑 SSH :** `{ssh.strip()}` __account__
        **🌐 VMESS :** `{vm.strip()}` __account__
        **🔒 VLESS :** `{vls.strip()}` __account__
        **🛡️ TROJAN :** `{trj.strip()}` __account__
        **💻 SCRIPTS VPS :** `{shadowsocks.strip()}` __vps__
        **☉━━━━━━━━━━━━━━━━━━━━━━━☉**
        **🔄 Vesion bot** `5.1`
        **🤖 Bot by:** @R23_VPNSTORE
        **☉━━━━━━━━━━━━━━━━━━━━━━━☉**
        """
        await event.edit(msg, buttons=inline)