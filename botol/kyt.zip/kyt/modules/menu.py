from kyt import *
import subprocess
import datetime

# Fungsi untuk menghitung countdown (hitungan mundur)
def countdown(expiration_date):
    current_time = datetime.datetime.now()
    time_left = expiration_date - current_time

    days_left = time_left.days
    hours_left, remainder = divmod(time_left.seconds, 3600)
    minutes_left, seconds_left = divmod(remainder, 60)

    return f"{days_left} hari, {hours_left} jam, {minutes_left} menit, {seconds_left} detik"

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    inline = [
        [Button.inline("🖥️𝗦𝘀𝗵 𝗪𝘀🖥️", "ssh")],
        [Button.inline("🖥️𝗩𝗺𝗲𝘀𝘀🖥️", "vmess")],
        [Button.inline("🖥️𝗥𝗲𝗴𝗶𝘀-𝗜𝗽🖥️", "shadowsocks")],
        [Button.inline("🖥️𝗜𝗻𝗳𝗼 𝗩𝗽𝘀🖥️", "info"),
         Button.inline("🖥️𝗦𝗲𝘁𝗶𝗻𝗴𝘀🖥️", "setting")],
        [Button.url("🖥️𝗗𝗮𝗳𝘁𝗮𝗿 𝗜𝗽🖥️", "https://github.com/scriswan/premiumsc/edit/main/register"),
         Button.inline("↪️𝗕𝗮𝗰𝗸 𝗠𝗲𝗻𝘂↩️", "start")]
    ]

    sender = await event.get_sender()
    val = valid(str(sender.id))
    if val == "false":
        try:
            await event.answer("", alert=True)
        except:
            await event.reply("")
    elif val == "true":
        # Mendapatkan informasi sistem
        sh = f'cat /etc/passwd | grep "home" | grep "false" | wc -l'
        ssh = subprocess.check_output(sh, shell=True).decode("ascii")
        vm = f'cat /etc/vmess/.vmess.db | grep "###" | wc -l'
        vms = subprocess.check_output(vm, shell=True).decode("ascii")
        sdss = f"cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
        namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
        shadowsocks = subprocess.check_output('cat /etc/shadowsocks/.shadowsocks.db | grep "###" | wc -l', shell=True).decode("ascii")
        ipvps = f"curl -s ipv4.icanhazip.com"
        ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
        
        # Mendapatkan lokasi VPS menggunakan ipinfo.io
        location = subprocess.check_output(f"curl -s http://ipinfo.io/{ipsaya.strip()}/json", shell=True).decode("ascii")
        location_info = json.loads(location)
        city = location_info.get('city', 'Unknown')
        region = location_info.get('region', 'Unknown')
        country = location_info.get('country', 'Unknown')

        # Mendapatkan informasi RAM
        ram = subprocess.check_output("free -h | grep Mem | awk '{print $2}'", shell=True).decode("ascii").strip()

        # Mendapatkan waktu saat ini di VPS
        vps_time = subprocess.check_output("date '+%Y-%m-%d %H:%M:%S'", shell=True).decode("ascii").strip()

        # Mendapatkan uptime VPS
        uptime = subprocess.check_output("uptime -p", shell=True).decode("ascii").strip()

        # Contoh tanggal kedaluwarsa (ganti dengan data kedaluwarsa pengguna)
        # Anda bisa mengganti dengan tanggal kedaluwarsa yang dinamis berdasarkan data pengguna
        expiration_date = datetime.datetime(2025, 2, 20, 12, 0, 0)  # Contoh: Kedaluwarsa 20 Februari 2025, 12:00 siang
        countdown_time = countdown(expiration_date)

        msg = f"""
        
**INFO SERVER VPS**
**━━━━━━━━━━━━━━━━━━━━━━━**
**LOKASI :** `{city} {country}`
**OS :** `{namaos.strip().replace('"','')}`
**DOMAIN :** `{DOMAIN}`
**IP VPS :** `{ipsaya.strip()}`
**VPS Time :** `{vps_time}`
**UPTIME :** `{uptime}` 
**TOTAL RAM :** `{ram}`
**━━━━━━━━━━━━━━━━━━━━━━━**
**AKUN YANG DIBUAT**
**SSH :** `{ssh.strip()}` 
**VMESS :** `{vms.strip()}` 
**SCRIPT VPS :** `{shadowsocks.strip()}`
**━━━━━━━━━━━━━━━━━━━━━━━**
**Expiry Sc:** `{countdown_time}`
**━━━━━━━━━━━━━━━━━━━━━━━**
**Version bot :** `3.1`
**Ownerku :** @RiswanJabar
**━━━━━━━━━━━━━━━━━━━━━━━**
    """
        x = await event.edit(msg, buttons=inline)
        if not x:
            await event.reply(msg, buttons=inline)