from datetime import datetime, timedelta
from kyt import *

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    inline = [
        [Button.inline("SSH OVPN", "ssh")],
        [Button.inline("VMESS", "vmess"), Button.inline("VLESS", "vless")],
        [Button.inline("TROJAN", "trojan"), Button.inline("REGIS-IP", "shadowsocks")],
        [Button.inline("INFO VPS", "info"), Button.inline("SETTING", "setting")],
        [Button.inline("NOOBZVPNS", "noobzvpns"), Button.inline("BACK MENU", "start")]
    ]
    
    sender = await event.get_sender()
    val = valid(str(sender.id))
    
    if val == "false":
        try:
            await event.answer("", alert=True)
        except:
            await event.reply("Access denied.")
    elif val == "true":
        try:
            # Gather data for VPS Information
            sh = f'cat /etc/passwd | grep "home" | grep "false" | wc -l'
            ssh = subprocess.check_output(sh, shell=True).decode("ascii")
            
            vm = f'cat /etc/vmess/.vmess.db | grep "###" | wc -l'
            vms = subprocess.check_output(vm, shell=True).decode("ascii")
            
            vl = f'cat /etc/vless/.vless.db | grep "###" | wc -l'
            vls = subprocess.check_output(vl, shell=True).decode("ascii")
            
            tr = f'cat /etc/trojan/.trojan.db | grep "###" | wc -l'
            trj = subprocess.check_output(tr, shell=True).decode("ascii")
            
            sdss = f"cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
            namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
            
            shadowsocks = subprocess.check_output('cat /etc/shadowsocks/.shadowsocks.db | grep "###" | wc -l', shell=True).decode("ascii")
            
            ipvps = f"curl -s ipv4.icanhazip.com"
            ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
            
            # Additional VPS Information
            cpu_info = subprocess.check_output("lscpu | grep 'Model name' | awk -F: '{print $2}'", shell=True).decode("ascii").strip()
            num_cores = subprocess.check_output("nproc", shell=True).decode("ascii").strip()
            memory_info = subprocess.check_output("free -h | awk 'NR==2{print $3 \" / \" $2}'", shell=True).decode("ascii").strip()
            disk_info = subprocess.check_output("df -h | grep '^/dev/' | awk '{ print $3 \" / \" $2 }'", shell=True).decode("ascii").strip()
            system_uptime = subprocess.check_output("uptime -p", shell=True).decode("ascii").strip()
            load_avg = subprocess.check_output("uptime | awk -F'load average: ' '{ print $2 }'", shell=True).decode("ascii").strip()

            # Set expiration date, e.g., 30 days from now
            current_date = datetime.now()
            expiration_date = current_date + timedelta(days=30)
            formatted_expiration_date = expiration_date.strftime('%Y-%m-%d %H:%M:%S')

            # Prepare message with new data including expiration date
            msg = f"""
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
                          **🤖 BOT MENU 🤖**
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
**💻Server Information**
**🌐OS :** `{namaos.strip().replace('"','')}`
**🌐HOST :** `{DOMAIN}`
**🌐IP VPS :** `{ipsaya.strip()}`
**💻CPU Model :** `{cpu_info}`
**💻CPU Cores :** `{num_cores} cores`
**💻Memory Usage :** `{memory_info}`
**💻Disk Usage :** `{disk_info}`
**💻Uptime :** `{system_uptime}`
**💻Load Average :** `{load_avg}`
**💻VPS Expiration Date :** `{formatted_expiration_date}`
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
**💻 Actions Available**
**🔑 SSH :** `{ssh.strip()}` __account__
**🌐 VMESS :** `{vms.strip()}` __account__
**🔒 VLESS :** `{vls.strip()}` __account__
**🛡️ TROJAN :** `{trj.strip()}` __account__
**💻 SCRIPTS VPS :** `{shadowsocks.strip()}` __vps__
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
**🔄 Version bot** `5.1`
**🤖 Bot by :**  @R23_VPNSTORE
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
   """
            
            x = await event.edit(msg, buttons=inline)
            if not x:
                await event.reply(msg, buttons=inline)
                
        except Exception as e:
            await event.reply(f"An error occurred: {str(e)}")