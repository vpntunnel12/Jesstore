from kyt import *

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    inline = [
        [Button.inline("SSH OVPN", "ssh")],
        [Button.inline("VMESS", "vmess"),
         Button.inline("VLESS", "vless")],
        [Button.inline("TROJAN", "trojan"),
         Button.inline("REGIS-IP", "shadowsocks")],
        [Button.inline("INFO VPS", "info"),
         Button.inline("SETTING", "setting")],
        [Button.inline("NOOBZVPNS", "noobzvpns"),
         Button.inline("BACK MENU", "start")]
    ]

    sender = await event.get_sender()
    val = valid(str(sender.id))
    
    if val == "false":
        try:
            await event.answer("", alert=True)
        except:
            await event.reply("")
    elif val == "true":
        # Mengambil data server
        sh = f' cat /etc/passwd | grep "home" | grep "false" | wc -l'
        ssh = subprocess.check_output(sh, shell=True).decode("ascii")
        vm = f' cat /etc/vmess/.vmess.db | grep "###" | wc -l'
        vms = subprocess.check_output(vm, shell=True).decode("ascii")
        vl = f' cat /etc/vless/.vless.db | grep "###" | wc -l'
        vls = subprocess.check_output(vl, shell=True).decode("ascii")
        tr = f' cat /etc/trojan/.trojan.db | grep "###" | wc -l'
        trj = subprocess.check_output(tr, shell=True).decode("ascii")
        sdss = f" cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
        namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
        shadowsocks = subprocess.check_output('cat /etc/shadowsocks/.shadowsocks.db | grep "###" | wc -l', shell=True).decode("ascii")
        ipvps = f" curl -s ipv4.icanhazip.com"
        ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
        
        # Membuat pesan utama dengan info server
        msg = f"""
        **☉━━━━━━━━━━━━━━━━━━━━━━━☉**
                       **🤖 BOT MENU 🤖**
        **☉━━━━━━━━━━━━━━━━━━━━━━━☉**
        **💻Informasi Server**
        **🌐OS :** `{namaos.strip().replace('"','')}`
        **🌐HOST :** `{DOMAIN}`
        **🌐IP VPS :** `{ipsaya.strip()}`
        **☉━━━━━━━━━━━━━━━━━━━━━━━☉**
        **💻 Aksi Tersedia**
        **🔑 SSH :** `{ssh.strip()}` __akun__
        **🌐 VMESS :** `{vms.strip()}` __akun__
        **🔒 VLESS :** `{vls.strip()}` __akun__
        **🛡️ TROJAN :** `{trj.strip()}` __akun__
        **💻 SCRIPTS VPS :** `{shadowsocks.strip()}` __vps__
        **☉━━━━━━━━━━━━━━━━━━━━━━━☉**
        **🔄 Versi bot** `5.1`
        **🤖 Bot by:** @R23_VPNSTORE
        **☉━━━━━━━━━━━━━━━━━━━━━━━☉**
        """
        
        # Mengirim notifikasi pembuatan payload/proxy
        payload_notification = f"🔔 **Konfigurasi payload dan proxy Anda telah berhasil dibuat!** 🔔\n\n"
        payload_notification += f"Berikut adalah detailnya:\n\n"
        payload_notification += f"SSH: `{ssh.strip()}`\n"
        payload_notification += f"VMESS: `{vms.strip()}`\n"
        payload_notification += f"VLESS: `{vls.strip()}`\n"
        payload_notification += f"TROJAN: `{trj.strip()}`\n"
        payload_notification += f"Shadowsocks: `{shadowsocks.strip()}`\n\n"
        payload_notification += "Sekarang Anda dapat menggunakan konfigurasi ini sesuai kebutuhan.\n"
        
        # Mengirim pesan notifikasi ke pengguna
        await event.reply(payload_notification)

        # Mengedit pesan awal dengan info server dan tombol
        x = await event.edit(msg, buttons=inline)
        if not x:
            await event.reply(msg, buttons=inline)