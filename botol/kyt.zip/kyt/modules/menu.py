import datetime

def get_vps_expiry():
    # Membaca tanggal kadaluarsa dari file
    with open('/etc/vps-expiry-date.txt', 'r') as file:
        expiry_date_str = file.read().strip()
    
    # Mengonversi string tanggal ke objek datetime
    expiry_date = datetime.datetime.strptime(expiry_date_str, "%Y-%m-%d")
    
    # Mendapatkan tanggal saat ini
    current_date = datetime.datetime.now()
    
    # Menghitung selisih hari
    remaining_days = (expiry_date - current_date).days
    
    return remaining_days

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    inline = [
        [Button.inline("SSH OVPN", "ssh")],
        [Button.inline("VMESS", "vmess"), Button.inline("VLESS", "vless")],
        [Button.inline("TROJAN", "trojan"), Button.inline("REGIS-IP", "shadowsocks")],
        [Button.inline("INFO VPS", "info"), Button.inline("SETTING", "setting")],
        [Button.inline("NOOBZVPNS", "noobzvpns"), Button.inline("BACK MENU", "start")]
    ]
    
    sender = await event.get_sender()
    val = valid(str(sender.id))
    
    if val == "false":
        try:
            await event.answer("", alert=True)
        except:
            await event.reply("")
    elif val == "true":
        # Mendapatkan informasi server lainnya seperti yang sudah dilakukan
        ssh = subprocess.check_output('cat /etc/passwd | grep "home" | grep "false" | wc -l', shell=True).decode("ascii")
        vms = subprocess.check_output('cat /etc/vmess/.vmess.db | grep "###" | wc -l', shell=True).decode("ascii")
        vls = subprocess.check_output('cat /etc/vless/.vless.db | grep "###" | wc -l', shell=True).decode("ascii")
        trj = subprocess.check_output('cat /etc/trojan/.trojan.db | grep "###" | wc -l', shell=True).decode("ascii")
        shadowsocks = subprocess.check_output('cat /etc/shadowsocks/.shadowsocks.db | grep "###" | wc -l', shell=True).decode("ascii")
        
        # Mendapatkan informasi OS dan IP VPS
        namaos = subprocess.check_output('cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed "s/=//g" | sed "s/PRETTY_NAME//g"', shell=True).decode("ascii")
        ipsaya = subprocess.check_output('curl -s ipv4.icanhazip.com', shell=True).decode("ascii")
        
        # Menghitung masa kadaluarsa VPS
        remaining_days = get_vps_expiry()

        msg = f"""
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
                       **🤖 BOT MENU 🤖**
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
**💻Server Information**
**🌐OS :** `{namaos.strip().replace('"','')}`
**🌐HOST :** `{DOMAIN}`
**🌐IP VPS :** `{ipsaya.strip()}`
**🌐VPS Expires in:** `{remaining_days} days`
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
**💻 Actions Available**
**🔑 SSH :** `{ssh.strip()}` __account__
**🌐 VMESS :** `{vms.strip()}` __account__
**🔒 VLESS :** `{vls.strip()}` __account__
**🛡️ TROJAN :** `{trj.strip()}` __account__
**💻 SCRIPTS VPS :** `{shadowsocks.strip()}` __vps__
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
**🔄 Version bot** `5.1`
**🤖 Bot by:** @R23_VPNSTORE
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
"""
        
        x = await event.edit(msg, buttons=inline)
        if not x:
            await event.reply(msg, buttons=inline)