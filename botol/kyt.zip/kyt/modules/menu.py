from kyt import *
import subprocess
from datetime import datetime

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    inline = [
        [Button.inline("SSH OVPN", "ssh")],
        [Button.inline("VMESS", "vmess"),
         Button.inline("VLESS", "vless")],
        [Button.inline("TROJAN", "trojan"),
         Button.inline("REGIS-IP", "shadowsocks")],
        [Button.inline("INFO VPS", "info"),
         Button.inline("SETTING", "setting")],
        [Button.inline("NOOBZVPNS", "noobzvpns"),
         Button.inline("BACK MENU", "start")]
    ]

    sender = await event.get_sender()
    val = valid(str(sender.id))
    if val == "false":
        try:
            await event.answer("", alert=True)
        except:
            await event.reply("")
    elif val == "true":
        # Get system information
        sh = f'cat /etc/passwd | grep "home" | grep "false" | wc -l'
        ssh = subprocess.check_output(sh, shell=True).decode("ascii")
        vm = f'cat /etc/vmess/.vmess.db | grep "###" | wc -l'
        vms = subprocess.check_output(vm, shell=True).decode("ascii")
        vl = f'cat /etc/vless/.vless.db | grep "###" | wc -l'
        vls = subprocess.check_output(vl, shell=True).decode("ascii")
        tr = f'cat /etc/trojan/.trojan.db | grep "###" | wc -l'
        trj = subprocess.check_output(tr, shell=True).decode("ascii")
        sdss = f"cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
        namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
        shadowsocks = subprocess.check_output('cat /etc/shadowsocks/.shadowsocks.db | grep "###" | wc -l', shell=True).decode("ascii")
        ipvps = f"curl -s ipv4.icanhazip.com"
        ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
        
        # Get total RAM
        ram = subprocess.check_output("free -h | grep Mem | awk '{print $2}'", shell=True).decode("ascii").strip()

        # Get VPS current time
        vps_time = subprocess.check_output("date '+%Y-%m-%d %H:%M:%S'", shell=True).decode("ascii").strip()

        # Get VPS uptime
        uptime = subprocess.check_output("uptime -p", shell=True).decode("ascii").strip()

        # Get expiry date for VPS script (replace with your file or database)
        try:
            expiry_file = '/etc/shadowsocks/expiry_date.txt'  # Path to the expiry date file
            with open(expiry_file, 'r') as f:
                expiry_date_str = f.read().strip()  # Assuming the file contains a date in the format YYYY-MM-DD
            expiry_date = datetime.strptime(expiry_date_str, '%Y-%m-%d')
            
            # Calculate remaining days
            current_date = datetime.now()
            remaining_days = (expiry_date - current_date).days
        except FileNotFoundError:
            remaining_days = "N/A"  # If the file doesn't exist or there's no expiry info

        msg = f"""
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
                    **🤖 BOT MENU 🤖**
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
**💻Server Information**
**🌐Os :** `{namaos.strip().replace('"','')}`
**🌐Host:** `{DOMAIN}`
**🌐IP VPS :** `{ipsaya.strip()}`
**🕒VPS Time :** `{vps_time}`
**⏳ Uptime :** `{uptime}`  
**💾 Total RAM :** `{ram}` 
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
**💻 Actions Available**
**🔑 SSH :** `{ssh.strip()}` __account__
**🌐 VMESS :** `{vms.strip()}` __account__
**🔒 VLESS :** `{vls.strip()}` __account__
**🛡️ TROJAN :** `{trj.strip()}` __account__
**💻 SCRIPTS VPS :** `{shadowsocks.strip()}` __vps__
**🗓️ Expiry Date :** `{remaining_days} days remaining`
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
**🔄 Version bot** `5.1`
**🤖 Bot by:** @R23_VPNSTORE
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
        """
        x = await event.edit(msg, buttons=inline)
        if not x:
            await event.reply(msg, buttons=inline)