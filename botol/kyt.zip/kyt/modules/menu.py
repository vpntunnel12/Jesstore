from kyt import *
import subprocess
from telethon import events, Button
import datetime

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    # Inline keyboard buttons
    inline = [
        [Button.inline("SSH OVPN", b"ssh")],
        [Button.inline("VMESS", b"vmess"), Button.inline("VLESS", b"vless")],
        [Button.inline("TROJAN", b"trojan"), Button.inline("REGIS-IP", b"shadowsocks")],
        [Button.inline("INFO VPS", b"info"), Button.inline("SETTING", b"setting")],
        [Button.inline("NOOBZVPNS", b"noobzvpns"), Button.inline("↪️Back Menu↩️", b"start")]
    ]

    # Access validation
    sender = await event.get_sender()
    val = valid(str(sender.id))
    if val == "false":
        try:
            await event.answer("Akses Ditolak", alert=True)
        except:
            await event.reply("Akses Ditolak")
        return

    # Shell commands with error handling
    try:
        ssh = subprocess.check_output("cat /etc/passwd | grep 'home' | grep 'false' | wc -l", shell=True).decode("ascii").strip()
        vms = subprocess.check_output("cat /etc/vmess/.vmess.db | grep '###' | wc -l", shell=True).decode("ascii").strip()
        vls = subprocess.check_output("cat /etc/vless/.vless.db | grep '###' | wc -l", shell=True).decode("ascii").strip()
        trj = subprocess.check_output("cat /etc/trojan/.trojan.db | grep '###' | wc -l", shell=True).decode("ascii").strip()
        shadowsocks = subprocess.check_output("cat /etc/shadowsocks/.shadowsocks.db | grep '###' | wc -l", shell=True).decode("ascii").strip()
        namaos = subprocess.check_output("grep -w PRETTY_NAME /etc/os-release | head -n1 | cut -d= -f2", shell=True).decode("ascii").strip().replace('"', '')
        ipsaya = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True).decode("ascii").strip()

        # Get VPS expiry date
        try:
            expiry = subprocess.check_output("cat /etc/vps-expiry", shell=True).decode("ascii").strip()
            expiry_date = datetime.datetime.strptime(expiry, "%Y-%m-%d").strftime("%d %B %Y")
        except Exception:
            expiry_date = "Tidak diketahui"
    except subprocess.CalledProcessError as e:
        await event.reply(f"Error fetching data: {e}")
        return

    # Message content
    msg = f"""
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
         **🧿MENU BOT VPNSTORE🧿**
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
**»🌀OS :** `{namaos.strip}`
**»👤HOST :** `{DOMAIN.strip}`
**»🌀IP VPS :** `{ipsaya.strip}`
**»📅Masa Aktif VPS :** `{expiry_date.strip}`
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
**»🗒️Total akun premium dibuat**
**»📚SSH :** `{ssh.strip}` __account__
**»📒VMESS :** `{vms.strip}` __account__
**»📓VLESS :** `{vls.strip}` __account__
**»📗TROJAN :** `{trj.strip}` __account__
**»📗SCRIPT :** `{shadowsocks.strip}` __ip-vps__
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
**»↪️Bot by :** @R23_VPNSTORE
"""

    # Send message with inline buttons
    try:
        await event.edit(msg, buttons=inline)
    except:
        await event.reply(msg, buttons=inline)