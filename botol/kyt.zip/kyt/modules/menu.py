from kyt import *

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
	inline = [
[Button.inline(" SSH OVPN ","ssh")],
[Button.inline(" VMESS ","vmess"),
Button.inline(" VLESS ","vless")],
[Button.inline(" TROJAN ","trojan"),
Button.inline(" REGIS-IP","shadowsocks")],
[Button.inline(" INFO VPS ","info"),
Button.inline(" SETTING ","setting")],
[Button.inline(" NOOBZVPNS ","noobzvpns"),
Button.inline(" ↪️Back Menu↩️ ","start")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Akses Ditolak", alert=True)
		except:
			await event.reply("Akses Ditolak")
	elif val == "true":
		sh = f' cat /etc/passwd | grep "home" | grep "false" | wc -l'
		
		import datetime
import requests

def count_lines(file_path, keyword="###"):
    try:
        with open(file_path, "r") as file:
            return sum(1 for line in file if keyword in line)
    except FileNotFoundError:
        return 0

def get_os_name():
    try:
        with open("/etc/os-release", "r") as file:
            for line in file:
                if "PRETTY_NAME" in line:
                    return line.split("=")[1].strip().replace('"', "")
    except FileNotFoundError:
        return "Unknown OS"

def get_public_ip():
    try:
        return requests.get("https://ipv4.icanhazip.com").text.strip()
    except requests.RequestException:
        return "Unknown IP"

def get_vps_expiry(file_path="/etc/vps-expire.txt"):
    try:
        # Membaca tanggal expire dari file
        with open(file_path, "r") as file:
            exp_date_str = file.read().strip()
            exp_date = datetime.datetime.strptime(exp_date_str, "%Y-%m-%d").date()
            
        # Tanggal hari ini
        today = datetime.date.today()
        
        # Hitung sisa hari
        remaining_days = (exp_date - today).days
        
        # Cek status VPS
        if remaining_days < 0:
            return "VPS telah kedaluwarsa"
        else:
            return f"{remaining_days} hari lagi"
    except FileNotFoundError:
        return "Tanggal expire tidak ditemukan"
    except ValueError:
        return "Format tanggal tidak valid"

# Menghitung akun
ssh = count_lines("/etc/passwd", "home")
vms = count_lines("/etc/vmess/.vmess.db", "###")
vls = count_lines("/etc/vless/.vless.db", "###")
trj = count_lines("/etc/trojan/.trojan.db", "###")
shadowsocks = count_lines("/etc/shadowsocks/.shadowsocks.db", "###")

# Informasi lainnya
namaos = get_os_name()
ipsaya = get_public_ip()
vps_expiry_status = get_vps_expiry()

msg = f"""
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
         **🧿MENU BOT VPNSTORE🧿**
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
**»🌀OS :** `{namaos}`
**»👤HOST :** `{DOMAIN}`
**»🌀IP VPS :** `{ipsaya}`
**»📆Masa Aktif VPS :** `{vps_expiry_status}`
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
**»🗒️Total akun premium dibuat**
**»📚SSH :** `{ssh}` __account__
**»📒VMESS :** `{vms}` __account__
**»📓VLESS :** `{vls}` __account__
**»📗TROJAN :** `{trj}` __account__
**»📗SCRIPT :** `{shadowsocks}` __ip-vps__
**☉━━━━━━━━━━━━━━━━━━━━━━━☉**
**»↪️Bot by :** @R23_VPNSTORE
"""