from cybervpn import *
from telethon import events, Button
import requests


@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
	inline = [
[Button.inline("⚡PANEL SSH WS⚡ ", "ssh")],
        [Button.inline("⚡PANEL VMESS ⚡", "vmess")],
        [Button.inline("⚡PANEL VLESS ⚡", "vless")],
        [Button.inline("⚡PANEL TROJAN ⚡", "trojan")],
        [Button.inline("⚡INFO VPS⚡", "info"),
       Button.inline("💰DONASI💰 ", "start")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Akses Ditolak", alert=True)
		except:
			await event.reply("Akses Ditolak")
	elif val == "true":
		sh = f' cat /etc/passwd | grep "home" | grep "false" | wc -l'
		ssh = subprocess.check_output(sh, shell=True).decode("ascii")
		vm = f' cat /etc/vmess/.vmess.db | grep "###" | wc -l'
		vms = subprocess.check_output(vm, shell=True).decode("ascii")
		vl = f' cat /etc/vless/.vless.db | grep "###" | wc -l'
		vls = subprocess.check_output(vl, shell=True).decode("ascii")
		tr = f' cat /etc/trojan/.trojan.db | grep "###" | wc -l'
		trj = subprocess.check_output(tr, shell=True).decode("ascii")
		sdss = f" cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
		namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
		shadowsocks = subprocess.check_output('cat /etc/shadowsocks/.shadowsocks.db | grep "###" | wc -l', shell=True).decode("ascii")
		ipvps = f" curl -s ipv4.icanhazip.com"
		ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")

		msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━━━━
█▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█
█░░╦─╦╔╗╦─╔╗╔╗╔╦╗╔╗░░█
█░░║║║╠─║─║─║║║║║╠─░░█
█░░╚╩╝╚╝╚╝╚╝╚╝╩─╩╚╝░░█
█▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█
Owner : @R23_VPNSTORE
━━━━━━━━━━━━━━━━━━━━━━━━━━
Os : `{namaos.strip().replace('"','')}`
Host : `{DOMAIN}`
Ipvps : `{ipsaya.strip()}`
━━━━━━━━━━━━━━━━━━━━━━━━━━
Total account Bansos
SSH: `{ssh.strip()}` __account__
VMESS: `{vms.strip()}` __account__
VLESS: `{vls.strip()}` __account__
TROJAN: `{trj.strip()}` __account__
━━━━━━━━━━━━━━━━━━━━━━━━━━
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)




url = "https://raw.githubusercontent.com/scriswan/fodder/main/statusku"

response = requests.get(url)


if response.status_code == 200:
    print(response.text)
else:
    print("Gagal mendapatkan konten dari URL")

@bot.on(events.NewMessage(pattern=r"(?:.menu|/start|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def start_menu(event):
    user_id = str(event.sender_id)

    if check_user_registration(user_id):
        try:
            saldo_aji, level = get_saldo_and_level_from_db(user_id)

            if level == "user":
                member_inline = [
                    
                 [Button.inline("⚡SSH⚡", "ssh")],
                    [Button.inline("⚡VMESS⚡", "vmess-member"),
                    
                     
                      Button.inline("💳TOPUP💳", f"topup")],
                      
                   
                ]

                member_msg = f"""
**┌─────────────────────•**
**│█▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█**
**│█░░╦─╦╔╗╦─╔╗╔╗╔╦╗╔╗░░█**
**│█░░║║║╠─║─║─║║║║║╠─░░█**
**│█░░╚╩╝╚╝╚╝╚╝╚╝╩─╩╚╝░░█**
**│█▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█**
**└─────────────────────•**
**┌─────────────────────•**
**│Chat ID       :** `{user_id}`
**│Members.  :** `{get_user_count()}`
**│Balance Rp:** `{saldo_aji}`
**└─────────────────────•**
**┌─────────────────────•**
**│VPN PREMIUM RZ STORE**
**│RP: 5000 LOGIN 2 HP STB**
**└─────────────────────•**
**┌─────────────────────•**
**│JIKA TOPUP TIDAK MASUK**
**│TINGGAL CHAT ADMIN AJA**
**└─────────────────────•**
**┌─────────────────────•**
**│Owner kami @R23_VPNSTORE**
**└─────────────────────•**
"""
                x = await event.edit(member_msg, buttons=member_inline)
                if not x:
                    await event.reply(member_msg, buttons=member_inline)


            elif level == "admin":
                admin_inline = [
                   [Button.inline("AKUN SSH", "ssh")],
                    [Button.inline("AKUN VMESS", "vmess"),
                     Button.inline("AKUN VLESS", "vless")],
                    [Button.inline("AKUN TROJAN", "trojan"),
                     Button.inline("ADD MEMBER", "registrasi-member")],
                     [Button.inline("HAPUS MEMBER", "delete-member")],
                     [Button.inline("DAFTAR MEMBER", "show-user")],
                    [Button.inline("ADD SALDO MEMBER", "addsaldo")],
                    [Button.inline("CEK INFO VPS", "info"),
                     Button.inline("PENGATURAN", "setting")],
                    [Button.url("TELEGRAM", "https://t.me/R23_VPNSTORE"),
                     Button.url("WHATSAPP", "https://wa.me/6285888801241")]
                ]

                admin_msg = f"""
**┌─────────────────────•**
**│█▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█**
**│█░░╦─╦╔╗╦─╔╗╔╗╔╦╗╔╗░░█**
**│█░░║║║╠─║─║─║║║║║╠─░░█**
**│█░░╚╩╝╚╝╚╝╚╝╚╝╩─╩╚╝░░█**
**│█▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█**
**└─────────────────────•**
**┌─────────────────────•**
**│Host:** `{DOMAIN}`
**│Chat ID       :** `{user_id}`
**│Members.  :** `{get_user_count()}`
**│Balance Rp:** `{saldo_aji}`
**└─────────────────────•**
**┌─────────────────────•**
**│VPN PREMIUM RZ STORE**
**│RP: 5000 LOGIN 2 HP STB**
**└─────────────────────•**
**┌─────────────────────•**
**│JIKA TOPUP TIDAK MASUK**
**│TINGGAL CHAT ADMIN AJA**
**└─────────────────────•**
**┌─────────────────────•**
**│Owner kami @R23_VPNSTORE**
**└─────────────────────•**
"""
                x = await event.edit(admin_msg, buttons=admin_inline)
                if not x:
                    await event.reply(admin_msg, buttons=admin_inline)

        except Exception as e:
            print(f"Error: {e}")

    else:
        await event.reply(
            f'**Siilahkan Registrasi Terlebih Dahulu**',
            buttons=[[(Button.inline("Registrasi", "registrasi"))]]
        )

