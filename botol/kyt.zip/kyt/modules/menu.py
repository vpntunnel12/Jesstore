from kyt import *
import subprocess

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    inline = [
    [Button.inline("SSH-WS", "ssh"),
     Button.inline("VMESS", "vmess")],
    [Button.inline("REGIS IP", "shadowsocks"),
     Button.inline("INFO VPS", "info")],
    [Button.inline("SETING", "setting")],
    [Button.url("DAFTAR IP", "https://github.com/scriswan/premiumsc/edit/main/register"),
     Button.inline("MAIN MENU", "start")]
]

    sender = await event.get_sender()
    val = valid(str(sender.id))
    if val == "false":
        try:
            await event.answer("", alert=True)
        except:
            await event.reply("")
    elif val == "true":
        # Get system information
        sh = f'cat /etc/passwd | grep "home" | grep "false" | wc -l'
        ssh = subprocess.check_output(sh, shell=True).decode("ascii")
        vm = f'cat /etc/vmess/.vmess.db | grep "###" | wc -l'
        vms = subprocess.check_output(vm, shell=True).decode("ascii")
        sdss = f"cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
        namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
        shadowsocks = subprocess.check_output('cat /etc/shadowsocks/.shadowsocks.db | grep "###" | wc -l', shell=True).decode("ascii")
        ipvps = f"curl -s ipv4.icanhazip.com"
        ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
        
        # Get VPS Location using ipinfo.io
        location = subprocess.check_output(f"curl -s http://ipinfo.io/{ipsaya.strip()}/json", shell=True).decode("ascii")
        location_info = json.loads(location)
        city = location_info.get('city', 'Unknown')
        region = location_info.get('region', 'Unknown')
        country = location_info.get('country', 'Unknown')

        # Get total RAM
        ram = subprocess.check_output("free -h | grep Mem | awk '{print $2}'", shell=True).decode("ascii").strip()

        # Get VPS current time
        vps_time = subprocess.check_output("date '+%Y-%m-%d %H:%M:%S'", shell=True).decode("ascii").strip()

        # Get VPS uptime
        uptime = subprocess.check_output("uptime -p", shell=True).decode("ascii").strip()

        msg = f"""
        
**INFO SERVER VPS**
**━━━━━━━━━━━━━━━━━━━━━━━**
**LOKASI :** `{city} {country}`
**OS :** `{namaos.strip().replace('"','')}`
**DOMAIN :** `{DOMAIN}`
**IP VPS :** `{ipsaya.strip()}`
**VPS Time :** `{vps_time}`
**UPTIME :** `{uptime}` 
**TOTAL RAM :** `{ram}`
**━━━━━━━━━━━━━━━━━━━━━━━**
**AKUN YANG DIBUAT**
**SSH :** `{ssh.strip()}` 
**VMESS :** `{vms.strip()}` 
**SCRIPT VPS :** `{shadowsocks.strip()}`
**━━━━━━━━━━━━━━━━━━━━━━━**
**Version bot :** `3.1`
**Ownerku :** @RiswanJabar
**━━━━━━━━━━━━━━━━━━━━━━━**
    """
        x = await event.edit(msg, buttons=inline)
        if not x:
            await event.reply(msg, buttons=inline)