from kyt import *
import subprocess
import datetime as DT
import sys
from telethon.sync import TelegramClient
import sqlite3
import random

@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
    user_id = str(event.sender_id)
    async def trial_ssh_(event):
        user = "Trial-" + str(random.randint(100, 1000))
        pw = "1"
        exp = "1"
        ip = "1"
        
    	# Fetch ISP and Location information
        isp_data = requests.get(f"http://ip-api.com/json/?fields=isp,country,city").json()
        isp = isp_data.get("isp", "Unknown ISP")
        country = isp_data.get("country", "Unknown Country")
        city = isp_data.get("city", "Unknown City")

        cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
        try:
            subprocess.check_output(cmd, shell=True)
        except:
            await event.respond("**Successful Create Account**")
        else:
            today = DT.date.today()
            later = today + DT.timedelta(days=int(exp))
            msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━**
               **TRIAL SSH WS** 
**━━━━━━━━━━━━━━━━━━━━━━**
**ISP :** `{isp}` 
**Server :** `{city}, {country}`
**Domain:** `{DOMAIN}`
**Usernem:** `{user.strip()}`
**Passwd:** `{pw.strip()}`
**━━━━━━━━━━━━━━━━━━━━━━**
**FORMAT HTTP COSTUM:**
`{DOMAIN}:80@{user.strip()}:{pw.strip()}`
**━━━━━━━━━━━━━━━━━━━━━━**
**FORMAT UDP COSTUM**
`{DOMAIN}:1-65535@{user.strip()}:{pw.strip()}`
**━━━━━━━━━━━━━━━━━━━━━━**
**Payload:**
```GET /cdn-cgi/trace HTTP/1.1[crlf]Host: Bug_Kalian[crlf][crlf]GET-RAY / HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]```
**━━━━━━━━━━━━━━━━━━━━━━**
**EXPIRED ON :** `{𝚕𝚊𝚝𝚎𝚛}`
**━━━━━━━━━━━━━━━━━━━━━━**
**by** 🤖@RiswanJabar
"""
            inline = [
                [Button.url("Admin", "t.me/RiswanJabar"),
                 Button.url("whatsapp", "wa.me/6285888801241")]
            ]
            await event.respond(msg, buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await trial_ssh_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)