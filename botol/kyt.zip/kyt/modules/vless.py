from kyt import *

@bot.on(events.CallbackQuery(data=b'create-vless'))
async def create_vless(event):
    async def create_vless_(event):
        # Simplified to one conversation for all user inputs
        async with bot.conversation(chat) as conv:
            await event.respond('**Username:**')
            user_message = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = user_message.raw_text
            
            await event.respond('**masa aktip akun :**')
            exp_message = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = exp_message.raw_text
            
            await event.respond('**Limit Ip:**')
            ip_message = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            ip = ip_message.raw_text
            
            await event.respond('**Limit Quota:**')
            quota_message = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            quota = quota_message.raw_text

            await event.respond('**Server :**')
            location_message = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            location = location_message.raw_text
            
            # Asking for the configuration type
            await event.respond('**Config apa :**')
            config_message = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            config_type = config_message.raw_text
            
            # Asking for the price
            await event.respond('**harga akun :**')
            price_message = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            price = price_message.raw_text

        await event.edit("`Wait.. Setting up an Account`")
        
        cmd = f'printf "%s\n" "{user}" "{exp}" "{quota}" "{ip}" | addvless-bot'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            await event.respond(f"Error occurred: {e}")
            return
        
        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))
        
        # Extract URLs and UUID from the output
        urls = [x.group() for x in re.finditer("vless://(.*)", a)]
        if len(urls) < 3:
            await event.respond("Error: Expected multiple VLESS URLs, but got fewer.")
            return
        
        uuid = re.search("vless://(.*?)@", urls[0]).group(1)

        msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━**
               **❞CREATE VLESS❞**
**━━━━━━━━━━━━━━━━━━━━━━**
**❞Remarks :** `{user}`
**❞Port TLS    :** `443`
**❞Port NTLS   :** `80`
**❞Port NTLS   :** `80, 8080, 8081-9999`
**❞UUID    :** `{uuid}`
**❞NetWork     :** `(WS) or (gRPC)` 
**❞Path        :** `/vless`
**❞ServiceName :** `vless-grpc`
**━━━━━━━━━━━━━━━━━━━━━━**
**❞VLESS URL TLS❞:**
```{urls[0]}```
**━━━━━━━━━━━━━━━━━━━━━━**
**❞VLESS URL HTTP❞:**
```{urls[1].replace(" ", "")}```
**━━━━━━━━━━━━━━━━━━━━━━**
**❞VLESS URL gRPC❞:** 
```{urls[2].replace(" ", "")}```
**━━━━━━━━━━━━━━━━━━━━━━**
**EXP `{later}`
**━━━━━━━━━━━━━━━━━━━━━━**
`💰{user}-{config_type}-{later}💰`
**━━━━━━━━━━━━━━━━━━━━━━**
**❞Testimonial:**
```◇━━━━━━━━━━━━━━━━━◇
💰PEMBELIAN BERHASIL💰
◇━━━━━━━━━━━━━━━━━◇
-» PRODUk : VLESS
-» SERVER : {location} 
-» CONFIG : {config_type}  
-» USER   : {user}
-» LOGIN  : 2 IP
-» HARGA  : {price} 
-» EXP    : {later}
◇━━━━━━━━━━━━━━━━━◇```
**by :** @R23_VPNSTORE
**━━━━━━━━━━━━━━━━━━━━━━**
"""
        await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await create_vless_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'cek-vless'))
async def cek_vless(event):
    async def cek_vless_(event):
        cmd = 'cek-vless'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"""
**◇━━━━━━━━━━━━━━━━━━◇**
   ** ⟨🔸Cek Vless User Login🔸⟩**
**◇━━━━━━━━━━━━━━━━━━◇**
{z}

**Shows Logged In Users Vless**
""", buttons=[[Button.inline("‹ 𝙼𝚊𝚒𝚗 𝙼𝚎𝚗𝚞 ›", "menu")]])

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await cek_vless_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

		
@bot.on(events.CallbackQuery(data=b'renew-vless'))
async def ren_vless(event):
    async def ren_vless_(event):
        async with bot.conversation(chat) as user:
            await event.respond('**Username:**')
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text

        async with bot.conversation(chat) as exp:
            await event.respond('**Expired:**')
            exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = (await exp).raw_text


        async with bot.conversation(chat) as ip:
            await event.respond('**Limit Ip:**')
            ip = ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            ip = (await ip).raw_text


        async with bot.conversation(chat) as Quota:
            await event.respond('**Limit Quota:**')
            Quota = Quota.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            Quota = (await Quota).raw_text

        
        await event.edit("Processing..")
        await event.edit("Processing...")
        await event.edit("Processing....")
        time.sleep(1)
        await event.edit("`Processing Create Premium Account`")
        time.sleep(1)
        await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 100%\n█████████████████████████ `")
        
        time.sleep(1)
        await event.edit("`Wait.. Setting up an Account`")
        cmd = f'printf "%s\n" "{user}" "{exp}" "{Quota}" "{ip}" | bot-renew-vle'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**Successfully Renew User**")
        else:
            msg = f"""
**{user} {exp} Days, limit ip {ip}, limit Quota {Quota} GB**
"""
            await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await ren_vless_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)


# CEK member VLESS
@bot.on(events.CallbackQuery(data=b'cek-membervl'))
async def cek_vless(event):
    async def cek_vless_(event):
        cmd = 'bash cek-mvs'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"""

{z}

**Shows Users from databases**
""", buttons=[[Button.inline("‹ main menu ›", "menu")]])

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await cek_vless_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)



@bot.on(events.CallbackQuery(data=b'delete-vless'))
async def delete_vless(event):
    async def delete_vless_(event):
        async with bot.conversation(chat) as user:
            await event.respond('**Username:**')
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        await event.edit("Processing.")
        await event.edit("Processing..")
        await event.edit("Processing...")
        await event.edit("Processing....")
        time.sleep(1)
        await event.edit("`Processing Crate Premium Account`")
        time.sleep(1)
        await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
        time.sleep(0)
        await event.edit("`Processing... 100%\n█████████████████████████ `")
        time.sleep(1)
        await event.edit("`Wait.. Setting up an Account`")
        cmd = f'printf "%s\n" "{user}" | bot-del-vle'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**Successfully Delete User**")
        else:
            msg = f"""**Successfully Deleted**"""
            await event.respond(msg)


    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await delete_vless_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)



@bot.on(events.CallbackQuery(data=b'trial-vless'))
async def trial_vless(event):
    async def trial_vless_(event):
        cmd = f'printf "%s\n" "Trial`</dev/urandom tr -dc X-Z0-9 | head -c4`" "1" "2000" "2000" | bot-trialvless'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**User Already Exist**")
        else:
            today = DT.date.today()
            later = today + DT.timedelta(days=int(1))
            x = [x.group() for x in re.finditer("vless://(.*)", a)]
            print(x)
            remarks = re.search("#(.*)", x[0]).group(1)
            # domain = re.search("@(.*?):", x[0]).group(1)
            uuid = re.search("vless://(.*?)@", x[0]).group(1)
            # path = re.search("path=(.*)&", x[0]).group(1)
            msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━**
               **❞TRIAL VLESS❞**
**━━━━━━━━━━━━━━━━━━━━━━**
**❞Host Server :** `{DOMAIN}`
**❞Port TLS    :** `443`
**❞Port NTLS   :** `80`
**❞UUID    :** `{uuid}`
**❞NetWork     :** `(WS) or (gRPC)`
**❞Path        :** `/vless`
**❞ServiceName :** `vless-grpc`
**━━━━━━━━━━━━━━━━━━━━━━**
**❞VLESS URL TLS:**
```{x[0]}```
**━━━━━━━━━━━━━━━━━━━━━━**
**❞VLESS URL HTTP❞:**
```{x[1].𝚛𝚎𝚙𝚕𝚊𝚌𝚎(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━━**
**❞VLESS URL gRPC❞:** 
```{x[2].𝚛𝚎𝚙𝚕𝚊𝚌𝚎(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━━**
**❞Notes pelangan**
**❞simpan detail pembelian akun**
**❞sebagai garansi. kirimkan detail** 
**❞pembelian akun ke admin untuk** 
**❞pengecekan ketika terjadi masalah**
**❞pada config**
**❞Exp jatuh pada:** `{today}`
**━━━━━━━━━━━━━━━━━━━━━━**
**» ** 🤖@R23_VPNSTORE
"""
            await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await trial_vless_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)


@bot.on(events.CallbackQuery(data=b'vless'))
async def vless(event):
    async def vless_(event):
        inline = [
            [Button.inline("Trial vless", "trial-vless"),
             Button.inline("Create vless", "create-vless")],
            [Button.inline("Cek login vless", "cek-vless"),
             Button.inline("Delete vless", "delete-vless")],
            [Button.inline("Renew vless", "renew-vless")],
            [Button.inline("Cek user vless", "cek-membervl"),
             Button.inline("‹ main menu ›", "menu")]
        ]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
     **◇⟨🔸VLESS SERVICE🔸⟩◇**
             **Admin Manager**
**◇━━━━━━━━━━━━━━━━━◇**
**  Service:** `VLESS`
**  Hostname/IP:** `{DOMAIN}`
**  ISP:** `{z["isp"]}`
**  Country:** `{z["country"]}`
**» ** 🤖@R23_VPNSTORE
**◇━━━━━━━━━━━━━━━━━◇**
"""
        await event.edit(msg, buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await vless_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

