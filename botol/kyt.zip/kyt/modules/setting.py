from kyt import *

@bot.on(events.CallbackQuery(data=b'regip'))
async def reg_ip(event):
	async def reg_ip_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**VERIFIKASI ADMIN:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as dom:
			await event.respond('**IP VPS:**')
			dom = dom.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			dom = (await dom).raw_text
		async with bot.conversation(chat) as sub:
			await event.respond('**NAMA CLIENT:**')
			sub = sub.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			sub = (await sub).raw_text
		async with bot.conversation(chat) as ipvps:
			await event.respond('**EXPAIRED:**')
			ipvps = ipvps.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			ipvps = (await ipvps).raw_text
		cmd = f'printf "%s\n" "{user}" "{dom}" "{sub}" "{ipvps}"  | bot-add-ip'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**Successfully Register IP**")
		else:
			msg = f"""**Successfully Register Ip {dom}**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await reg_ip_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'renip'))
async def renip(event):
	async def renip_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**VERIFIKASI ADMIN:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as dom:
			await event.respond('**IP VPS:**')
			dom = dom.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			dom = (await dom).raw_text
		async with bot.conversation(chat) as ipvps:
			await event.respond('**EXPAIRED:**')
			ipvps = ipvps.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			ipvps = (await ipvps).raw_text
		cmd = f'printf "%s\n" "{user}" "{dom}" "{ipvps}"  | bot-renew-ip'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**Successfully Renew IP**")
		else:
			msg = f"""**Successfully Renew Ip {dom}**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await renip_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'delip'))
async def delip(event):
	async def delip_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**VERIFIKASI ADMIN:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as dom:
			await event.respond('**IP VPS:**')
			dom = dom.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			dom = (await dom).raw_text
		cmd = f'printf "%s\n" "{user}" "{dom}" | bot-del-ip'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**Successfully Delete IP**")
		else:
			msg = f"""**Successfully Delete Ip {dom}**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delip_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)


@bot.on(events.CallbackQuery(data=b'reg'))
async def reg(event):
	async def reg_(event):
		inline = [
[Button.inline(" ADD IP ","regip"),
Button.inline(" DELETE IP ","delip")],
[Button.inline(" RENEW IP ","renip"),
Button.inline(" MENU ","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
☉━━━━━━━━━━━━━━━━━━━━━☉
     🔸   𝗠𝗲𝗻𝘂 𝗗𝗶 𝗗𝗮𝘀𝗵𝗯𝗼𝗮𝗿𝗱   🔸
☉━━━━━━━━━━━━━━━━━━━━━☉
✨ » 𝗛𝗼𝘀𝘁𝗻𝗮𝗺𝗲/𝗜𝗣: `{DOMAIN}`
✨ » 𝗜𝗦𝗣: `{z["isp"]}`
✨ » 𝗥𝗲𝗴𝗶𝗼𝗻: `{z["country"]}`
🍄 »🤖@RiswanJabar
☉━━━━━━━━━━━━━━━━━━━━━☉
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await reg_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'reboot'))
async def rebooot(event):
	async def rebooot_(event):
		cmd = f'reboot'
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing Restart Service Server...`")
		time.sleep(1)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		subprocess.check_output(cmd, shell=True)
		await event.edit(f"""
**» REBOOT SERVER**
**» 🍄@RiswanJabar**
""",buttons=[[Button.inline("MAIN MENU","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await rebooot_(event)
	else:
		await event.answer("Access Denied",alert=True)


@bot.on(events.CallbackQuery(data=b'resx'))
async def resx(event):
	async def resx_(event):
		cmd = f'systemctl restart xray | systemctl restart nginx | systemctl restart haproxy | systemctl restart server | systemctl restart udp-custom | systemctl restart noobzvpns | systemctl restart client'
		subprocess.check_output(cmd, shell=True)
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing Restart Service Server...`")
		time.sleep(1)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(1)
		await event.edit(f"""
```Processing... 100%\n█████████████████████████ ```
**» Restarting Service Done**
**» 🍄@RiswanJabar**
""",buttons=[[Button.inline("MAIN MENU","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await resx_(event)
	else:
		await event.answer("Access Denied",alert=True)
		
@bot.on(events.CallbackQuery(data=b'speedtest'))
async def speedtest(event):
	async def speedtest_(event):
		cmd = 'speedtest-cli --share'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		time.sleep(0)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		await event.respond(f"""
**
{z}
**
**» 🍄@RiswanJabar**
""",buttons=[[Button.inline("MAIN MENU","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await speedtest_(event)
	else:
		await event.answer("Access Denied",alert=True)


import re
import subprocess
from telethon import events

# Email validation function
def is_valid_email(email):
    email_regex = r"(^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$)"
    return re.match(email_regex, email)

@bot.on(events.CallbackQuery(data=b'backup'))
async def backup(event):
    user_id = str(event.sender_id)

    async def backup_(event):
        async with bot.conversation(event.chat_id) as user:
            # Request email from the user
            await event.respond('**Input Email:**')
            user_input = await user.wait_event(events.NewMessage(incoming=True, from_users=event.sender_id))
            email = user_input.raw_text

            # Validate the email format
            if not is_valid_email(email):
                await event.respond("**Email tidak valid. Silakan masukkan email yang benar.**")
                return

            # Inform the user that the backup process has started
            await event.respond("**Proses backup dimulai... Mohon tunggu sebentar.**")

            # Command to run the backup process
            cmd = f'printf "%s\n" "{email}" | bot-backup'
            try:
                # Execute the command
                backup_output = subprocess.check_output(cmd, shell=True).decode("utf-8")
            except subprocess.CalledProcessError:
                # Handle errors during the backup process
                await event.respond("**Terjadi kesalahan saat melakukan backup. Pastikan email valid atau coba lagi nanti.**")
            except Exception as e:
                # Catch any other exceptions and log them (for debugging)
                await event.respond(f"**Terjadi kesalahan tak terduga: {str(e)}**")
            else:
                # Notify the user upon successful backup
                msg = f"**\nBackup berhasil! Silakan cek emailnya kak..\n**"
                await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()

    # Validate user permission
    a = valid(str(sender.id))
    if a == "true":
        await backup_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)
# Callback for restore operation
@bot.on(events.CallbackQuery(data=b'restore'))
async def restore(event):
    async def restore_(event):
        async with bot.conversation(event.chat_id) as user:
            await event.respond('**masukan Link Backup kak:**')
            user_input = await user.wait_event(events.NewMessage(incoming=True, from_users=event.sender_id))
            backup_link = user_input.raw_text
        
        cmd = f'printf "%s\n" "{backup_link}" | bot-restore'
        try:
            restore_output = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except subprocess.CalledProcessError:
            await event.respond("**Link Not Exist**")
        else:
            msg = f"""```{restore_output}```
**@RiswanJabar**"""
            await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    
    # Validate user permission
    a = valid(str(sender.id))
    if a == "true":
        await restore_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)



		
@bot.on(events.CallbackQuery(data=b'backer'))
async def backers(event):
	async def backers_(event):
		inline = [
[Button.inline(" BACKUP","backup"),
Button.inline(" RESTORE","restore")],
[Button.inline("MAIN MENU","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
☉━━━━━━━━━━━━━━━━━━━━━☉
     🔸   𝗠𝗲𝗻𝘂 𝗗𝗶 𝗗𝗮𝘀𝗵𝗯𝗼𝗮𝗿𝗱   🔸
☉━━━━━━━━━━━━━━━━━━━━━☉
✨ » 𝗛𝗼𝘀𝘁𝗻𝗮𝗺𝗲/𝗜𝗣: `{DOMAIN}`
✨ » 𝗜𝗦𝗣: `{z["isp"]}`
✨ » 𝗥𝗲𝗴𝗶𝗼𝗻: `{z["country"]}`
🍄 »@RiswanJabar
☉━━━━━━━━━━━━━━━━━━━━━☉
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await backers_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'setting'))
async def settings(event):
	async def settings_(event):
		inline = [
[Button.inline("Speedtest","speedtest"),
Button.inline("Backup&Resto","backer")],
[Button.inline("Reboot server","reboot"),
Button.inline("Restart service","resx")],
[Button.inline("Back menu","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
☉━━━━━━━━━━━━━━━━━━━━━☉
     🔸   𝗠𝗲𝗻𝘂 𝗗𝗶 𝗗𝗮𝘀𝗵𝗯𝗼𝗮𝗿𝗱   🔸
☉━━━━━━━━━━━━━━━━━━━━━☉
✨ » 𝗛𝗼𝘀𝘁𝗻𝗮𝗺𝗲/𝗜𝗣: `{DOMAIN}`
✨ » 𝗜𝗦𝗣: `{z["isp"]}`
✨ » 𝗥𝗲𝗴𝗶𝗼𝗻: `{z["country"]}`
🍄 »@RiswanJabar
☉━━━━━━━━━━━━━━━━━━━━━☉
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await settings_(event)
	else:
		await event.answer("Access Denied",alert=True)
