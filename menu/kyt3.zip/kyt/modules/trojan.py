from kyt import *

import subprocess
import re
import datetime as DT
import json
from telethon import events

# Menyimpan data pembuatan akun (misalnya menggunakan file JSON)
def get_user_data():
    try:
        with open('user_data.json', 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

def save_user_data(data):
    with open('user_data.json', 'w') as f:
        json.dump(data, f)

@bot.on(events.CallbackQuery(data=b'trial-bujang'))
async def trial_trojan(event):
    async def trial_trojan_(event):
        # Cek apakah pengguna sudah membuat akun hari ini
        user_data = get_user_data()
        sender = await event.get_sender()
        user_id = str(sender.id)
        today = DT.date.today().isoformat()

        # Jika pengguna sudah membuat akun hari ini
        if user_id in user_data and user_data[user_id] == today:
            await event.respond("**Anda sudah membuat akun Trojan hari ini. Cobalah lagi besok.**")
            return

        # Jika belum membuat akun hari ini, buatkan akun baru
        cmd = f'printf "%s\n" "RiswanJabar`</dev/urandom tr -dc X-Z0-9 | head -c4`" "3" "2000" "2000" | addtr-bot'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except subprocess.CalledProcessError:
            await event.respond("**Error: Could not generate Trojan account**")
            return
        except Exception as e:
            await event.respond(f"**Error: {str(e)}**")
            return

        later = DT.date.today() + DT.timedelta(days=3)
        b = [x.group() for x in re.finditer("trojan://(.*)", a)]

        if not b:
            await event.respond("**Error: Invalid Trojan URL format**")
            return

        remarks = re.search("#(.*)", b[0]).group(1)
        domain = re.search("@(.*?):", b[0]).group(1)
        uuid = re.search("trojan://(.*?)@", b[0]).group(1)
        
        msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
     **⟨🔸 Trojan Account🔸⟩**
**◇━━━━━━━━━━━━━━━━━◇**
**» Host Server :** `{domain}`
**» Quaota** `2000 GB`
**» Login IP** `2000 HP`
**» Port TLS    :** `443, 400-900`
**» Port NTLS   :** `80, 8080, 8081-9999 `
**» UUID        :** `{uuid}`
**» NetWork     :** `(WS) or (gRPC)`
**» Path        :** `/trojan`
**» ServiceName :** `trojan-grpc`
**◇━━━━━━━━━━━━━━━━━◇**
**» URL TLS    :**
```{b[0]}```
**◇━━━━━━━━━━━━━━━━━◇**
**» URL HTTP    :**
```{b[1].replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» URL gRPC   :** 
```{b[2].replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» Expired:** `{later}`
**◇━━━━━━━━━━━━━━━━━◇**
**» ** 🤖@RiswanJabar
"""
        await event.respond(msg)

        # Update data: menyimpan tanggal pembuatan akun untuk pengguna ini
        user_data[user_id] = today
        save_user_data(user_data)

    # Memeriksa apakah pengguna valid
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await trial_trojan_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)


# CEK member tr
@bot.on(events.CallbackQuery(data=b'cek-membertr'))
async def cek_tr(event):
    try:
        # Menjalankan perintah bash
        cmd = 'bash cek-mts'.strip()
        result = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)

        # Mengirim hasil ke pengguna
        await event.edit(f"""
{result}

**Shows Users from databases**
        """, buttons=[[Button.inline("‹ main menu ›", b"menu")]])

    except subprocess.CalledProcessError as e:
        # Jika terjadi error saat eksekusi perintah bash
        await event.edit(f"Error: {str(e)}", buttons=[[Button.inline("‹ main menu ›", b"menu")]])

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await cek_tr_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)



@bot.on(events.CallbackQuery(data=b'trojan'))
async def trojan(event):
    async def trojan_(event):
        inline = [
           
             [Button.inline("⚡BANSOS 3 HARI⚡", "trial-bujang")],
    
            [Button.inline("⚡CEK USER LOGIN⚡", "cek-tr")],
            [Button.inline("⚡LIST USER⚡", "cek-membertr")],     
            [Button.inline("↪️MAIN MENU↩️", "menu")]
        ]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
   **◇⟨🔸TROJAN SERVICE🔸⟩◇**             
**◇━━━━━━━━━━━━━━━━━◇**
**» Service:** `TROJAN`
**» Hostname/IP:** `{DOMAIN}`
**» ISP:** `{z["isp"]}`
**» Country:** `{z["country"]}`
**» ** 🤖@RiswanJabar
**◇━━━━━━━━━━━━━━━━━◇**
        """
        await event.edit(msg, buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await trojan_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)